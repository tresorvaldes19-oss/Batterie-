import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { ZipArchive } from 'archiver';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json());

  // API Route for AI Chat / Assistance
  app.post('/api/ai-chat', async (req, res) => {
    try {
      const {
        message,
        history,
        catalogSummary,
        settingsSummary,
        mode,
        customPrompt,
        unavailabilityMessage,
      } = req.body;

      // Unavailability only mode
      if (mode === 'unavailability_only') {
        return res.json({
          reply:
            unavailabilityMessage ||
            "Bonjour ! L'équipe commerciale est momentanément indisponible mais a bien reçu votre message. L'administrateur vous répondra très rapidement.",
          isUnavailability: true,
        });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.json({
          useLocalEngine: true,
          notice: 'Using autonomous full-time e-commerce AI engine',
        });
      }

      const ai = new GoogleGenAI({ apiKey });
      const systemInstruction =
        customPrompt ||
        `Tu es l'assistant commercial virtuel à temps plein (24h/24) d'AfroTrade Express, plateforme d'importation de produits directement depuis les usines de Shenzhen & Guangzhou (Chine) vers tous les pays d'Afrique (Cameroun, RD Congo, Côte d'Ivoire, Gabon, Congo, Sénégal, Bénin, Togo, Mali, Guinée, Nigeria, Ghana, Kenya, etc.).
Ton rôle est d'accueillir le client chaleureusement, de répondre avec précision à ses questions sur les articles du catalogue, les prix convertis dans la devise de son pays africain (FCFA XAF/XOF, Franc Congolais CDF, Naira NGN, Cedi GHS, Shilling KES, Rand ZAR, etc.), les expéditions (fret aérien express 7-10j, maritime 30-45j) et la passation de commande.
Règles importantes:
1. Sois très courtois, commercial, précis, encourageant et rassurant.
2. Si le client recherche un produit ou demande le produit/ordinateur le moins cher (ex: « l'ordinateur le plus min chers »), vérifie immédiatement dans la liste des articles du catalogue fourni : cite le modèle en stock le moins cher avec son nom exact, sa référence SKU, son prix en USD et son prix converti dans la devise africaine active du client, le nombre de pièces en stock à l'entrepôt de Shenzhen, ses caractéristiques clés et les délais de fret aérien (7-10 jours ouvrés).
3. Si le client mentionne une commande ou des articles de son chariot, confirme la bonne prise en compte de sa demande.
4. Rappelle toujours avec bienveillance au client que l'administrateur / propriétaire a été alerté en direct et consultera la discussion en temps réel pour confirmer les stocks et finaliser les détails.
5. Reste toujours opérationnel et constructif à toute heure (temps plein 24h/24).`;

      const promptContext = `Boutique: ${settingsSummary?.name || 'AfroTrade Express'}
WhatsApp Propriétaire: ${settingsSummary?.whatsappPhone || '+237699452010'}
Devise active client: ${settingsSummary?.currency || 'XAF'} (${settingsSummary?.currencySymbol || 'FCFA'})
Taux de change indicatif: 1$ = ${settingsSummary?.exchangeRate || 610} ${settingsSummary?.currencySymbol || 'FCFA'}

Extrait Catalogue Articles Disponibles:
${catalogSummary || 'Articles électroniques, téléphones, perruques, ordinateurs, électroménager, drones, caméras solaires'}

Historique de la conversation:
${JSON.stringify(history || [])}

Nouveau message du client:
"${message}"

Réponds directement au client en tant qu'assistant commercial virtuel officiel d'AfroTrade Express.`;

      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptContext,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });

        if (response.text && response.text.trim().length > 20) {
          return res.json({ reply: response.text });
        }
      } catch (genErr) {
        console.warn('Gemini model call notice, switching to autonomous engine:', genErr);
      }

      return res.json({
        useLocalEngine: true,
        notice: 'Using autonomous full-time e-commerce AI engine',
      });
    } catch (err: any) {
      console.error('Error generating AI response:', err);
      return res.json({
        useLocalEngine: true,
        notice: 'Using autonomous full-time e-commerce AI engine',
      });
    }
  });

  // API Route: Download complete project as ZIP archive
  app.get(['/api/admin/download-project-zip', '/api/download-zip'], async (_req, res) => {
    try {
      const publicZip = path.resolve(__dirname, 'public', 'afrotrade-express-project.zip');

      res.setHeader('Content-Type', 'application/zip');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="afrotrade-express-complet.zip"'
      );

      const archive = new ZipArchive({ zlib: { level: 9 } });
      archive.pipe(res);

      const itemsToInclude = [
        'src',
        'public',
        'api',
        'package.json',
        'tsconfig.json',
        'vite.config.ts',
        'server.ts',
        'index.html',
        'README.md',
        '.env.example',
        'metadata.json',
        'vercel.json',
        'netlify.toml',
        'Dockerfile',
        '.dockerignore',
        'docker-compose.yml',
        'firestore.rules',
        'firebase-blueprint.json',
        'firebase-applet-config.json',
      ];

      for (const item of itemsToInclude) {
        const fullPath = path.resolve(__dirname, item);
        if (!fs.existsSync(fullPath)) continue;

        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
          if (item === 'public') {
            archive.glob('**/*', {
              cwd: fullPath,
              ignore: ['*.zip'],
            }, { prefix: 'public' });
          } else {
            archive.directory(fullPath, item);
          }
        } else {
          archive.file(fullPath, { name: item });
        }
      }

      await archive.finalize();
    } catch (err) {
      console.error('Error generating project zip on demand:', err);
      const fallbackZip = path.resolve(__dirname, 'public', 'afrotrade-express-project.zip');
      if (fs.existsSync(fallbackZip)) {
        return res.download(fallbackZip, 'afrotrade-express-complet.zip');
      }
      res.status(500).json({ error: 'Failed to generate project archive' });
    }
  });

  // Vite middleware in dev or static serve in prod
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
