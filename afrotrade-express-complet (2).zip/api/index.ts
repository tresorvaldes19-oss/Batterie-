/**
 * API Health Check and Environment Info Endpoint
 */
export default function handler(_req: any, res: any) {
  res.status(200).json({
    name: 'AfroTrade Express API',
    status: 'online',
    version: '1.0.0',
    platform: process.env.VERCEL ? 'vercel' : 'node',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString(),
  });
}
