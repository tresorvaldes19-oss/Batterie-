import { GoogleGenAI } from '@google/genai';

/**
 * Serverless function for Vercel Free / Serverless deployments
 * Handles AI chat, assistance, and unavailability responses via Gemini API.
 */
export default async function handler(req: any, res: any) {
  // CORS configuration
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed. Please use POST.' });
  }

  try {
    let body = req.body;
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        body = {};
      }
    }

    const {
      message,
      history,
      catalogSummary,
      settingsSummary,
      mode,
      customPrompt,
      unavailabilityMessage,
    } = body || {};

    // 1. Unavailability mode
    if (mode === 'unavailability_only') {
      return res.status(200).json({
        reply:
          unavailabilityMessage ||
          "Bonjour ! L'équipe commerciale est momentanément indisponible mais a bien reçu votre message. L'administrateur vous répondra très rapidement.",
        isUnavailability: true,
      });
    }

    // 2. Check for Gemini API key
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(200).json({
        useLocalEngine: true,
        notice: 'Using autonomous full-time e-commerce AI engine',
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const systemInstruction =
      customPrompt ||
      `Tu es l'assistant commercial virtuel à temps plein (24h/24) d'AfroTrade Express, plateforme d'importation de produits directement depuis les usines de Shenzhen & Guangzhou (Chine) vers tous les pays d'Afrique (Cameroun, RD Congo, Côte d'Ivoire, Gabon, Congo, Sénégal, Bénin, Togo, Mali, Guinée, Nigeria, Ghana, Kenya, etc.).
Ton rôle est d'accueillir le client chaleureusement, de répondre avec précision à ses questions sur les articles du catalogue, les prix convertis dans la devise de son pays africain (FCFA XAF/XOF, Franc Congolais CDF, Naira NGN, Cedi GHS, Shilling KES, Rand ZAR, etc.), les expéditions (fret aérien express 7-10j, maritime 30-45j) et la passation de commande.
Règles importantes:
1. Sois très courtois, commercial, précis, encourageant et rassurant.
2. Si le client mentionne une commande ou des articles de son chariot, confirme la bonne prise en compte de sa demande.
3. Rappelle toujours avec bienveillance au client que l'administrateur / propriétaire a été alerté en direct et consultera la discussion en temps réel pour confirmer les stocks et finaliser les détails.
4. Reste toujours opérationnel et constructif à toute heure (temps plein).`;

    const promptContext = `Boutique: ${settingsSummary?.name || 'AfroTrade Express'}
WhatsApp Propriétaire: ${settingsSummary?.whatsappPhone || '+237699452010'}
Devise active client: ${settingsSummary?.currency || 'XAF'} (${settingsSummary?.currencySymbol || 'FCFA'})
Taux de change indicatif: 1$ = ${settingsSummary?.exchangeRate || 610} ${settingsSummary?.currencySymbol || 'FCFA'}

Extrait Catalogue Articles Disponibles:
${catalogSummary || 'Articles électroniques, téléphones, perruques, ordinateurs, électroménager, drones, caméras solaires'}

Historique de la conversation:
${JSON.stringify(history || [])}

Nouveau message du client:
"${message || ''}"

Réponds directement au client en tant qu'assistant commercial virtuel officiel d'AfroTrade Express.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: promptContext,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      if (response.text && response.text.trim().length > 20) {
        return res.status(200).json({ reply: response.text });
      }
    } catch (genErr) {
      console.warn('Gemini model call notice in serverless function:', genErr);
    }

    return res.status(200).json({
      useLocalEngine: true,
      notice: 'Using autonomous full-time e-commerce AI engine',
    });
  } catch (err: any) {
    console.error('Error in Vercel AI function:', err);
    return res.status(200).json({
      useLocalEngine: true,
      notice: 'Using autonomous full-time e-commerce AI engine',
    });
  }
}
