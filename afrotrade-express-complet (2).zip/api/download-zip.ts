import fs from 'fs';
import path from 'path';

/**
 * Serverless function for Vercel / Netlify / Cloudflare / Node
 * Streams or redirects to the complete project ZIP archive.
 */
export default function handler(req: any, res: any) {
  // Candidate paths where the zip archive may reside
  const candidatePaths = [
    path.join(process.cwd(), 'public', 'afrotrade-express-project.zip'),
    path.join(process.cwd(), 'dist', 'afrotrade-express-project.zip'),
    path.join(process.cwd(), 'afrotrade-express-project.zip'),
  ];

  for (const zipPath of candidatePaths) {
    if (fs.existsSync(zipPath)) {
      try {
        const stat = fs.statSync(zipPath);
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader(
          'Content-Disposition',
          'attachment; filename="afrotrade-express-complet.zip"'
        );
        res.setHeader('Content-Length', stat.size);
        const readStream = fs.createReadStream(zipPath);
        return readStream.pipe(res);
      } catch (err) {
        console.error('Error streaming zip file:', err);
      }
    }
  }

  // Fallback to static URL redirect
  return res.redirect(302, '/afrotrade-express-project.zip');
}
