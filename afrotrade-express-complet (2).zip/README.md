# AfroTrade Express - Plateforme E-Commerce & Import Chine-Afrique

Plateforme professionnelle de commerce en ligne et d'importation directe de produits depuis la Chine (Shenzhen / Guangzhou) vers l'Afrique (Cameroun, Côte d'Ivoire, Gabon, Congo, Bénin, Togo, Sénégal, RDC, etc.).

---

## ⚡ Déploiement Facile & Rapide (1 Clic)

Le projet a été spécialement configuré pour être déployé en **1 clic sans configuration complexe** sur les hébergeurs gratuits les plus populaires :

### 1. 🔺 Déploiement sur Vercel (Offre Gratuite / Free Tier)

Le projet intègre un fichier `vercel.json` et des fonctions serverless dans `/api` prêtes pour Vercel :

**Option A : Via GitHub (Recommandé)**
1. Poussez votre projet sur un dépôt GitHub (public ou privé).
2. Rendez-vous sur [vercel.com](https://vercel.com) et cliquez sur **"Add New Project"**.
3. Importez votre dépôt GitHub. Vercel détecte automatiquement :
   - **Framework Preset** : `Vite`
   - **Build Command** : `npm run build`
   - **Output Directory** : `dist`
4. *(Optionnel)* Dans la section **Environment Variables**, ajoutez :
   - `GEMINI_API_KEY` : votre clé API gratuite [Google AI Studio](https://aistudio.google.com/)
5. Cliquez sur **Deploy**. Votre site est en ligne avec un lien HTTPS gratuit (ex: `mon-projet.vercel.app`) !

**Option B : Via le CLI Vercel**
```bash
npm i -g vercel
vercel
```

---

### 2. 🌐 Déploiement sur Netlify (Offre Gratuite)

Le fichier `netlify.toml` et les redirections SPA `public/_redirects` sont déjà configurés :
1. Rendez-vous sur [netlify.com](https://www.netlify.com/).
2. Glissez-déposez le dossier du projet ou importez votre dépôt GitHub.
3. Configuration de build :
   - **Build command** : `npm run build`
   - **Publish directory** : `dist`
4. Déployez ! Le routage SPA et le catalogue fonctionnent sans aucune erreur 404 lors des rafraîchissements de page.

---

### 3. 🐳 Déploiement avec Docker & VPS

Un `Dockerfile` optimisé multi-stage et un fichier `docker-compose.yml` sont inclus :
```bash
# Lancement direct en 1 seule commande :
docker compose up -d --build
```
Le site sera immédiatement accessible sur le port `3000` (ex: `http://ip-de-votre-vps:3000`).

---

### 4. 🚂 Déploiement sur Render ou Railway

- **Build Command** : `npm run build`
- **Start Command** : `npm start`
- Les variables d'environnement (`PORT`, `GEMINI_API_KEY`) sont automatiquement prises en compte.

---

## 🚀 Fonctionnalités Incluses

### 🛒 E-Commerce & Catalogue Client
- **Catalogue B2B & B2C** : Grille de produits avec photos multi-angles, devises dynamiques (€ EUR, $ USD, FCFA).
- **Fiches Produits Riches** : Galerie photos, calcul de marge, stocks, spécifications techniques, sélecteurs de variantes et quantités.
- **Panier d'Achat Complet** : Ajout d'articles, calcul automatique des sous-totaux, frais de transit et seuils de gratuité.
- **Commande & WhatsApp** : Génération de commande directe avec redirection WhatsApp pré-formatée (références, quantités, devis) et enregistrement en base.
- **Espace Client / Compte** : Création de compte client, suivi des commandes passées, coordonnées de livraison et messagerie privée.

### 🛡️ Panneau d'Administration Complet (Admin Panel)
- **Tableau de Bord Logistique** : Statistiques globales (ventes, commandes transit maritime/aérien, messages non lus, alertes stock faible).
- **Publications & Produits** : Ajout, modification, gestion des stocks, photos, prix d'achat/vente, suppression d'articles.
- **Gestion des Contenus & Catégories** : Édition des bannières d'accueil (Hero, badges, sous-titres), cartes d'avantages logistiques, création/modification/suppression des catégories de produits.
- **Commandes & Expéditions** : Suivi des commandes clients, changement de statut (Nouvelle, En préparation, Expédiée, Livrée), consultation des articles commandés.
- **Messagerie & Devis en Direct** : Suivi des conversations clients, statut `en_attente`, réponses directes de l'admin.
- **Assistant IA Commercial & Répondeur** : Configuration de l'IA (Gemini Flash), mode répondeur d'indisponibilité, personnalisation des prompts.
- **Paramètres Généraux** : Nom de la boutique, numéro WhatsApp commercial, taux de change USD/FCFA, frais de port, identifiants d'accès admin.
- **Sauvegarde & Téléchargement ZIP** : Exportation en un clic de l'intégralité du projet pour hébergement ou sauvegarde locale.

---

## 📦 Installation & Démarrage Local

### Prérequis
- [Node.js](https://nodejs.org/) v18 ou plus récent
- Gestionnaire de paquets `npm` (inclus avec Node.js) ou `bun` / `pnpm`

### 1. Cloner ou Décompresser le projet
Décompressez le fichier `.zip` dans le dossier de votre choix, puis ouvrez un terminal dans ce dossier.

### 2. Installer les dépendances
```bash
npm install
```

### 3. Configurer l'environnement
Copiez le fichier `.env.example` en `.env` :
```bash
cp .env.example .env
```
Ajoutez votre clé API Gemini si vous souhaitez activer l'IA en temps réel :
```env
GEMINI_API_KEY=votre_cle_api_ici
PORT=3000
```

### 4. Lancer le serveur de développement
```bash
npm run dev
```
Rendez-vous ensuite sur [http://localhost:3000](http://localhost:3000) dans votre navigateur.

### 5. Compiler pour la production
```bash
npm run build
```
Pour tester la version de production :
```bash
npm run preview
```

---

## 🔐 Accès Espace Administration

- **URL de connexion** : Cliquez sur le bouton "Admin" en haut ou naviguez vers l'onglet Admin
- **Identifiant par défaut** : `admin`
- **Mot de passe par défaut** : `admin123` (modifiable directement dans l'onglet **Paramètres** de l'administration).

---

## 📂 Structure du Projet

```text
├── api/                    # Fonctions Serverless prêtes pour Vercel Free (/api/ai-chat, /api/download-zip)
├── src/
│   ├── components/         # Composants réutilisables (Navbar, Footer, CartDrawer, etc.)
│   ├── context/            # Context React d'état global du panier, des devises et des commandes
│   ├── pages/              # Pages publiques (Accueil, Catalogue, Produit, Panier, Commande, etc.)
│   │   └── admin/          # Espace d'administration complet :
│   │       ├── AdminDashboard.tsx      # Tableau de bord & KPIs
│   │       ├── AdminProducts.tsx       # Gestion des publications & stocks
│   │       ├── AdminContent.tsx        # Éditeur de bannières & catégories
│   │       ├── AdminOrders.tsx         # Suivi des commandes
│   │       ├── AdminCustomers.tsx      # Gestion des clients
│   │       ├── AdminMessages.tsx       # Messagerie & discussions
│   │       ├── AdminSettings.tsx       # Paramètres, WhatsApp, IA, identifiants & Export ZIP
│   │       └── AdminExport.tsx         # Zone de téléchargement du ZIP & Guides Vercel
│   ├── services/           # Logique Firestore / DB locale & Service IA
│   └── types/              # Définitions TypeScript complètes
├── public/                 # Assets statiques, _redirects, et archive zip
├── server.ts               # Serveur Express & routes API (Local, Docker, Render, VPS)
├── vercel.json             # Configuration Vercel Free (SPA rewrites, headers, serverless)
├── netlify.toml            # Configuration Netlify Free
├── Dockerfile              # Conteneurisation Docker multi-stage
├── docker-compose.yml      # Orchestration Docker Compose
├── package.json            # Dépendances et scripts de compilation
├── vite.config.ts          # Configuration du bundler Vite, Tailwind CSS & code splitting
└── firestore.rules         # Règles de sécurité Firestore
```
