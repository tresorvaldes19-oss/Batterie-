import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext.tsx';
import { TopInfoBar } from './components/TopInfoBar.tsx';
import { Header } from './components/Header.tsx';
import { Footer } from './components/Footer.tsx';
import { CartDrawer } from './components/CartDrawer.tsx';
import { ChatWidget } from './components/ChatWidget.tsx';
import { CartNotification } from './components/CartNotification.tsx';
import { MobileBottomNav } from './components/MobileBottomNav.tsx';
import { ProductDetailsModal } from './components/ProductDetailsModal.tsx';
import { WhatsAppFloatingButton } from './components/WhatsAppFloatingButton.tsx';
import { OrderModeModal } from './components/OrderModeModal.tsx';
import { CurrencySelectorModal } from './components/CurrencySelectorModal.tsx';

// Public Pages
import { CatalogPage } from './pages/CatalogPage.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { ProductDetailPage } from './pages/ProductDetailPage.tsx';
import { CartPage } from './pages/CartPage.tsx';
import { CheckoutPage } from './pages/CheckoutPage.tsx';
import { AccountPage } from './pages/AccountPage.tsx';
import { ContactPage } from './pages/ContactPage.tsx';
import { LegalPage } from './pages/LegalPage.tsx';

// Admin Pages
import { AdminLogin } from './pages/admin/AdminLogin.tsx';
import { AdminLayout } from './pages/admin/AdminLayout.tsx';
import { AdminDashboard } from './pages/admin/AdminDashboard.tsx';
import { AdminProducts } from './pages/admin/AdminProducts.tsx';
import { AdminOrders } from './pages/admin/AdminOrders.tsx';
import { AdminCustomers } from './pages/admin/AdminCustomers.tsx';
import { AdminMessages } from './pages/admin/AdminMessages.tsx';
import { AdminSettings } from './pages/admin/AdminSettings.tsx';
import { AdminContent } from './pages/admin/AdminContent.tsx';
import { AdminExport } from './pages/admin/AdminExport.tsx';

const AppContent: React.FC = () => {
  const { navState, isAdmin, isCurrencyModalOpen, setIsCurrencyModalOpen } = useStore();

  const isAuthedAdmin =
    isAdmin ||
    (() => {
      try {
        return (
          sessionStorage.getItem('ate_admin_auth') === 'true' ||
          localStorage.getItem('ate_admin_auth') === 'true'
        );
      } catch {
        return false;
      }
    })();

  const renderContent = () => {
    // Admin routing
    if (navState.page.startsWith('admin-')) {
      if (navState.page === 'admin-login') {
        if (isAuthedAdmin) {
          return (
            <AdminLayout activeSection="admin-dashboard">
              <AdminDashboard />
            </AdminLayout>
          );
        }
        return <AdminLogin />;
      }

      // Protected admin routes: require isAuthedAdmin
      if (!isAuthedAdmin) {
        return <AdminLogin />;
      }

      switch (navState.page) {
        case 'admin-dashboard':
          return (
            <AdminLayout activeSection="admin-dashboard">
              <AdminDashboard />
            </AdminLayout>
          );
        case 'admin-products':
          return (
            <AdminLayout activeSection="admin-products">
              <AdminProducts />
            </AdminLayout>
          );
        case 'admin-content':
          return (
            <AdminLayout activeSection="admin-content">
              <AdminContent />
            </AdminLayout>
          );
        case 'admin-orders':
          return (
            <AdminLayout activeSection="admin-orders">
              <AdminOrders />
            </AdminLayout>
          );
        case 'admin-customers':
          return (
            <AdminLayout activeSection="admin-customers">
              <AdminCustomers />
            </AdminLayout>
          );
        case 'admin-messages':
          return (
            <AdminLayout activeSection="admin-messages">
              <AdminMessages />
            </AdminLayout>
          );
        case 'admin-settings':
          return (
            <AdminLayout activeSection="admin-settings">
              <AdminSettings />
            </AdminLayout>
          );
        case 'admin-export':
          return (
            <AdminLayout activeSection="admin-export">
              <AdminExport />
            </AdminLayout>
          );
        default:
          return (
            <AdminLayout activeSection="admin-dashboard">
              <AdminDashboard />
            </AdminLayout>
          );
      }
    }

    // Public pages
    return (
      <div className="min-h-screen flex flex-col bg-[#F8FAFC] font-sans text-[#0F172A] selection:bg-[#F59E0B]/20 selection:text-[#0A2540] pb-16 lg:pb-0">
        <TopInfoBar />
        <Header />
        <main className="flex-1">
          {(() => {
            switch (navState.page) {
              case 'catalog':
                return <CatalogPage />;
              case 'home':
                return <HomePage />;
              case 'product-detail':
                return <ProductDetailPage />;
              case 'cart':
                return <CartPage />;
              case 'checkout':
                return <CheckoutPage />;
              case 'account':
                return <AccountPage />;
              case 'contact':
                return <ContactPage />;
              case 'legal':
                return <LegalPage />;
              default:
                return <CatalogPage />;
            }
          })()}
        </main>
        <Footer />
        <CartDrawer />
        <ChatWidget />
        <CartNotification />
        <ProductDetailsModal />
        <WhatsAppFloatingButton />
        <MobileBottomNav />
        <CurrencySelectorModal
          isOpen={isCurrencyModalOpen}
          onClose={() => setIsCurrencyModalOpen(false)}
        />
      </div>
    );
  };

  return <>{renderContent()}</>;
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
