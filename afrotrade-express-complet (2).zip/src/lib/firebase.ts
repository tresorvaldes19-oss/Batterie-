import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import defaultAppletConfig from '../../firebase-applet-config.json';

// Build Firebase config: supports both Vercel/Netlify Environment Variables (VITE_FIREBASE_*)
// and the pre-configured project credentials in firebase-applet-config.json.
const env = typeof import.meta !== 'undefined' && import.meta.env ? import.meta.env : ({} as Record<string, string>);

const firebaseConfig = {
  projectId: env.VITE_FIREBASE_PROJECT_ID || defaultAppletConfig?.projectId || 'gen-lang-client-0317419460',
  appId: env.VITE_FIREBASE_APP_ID || defaultAppletConfig?.appId || '1:158336138079:web:8c0c854b45718176e114ea',
  apiKey: env.VITE_FIREBASE_API_KEY || defaultAppletConfig?.apiKey || 'AIzaSyBUQLSF_FnY0bqNIAaLMaLhwcLdHHbexeE',
  authDomain:
    env.VITE_FIREBASE_AUTH_DOMAIN ||
    defaultAppletConfig?.authDomain ||
    `${env.VITE_FIREBASE_PROJECT_ID || defaultAppletConfig?.projectId || 'gen-lang-client-0317419460'}.firebaseapp.com`,
  firestoreDatabaseId:
    env.VITE_FIREBASE_DATABASE_ID ||
    defaultAppletConfig?.firestoreDatabaseId ||
    'ai-studio-c3b904e1-044e-4d2d-b134-d909b89ef5a0',
  storageBucket:
    env.VITE_FIREBASE_STORAGE_BUCKET ||
    defaultAppletConfig?.storageBucket ||
    `${env.VITE_FIREBASE_PROJECT_ID || defaultAppletConfig?.projectId || 'gen-lang-client-0317419460'}.firebasestorage.app`,
  messagingSenderId: env.VITE_FIREBASE_MESSAGING_SENDER_ID || defaultAppletConfig?.messagingSenderId || '158336138079',
  measurementId: env.VITE_FIREBASE_MEASUREMENT_ID || defaultAppletConfig?.measurementId || '',
};

// Initialize Firebase App
export const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

let dbInstance: any;
try {
  dbInstance = initializeFirestore(
    app,
    {
      experimentalAutoDetectLongPolling: true,
      ignoreUndefinedProperties: true,
    },
    firebaseConfig.firestoreDatabaseId
  );
} catch {
  dbInstance = getFirestore(app, firebaseConfig.firestoreDatabaseId);
}
export const db = dbInstance;

// Initialize Firebase Auth
export const auth = getAuth(app);

// Connectivity validation helper
export async function testFirebaseConnection() {
  try {
    await getDocFromServer(doc(db, 'settings', 'connection-test'));
    return true;
  } catch (error: any) {
    if (error instanceof Error && (error.message.includes('client is offline') || error.message.includes('unavailable'))) {
      console.info('Firebase operating in offline-first mode.');
    }
    return false;
  }
}
