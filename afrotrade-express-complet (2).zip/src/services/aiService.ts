import { Message, Product, StoreSettings } from '../types/index.ts';
import { AFRICAN_CURRENCIES, getCurrencyInfo } from '../constants/currencies.ts';

/**
 * Intelligent Commercial AI Engine for AfroTrade Express.
 * Operates full-time (24h/24, 7j/7) in absence of the admin or owner,
 * answering directly and comprehensively to ALL customer questions and requests:
 * - Product catalogs, search, specs, availability & custom factory sourcing
 * - African currencies (all 54 countries), conversions and factory-direct pricing
 * - Shipping, customs & transit delays (Air express 7-10 days vs Sea groupage 30-45 days)
 * - Payment options: Orange Money, MTN, Wave, Moov, Airtel, Wire, deposit + cash on pickup
 * - Cash on delivery & deposit terms
 * - Physical depots & agencies in Africa (Douala, Yaoundé, Abidjan, Brazzaville, Libreville, Kinshasa, etc.)
 * - Wholesale, bulk discounts, B2B quotes, container shipping (20ft/40ft/CBM)
 * - Quality control, real photos/videos before boarding in Shenzhen
 * - Order tracking, changes, cancellations & additions
 * - Free shipping thresholds
 * - Direct contact with the owner / human manager
 */
export async function generateAiReply(params: {
  userMessage: string;
  conversationHistory: Message[];
  settings: StoreSettings;
  products: Product[];
  orderRef?: string;
  selectedCurrency?: string;
}): Promise<string> {
  const { userMessage, conversationHistory, settings, products, orderRef, selectedCurrency } = params;

  // Active currency info
  const currInfo = getCurrencyInfo(selectedCurrency || 'XAF');

  // Build catalog summary for grounding
  const catalogSummary = products
    .slice(0, 15)
    .map((p) => {
      const localPrice = Math.round(p.priceUSD * currInfo.rateToUSD);
      return `- ${p.name} (Réf: ${p.sku}) | Prix: $${p.priceUSD} (~${localPrice.toLocaleString('fr-FR')} ${currInfo.symbol}) | Stock: ${p.stock} | Fret Aérien: ${p.transitAirDays || '7-10 jours'} | Fret Maritime: ${p.transitSeaDays || '30-45 jours'}`;
    })
    .join('\n');

  // 1. Try calling server-side API proxy (Gemini API)
  try {
    const res = await fetch('/api/ai-chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: userMessage,
        history: conversationHistory.slice(-6).map((m) => ({
          role: m.sender === 'customer' ? 'user' : 'model',
          content: m.content,
        })),
        catalogSummary,
        settingsSummary: {
          name: settings.name,
          phone: settings.phone,
          whatsappPhone: settings.whatsappPhone,
          exchangeRate: settings.exchangeRateUSD_FCFA,
          currency: currInfo.code,
          currencySymbol: currInfo.symbol,
        },
        mode: settings.aiMode || 'full_time',
        customPrompt: settings.aiCustomSystemPrompt,
        unavailabilityMessage: settings.aiUnavailabilityMessage,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (
        data.reply &&
        !data.isFallback &&
        !data.useLocalEngine &&
        !data.reply.includes('En attendant, n\'hésitez pas à consulter notre catalogue') &&
        data.reply.trim().length > 30
      ) {
        return data.reply;
      }
    }
  } catch (apiErr) {
    console.info('Server AI proxy notice, running comprehensive commercial engine:', apiErr);
  }

  // 2. Comprehensive Autonomous Full-Time African E-Commerce AI Brain
  const msgLower = userMessage.toLowerCase().trim();

  // Helper formatting for prices
  const formatLocal = (priceUsd: number) => {
    const converted = Math.round(priceUsd * currInfo.rateToUSD);
    return `$${priceUsd} (~${converted.toLocaleString('fr-FR')} ${currInfo.symbol})`;
  };

  // --- 1. EXPLICIT ORDER RECAP OR ORDER STATUS ---
  const isOrderRecapMessage =
    userMessage.includes('📦 NOUVELLE COMMANDE REÇUE') ||
    userMessage.includes('DEMANDE DE COMMANDE');

  const isAskingDirectlyAboutOrder =
    isOrderRecapMessage ||
    ((msgLower.includes('ma commande') ||
      msgLower.includes('où est ma commande') ||
      msgLower.includes('suivi de commande') ||
      msgLower.includes('avancement') ||
      msgLower.includes('statut de commande')) &&
      !msgLower.includes('comment passer') &&
      !msgLower.includes('comment faire'));

  if (isAskingDirectlyAboutOrder) {
    return (
      `Bonjour ! Merci pour votre confiance${orderRef ? ` concernant la commande **#${orderRef}**` : ''}.\n\n` +
      `📦 **Suivi en direct de votre commande :**\n` +
      `• **Statut actuel :** Dossier enregistré et transmis au pôle logistique de notre entrepôt à Shenzhen (Chine).\n` +
      `• **Inspection qualité :** Les articles sont vérifiés avant l'emballage sécurisé pour l'Afrique.\n` +
      `• **Prise en charge par le propriétaire :** L'administrateur a reçu une alerte en direct dans ce fil de discussion pour valider l'acheminement et confirmer le bordereau de fret.\n\n` +
      `💬 Vous pouvez échanger directement avec lui ici-même ou sur WhatsApp au **${settings.whatsappPhone || '+237 6 99 45 20 10'}**.`
    );
  }

  // --- 2. MODIFICATION OU ANNULATION DE COMMANDE ---
  if (
    msgLower.includes('annuler') ||
    msgLower.includes('modifier commande') ||
    msgLower.includes('changer d\'article') ||
    msgLower.includes('changer article') ||
    msgLower.includes('ajouter un article') ||
    msgLower.includes('changer adresse') ||
    msgLower.includes('changer numero') ||
    msgLower.includes('changer numéro')
  ) {
    return (
      `📝 **Modification ou Annulation de Commande**\n\n` +
      `Tant que votre colis n'a pas quitté notre entrepôt de Shenzhen, les ajustements sont 100% gratuits :\n\n` +
      `• **Pour modifier des articles ou quantités :** Indiquez-nous ici les ajouts ou retraits souhaités.\n` +
      `• **Pour modifier vos coordonnées de livraison :** Précisez le nouveau nom, téléphone ou ville de destination.\n` +
      `• **Pour annuler :** Mentionnez votre référence de commande${orderRef ? ` (**#${orderRef}**)` : ''} et l'administrateur effectuera l'annulation immédiatement sans pénalité.\n\n` +
      `L'administrateur consulte actuellement votre message et mettra à jour votre dossier en direct.`
    );
  }

  // --- 2.5. RECHERCHE INTELLIGENTE DE PRODUITS & VÉRIFICATION DE STOCK EN DIRECT ---
  // Exemple spécifique : "l'ordinateur le plus min chers", "pc le moins cher", "téléphone disponible", etc.
  const isAskingCheapest =
    msgLower.includes('moins cher') ||
    msgLower.includes('min cher') ||
    msgLower.includes('min chers') ||
    msgLower.includes('pas cher') ||
    msgLower.includes('plus bas') ||
    msgLower.includes('premier prix') ||
    msgLower.includes('économique') ||
    msgLower.includes('economique') ||
    msgLower.includes('accessible') ||
    msgLower.includes('abordable') ||
    msgLower.includes('petit prix') ||
    msgLower.includes('meilleur prix');

  const isAskingComputer =
    msgLower.includes('ordinateur') ||
    msgLower.includes('pc') ||
    msgLower.includes('laptop') ||
    msgLower.includes('macbook') ||
    msgLower.includes('bureautique');

  const isAskingPhone =
    msgLower.includes('telephone') ||
    msgLower.includes('téléphone') ||
    msgLower.includes('smartphone') ||
    msgLower.includes('iphone') ||
    msgLower.includes('android');

  // CAS SPÉCIFIQUE ORDINATEURS (Recherche du modèle le moins cher ou vérification de stock)
  if (isAskingComputer) {
    const pcProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('ordinateur') ||
        p.name.toLowerCase().includes('pc') ||
        p.name.toLowerCase().includes('ordinateur') ||
        p.name.toLowerCase().includes('laptop')
    );
    const sortedPcs = [...pcProds].sort((a, b) => a.priceUSD - b.priceUSD);
    const cheapestPc = sortedPcs[0];
    const higherPc = sortedPcs[1];

    if (cheapestPc) {
      const stockBadge =
        cheapestPc.stock > 0
          ? `✅ **DISPONIBLE EN STOCK :** **${cheapestPc.stock} pièces** prêtes à l'expédition immédiate à notre entrepôt de Shenzhen.`
          : `⏳ **Rupture momentanée :** Réassort direct usine sous 48h.`;

      const charsList = (cheapestPc.characteristics || [])
        .slice(0, 5)
        .map((c) => `  ✓ ${c}`)
        .join('\n');

      return (
        `🔍 **Vérification en direct du stock à l'entrepôt de Shenzhen :**\n\n` +
        `L'ordinateur le moins cher actuellement disponible dans notre catalogue est :\n\n` +
        `💻 **${cheapestPc.name}**\n` +
        `• **Référence SKU :** \`${cheapestPc.sku}\`\n` +
        `• **Prix d'usine direct :** **${formatLocal(cheapestPc.priceUSD)}** (soit seulement $${cheapestPc.priceUSD})\n` +
        `• **État du stock :** ${stockBadge}\n` +
        (charsList ? `• **Fiche technique & Équipements :**\n${charsList}\n` : '') +
        `• **Expédition vers votre pays :** ✈️ Fret aérien express en **${cheapestPc.transitAirDays || '7 à 10 jours ouvrés'}** (dédouanement complet inclus à l'arrivée) ou 🚢 groupage maritime en **${cheapestPc.transitSeaDays || '30 à 40 jours'}**.\n\n` +
        (higherPc
          ? `💡 **Autre modèle plus puissant disponible :**\n• **${higherPc.name}** (Réf: \`${higherPc.sku}\`) à **${formatLocal(higherPc.priceUSD)}** — Stock : **${higherPc.stock} pièces** disponibles avec processeur supérieur et 16Go RAM.\n\n`
          : '') +
        `👉 Souhaitez-vous que je réserve un exemplaire pour vous ou préférez-vous l'ajouter à votre panier pour valider la commande ?`
      );
    }
  }

  // CAS SPÉCIFIQUE TÉLÉPHONES LES MOINS CHERS / DISPONIBILITÉ
  if (isAskingPhone && isAskingCheapest) {
    const phoneProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('téléphone') ||
        p.name.toLowerCase().includes('smartphone') ||
        p.name.toLowerCase().includes('android') ||
        p.name.toLowerCase().includes('téléphone')
    );
    const sortedPhones = [...phoneProds].sort((a, b) => a.priceUSD - b.priceUSD);
    const cheapestPhone = sortedPhones[0];

    if (cheapestPhone) {
      return (
        `🔍 **Vérification en direct des smartphones en stock :**\n\n` +
        `Le smartphone le moins cher actuellement disponible dans notre catalogue est :\n\n` +
        `📱 **${cheapestPhone.name}**\n` +
        `• **Référence SKU :** \`${cheapestPhone.sku}\`\n` +
        `• **Prix direct fabricant :** **${formatLocal(cheapestPhone.priceUSD)}** (soit $${cheapestPhone.priceUSD})\n` +
        `• **Disponibilité en stock :** ✅ **${cheapestPhone.stock} pièces** prêtes pour expédition à Shenzhen.\n` +
        `• **Réseaux & Compatibilité :** 100% débloqué tout opérateur en Afrique (Orange, MTN, Moov, Airtel, Vodacom).\n` +
        `• **Délais d'expédition :** ✈️ Fret aérien express 7 à 10 jours ouvrés avec dédouanement inclus.\n\n` +
        `👉 Voulez-vous que je vous aide à passer commande de ce modèle ?`
      );
    }
  }

  // --- 3. PAIEMENT À LA LIVRAISON (COD) & ACOMPTE ---
  if (
    msgLower.includes('paiement a la livraison') ||
    msgLower.includes('payer à la livraison') ||
    msgLower.includes('payer a la livraison') ||
    msgLower.includes('payer au depot') ||
    msgLower.includes('payer au dépôt') ||
    msgLower.includes('payer à l\'arrivée') ||
    msgLower.includes('payer a l\'arrivee')
  ) {
    return (
      `🤝 **Paiement au Dépôt & Modalités d'Acompte**\n\n` +
      `Parce que les marchandises sont importées sur-mesure directement depuis les usines de Shenzhen en Chine, nous appliquons une formule sécurisée et équitable :\n\n` +
      `1️⃣ **Acompte de réservation (30% à 50%) :** Versé à la validation de la commande pour déclencher l'achat usine et les formalités de fret aérien/maritime.\n` +
      `2️⃣ **Solde (50% à 70%) :** Payé en espèces ou Mobile Money directement lors du retrait de vos colis à notre agence/dépôt partenaire dans votre ville en Afrique.\n\n` +
      `Cette formule vous protège entièrement : vous inspectez vos colis sur place avant de verser le solde restant !`
    );
  }

  // --- 4. ACHAT DE GROS, B2B, REVENDEURS, CONTENEUR & DEVIS SUR-MESURE ---
  if (
    msgLower.includes('de gros') ||
    msgLower.includes('en gros') ||
    msgLower.includes('revendeur') ||
    msgLower.includes('grossiste') ||
    msgLower.includes('quantité') ||
    msgLower.includes('quantite') ||
    msgLower.includes('reduction') ||
    msgLower.includes('réduction') ||
    msgLower.includes('remise') ||
    msgLower.includes('devis') ||
    msgLower.includes('conteneur') ||
    msgLower.includes('carton') ||
    msgLower.includes('cbm') ||
    msgLower.includes('moq')
  ) {
    return (
      `💼 **Tarifs de Gros, Service B2B & Groupage Conteneur (Chine ➔ Afrique)**\n\n` +
      `Pour les commerçants, boutiques et importateurs africains, nous offrons des remises très avantageuses :\n\n` +
      `• **Tarifs dégressifs par carton :** De 15% à 35% de réduction selon les volumes commandés.\n` +
      `• **Fret Maritime au mètre cube (CBM) :** La solution la plus économique pour les gros volumes et charges lourdes (30 à 45 jours).\n` +
      `• **Conteneurs complets (20 pieds / 40 pieds HC) :** Négociation directe usine, dédouanement et acheminement portuaire clé en main.\n` +
      `• **Marquage personnalisé (OEM / Private Label) :** Possibilité d'apposer votre logo sur vos produits dès 50 pièces.\n\n` +
      `👉 Précisez-nous la quantité désirée et votre ville, le propriétaire vous établira un devis proforma personnalisé sous peu !`
    );
  }

  // --- 5. ADRESSES PHYSIQUES & DÉPÔTS EN AFRIQUE ---
  if (
    msgLower.includes('adresse') ||
    msgLower.includes('ou vous trouver') ||
    msgLower.includes('où vous trouver') ||
    msgLower.includes('localisation') ||
    msgLower.includes('bureau') ||
    msgLower.includes('agence') ||
    msgLower.includes('depot') ||
    msgLower.includes('dépôt') ||
    msgLower.includes('magasin') ||
    msgLower.includes('boutique physique')
  ) {
    return (
      `📍 **Nos Bureaux & Dépôts Partenaires :**\n\n` +
      `🇨🇳 **Hub Logistique Chine (Départ) :**\n` +
      `• Entrepôt & Centre de Contrôle Qualité : Bao'an District, Shenzhen & Guangzhou Hub.\n\n` +
      `🌍 **Agences de Retrait & Dépôts Partenaires en Afrique (Arrivée) :**\n` +
      `• **Cameroun :** Douala (Akwa / Bonabéri) & Yaoundé (Mvan / Poste Centrale).\n` +
      `• **Côte d'Ivoire :** Abidjan (Treichville & Yopougon).\n` +
      `• **Gabon :** Libreville (Centre-ville & Oloumi).\n` +
      `• **Congo :** Brazzaville (Moungali) & Pointe-Noire (Grand Marché).\n` +
      `• **RD Congo :** Kinshasa (Gombe / Limete).\n` +
      `• **Bénin :** Cotonou (Dantokpa / Akpakpa).\n` +
      `• **Sénégal, Mali, Togo, Burkina, Guinée :** Agences partenaires dans chaque capitale.\n\n` +
      `📞 Contact direct avec le responsable : **${settings.whatsappPhone || '+237 6 99 45 20 10'}**.`
    );
  }

  // --- 6. CONTRÔLE QUALITÉ, PHOTOS & VIDÉOS AVANT EMBARQUEMENT ---
  if (
    msgLower.includes('photo reelle') ||
    msgLower.includes('photo réelle') ||
    msgLower.includes('video') ||
    msgLower.includes('vidéo') ||
    msgLower.includes('qualite') ||
    msgLower.includes('qualité') ||
    msgLower.includes('original') ||
    msgLower.includes('vrai produit') ||
    msgLower.includes('voir le produit')
  ) {
    return (
      `📸 **Garantie Contrôle Qualité & Photos / Vidéos Réelles**\n\n` +
      `Chez **${settings.name}**, nous ne laissons aucune place au hasard :\n\n` +
      `1️⃣ **Inspection systématique :** Chaque article est déballé et testé par nos inspecteurs à Shenzhen (allumage des appareils, état des coutures, vérification des mèches, tests batterie).\n` +
      `2️⃣ **Photos & Vidéos de conformité :** Avant que votre colis ne soit scellé pour le fret aérien ou maritime, nous pouvons vous envoyer des photos et courtes vidéos réelles du produit.\n` +
      `3️⃣ **Emballage renforcé :** Cartons triple cannelure, papier bulle multicouche et cerclage hermétique pour résister au voyage.\n\n` +
      `Vous achetez en toute transparence comme si vous étiez vous-même en Chine !`
    );
  }

  // --- 7. LIVRAISON À DOMICILE VS RETRAIT AU DÉPÔT ---
  if (
    msgLower.includes('a domicile') ||
    msgLower.includes('à domicile') ||
    msgLower.includes('chez moi') ||
    msgLower.includes('livreur')
  ) {
    return (
      `🛵 **Livraison à Domicile & Retrait en Agence**\n\n` +
      `Dès l'arrivée de votre commande au dépôt local dans votre pays en Afrique :\n\n` +
      `1️⃣ **Retrait gratuit en agence :** Vous venez récupérer votre colis à notre dépôt partenaire dans votre ville.\n` +
      `2️⃣ **Livraison à domicile par coursier :** Disponible dans toutes les grandes villes (Douala, Yaoundé, Abidjan, Brazzaville, Libreville, Kinshasa, Cotonou, Dakar). Un livreur vous achemine votre colis directement à votre adresse pour un tarif local modique (souvent entre 1 000 et 2 500 FCFA selon le quartier).\n\n` +
      `Indiquez votre quartier à l'administrateur pour programmer le coursier !`
    );
  }

  // --- 8. FRAIS DE PORT & SEUILS DE LIVRAISON GRATUITE ---
  if (
    msgLower.includes('gratuit') ||
    msgLower.includes('frais de port') ||
    msgLower.includes('frais de livraison') ||
    msgLower.includes('combien coute la livraison') ||
    msgLower.includes('combien coûte la livraison')
  ) {
    return (
      `🚚 **Tarification du Transport & Offre de Livraison Gratuite**\n\n` +
      `• **Seuil Fret Offert :** La livraison de base est **GRATUITE** dès **$${settings.freeShippingThresholdUSD || 220}** d'achats !\n` +
      `• **Frais standard colis légers :** Seulement **$${settings.defaultShippingCostUSD || 18}** (~${Math.round((settings.defaultShippingCostUSD || 18) * currInfo.rateToUSD).toLocaleString('fr-FR')} ${currInfo.symbol}) pour les commandes inférieures au seuil.\n` +
      `• **Inclus dans le tarif :** Transport international depuis Shenzhen, manutention, assurance casse et **dédouanement complet** à l'arrivée en Afrique.\n\n` +
      `Ajoutez des articles à votre panier pour atteindre le seuil et bénéficier du fret offert !`
    );
  }

  // --- 9. PRODUITS DU CATALOGUE & RECHERCHES PRÉCISES ---

  // A. Téléphones, Smartphones, Accessoires & Réparations
  if (
    msgLower.includes('telephone') ||
    msgLower.includes('téléphone') ||
    msgLower.includes('smartphone') ||
    msgLower.includes('iphone') ||
    msgLower.includes('samsung') ||
    msgLower.includes('infinix') ||
    msgLower.includes('tecno') ||
    msgLower.includes('xiaomi') ||
    msgLower.includes('redmi') ||
    msgLower.includes('airpods') ||
    msgLower.includes('ecouteur') ||
    msgLower.includes('écouteur') ||
    msgLower.includes('chargeur') ||
    msgLower.includes('batterie')
  ) {
    const phoneProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('téléphone') ||
        p.name.toLowerCase().includes('smartphone') ||
        p.name.toLowerCase().includes('android') ||
        p.name.toLowerCase().includes('dual sim')
    );
    const prodList = phoneProds.slice(0, 3).map(
      (p) => `• **${p.name}** (Réf: ${p.sku}) : **${formatLocal(p.priceUSD)}** — Stock: ${p.stock} pièces`
    ).join('\n');

    return (
      `📱 **Smartphones & Téléphones d'Usine (Shenzhen 🇨🇳)**\n\n` +
      `Tous nos appareils sont neufs, débloqués d'usine et 100% compatibles avec tous les réseaux africains (Orange, MTN, Moov, Airtel, Vodacom, Togocom, etc.) :\n\n` +
      `${prodList || '• Smartphones Android 5G, 256 Go / 512 Go de stockage, doubles cartes SIM, écrans AMOLED 120Hz et batteries haute capacité 5500 mAh.'}\n\n` +
      `✨ **Garantie usine 12 mois** avec inspection avant embarquement.\n` +
      `✈️ **Fret aérien express (7 à 10 jours ouvrés)** avec dédouanement inclus.\n\n` +
      `Souhaitez-vous commander un modèle en particulier ou obtenir un tarif grossiste pour de la quantité ?`
    );
  }

  // B. Perruques, Mèches, Cheveux humains, Tissages & Lace
  if (
    msgLower.includes('perruque') ||
    msgLower.includes('mèche') ||
    msgLower.includes('meche') ||
    msgLower.includes('lace') ||
    msgLower.includes('wig') ||
    msgLower.includes('cheveux') ||
    msgLower.includes('bresilienne') ||
    msgLower.includes('brésilienne') ||
    msgLower.includes('closure') ||
    msgLower.includes('frontal') ||
    msgLower.includes('tissage')
  ) {
    const wigProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('perruque') ||
        p.name.toLowerCase().includes('perruque') ||
        p.name.toLowerCase().includes('dentelle')
    );
    const prodList = wigProds.slice(0, 3).map(
      (p) => `• **${p.name}** (Réf: ${p.sku}) : **${formatLocal(p.priceUSD)}**`
    ).join('\n');

    return (
      `💁‍♀️ **Perruques & Mèches 100% Cheveux Humains (Direct Fabricant)**\n\n` +
      `Nos ateliers partenaires à Guangzhou et Shenzhen confectionnent des perruques de qualité supérieure :\n\n` +
      `${prodList || '• Perruques Lace Frontal 13x4 / 13x6 HD transparentes, cheveux humains 10A et 12A vierges, textures lisses, ondulées (Body Wave) et bouclées (Deep Wave).'}\n\n` +
      `• Densités au choix : 180%, 200% et 250% bien fournies.\n` +
      `• Résistent parfaitement à la décoloration, teinture et fers chauffants.\n` +
      `✈️ Expédiées par fret aérien express sous 7 à 10 jours ouvrés directement vers votre pays.`
    );
  }

  // C. Ordinateurs, PC, Laptops & Accessoires Bureautique
  if (
    msgLower.includes('ordinateur') ||
    msgLower.includes('pc') ||
    msgLower.includes('laptop') ||
    msgLower.includes('macbook') ||
    msgLower.includes('portable') ||
    msgLower.includes('lenovo') ||
    msgLower.includes('dell') ||
    msgLower.includes('hp') ||
    msgLower.includes('asus')
  ) {
    const pcProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('ordinateur') ||
        p.name.toLowerCase().includes('pc') ||
        p.name.toLowerCase().includes('ordinateur')
    );
    const prodList = pcProds.slice(0, 3).map(
      (p) => `• **${p.name}** : **${formatLocal(p.priceUSD)}**`
    ).join('\n');

    return (
      `💻 **PC Portables & Ordinateurs d'Entreprise**\n\n` +
      `Nous fournissons des PC portables professionnels neufs et reconditionnés usine certifiés grade A+ :\n\n` +
      `${prodList || '• PC Ultra-Slim Intel Core i5/i7/i9 et AMD Ryzen, 16 Go à 32 Go de RAM, disques SSD NVMe haute vitesse de 512 Go à 1 To.'}\n\n` +
      `• Systèmes Windows 11 Pro activés multilingues (Français / Anglais).\n` +
      `• Claviers AZERTY ou QWERTY selon votre préférence.\n` +
      `✈️ Transport sécurisé par avion sous 7 à 10 jours avec protection antichoc renforcée.`
    );
  }

  // D. Drones, Caméras & Surveillance Solaire 4G
  if (
    msgLower.includes('drone') ||
    msgLower.includes('camera') ||
    msgLower.includes('caméra') ||
    msgLower.includes('surveillance') ||
    msgLower.includes('solaire') ||
    msgLower.includes('gopro') ||
    msgLower.includes('cctv')
  ) {
    const droneProds = products.filter(
      (p) =>
        p.category.toLowerCase().includes('drone') ||
        p.category.toLowerCase().includes('caméra') ||
        p.name.toLowerCase().includes('drone') ||
        p.name.toLowerCase().includes('caméra')
    );
    const prodList = droneProds.slice(0, 3).map(
      (p) => `• **${p.name}** : **${formatLocal(p.priceUSD)}**`
    ).join('\n');

    return (
      `🛸 **Drones Professionnels 4K & Caméras de Surveillance Solaires 4G**\n\n` +
      `${prodList || '• Drones 4K Ultra HD avec évitement d’obstacles à 360°, retour GPS automatique, portée 5 km et double batterie longue autonomie.\n• Caméras solaires autonomes avec carte SIM 4G, panneau solaire intégré et vision nocturne infrarouge.'}\n\n` +
      `Idéales pour sécuriser des chantiers, fermes, plantations, concessions et commerces sans nécessiter de courant électrique ni de Wi-Fi fixe !`
    );
  }

  // E. Énergie Solaire, Panneaux, Batteries Lithium & Générateurs
  if (
    msgLower.includes('panneau solaire') ||
    msgLower.includes('batterie solaire') ||
    msgLower.includes('lithium') ||
    msgLower.includes('onduleur') ||
    msgLower.includes('inverter') ||
    msgLower.includes('generateur') ||
    msgLower.includes('générateur') ||
    msgLower.includes('groupe electrogene') ||
    msgLower.includes('groupe électrogène')
  ) {
    return (
      `☀️ **Solutions d'Énergie Solaire & Kits d'Autonomie (Direct Usine)**\n\n` +
      `Nous expédions du matériel solaire de premier choix pour faire face aux coupures d'électricité :\n\n` +
      `• **Panneaux solaires monocristallins :** Rendement élevé (150W, 300W, 450W, 550W).\n` +
      `• **Batteries Lithium LiFePO4 :** Durée de vie supérieure à 10 ans, 100Ah / 200Ah en 12V, 24V et 48V.\n` +
      `• **Onduleurs hybrides solaires :** Pur sinus (1kVA à 10kVA) avec régulateur MPPT intégré.\n` +
      `🚢 Expédition recommandée par groupage maritime économique (au mètre cube) pour les batteries lourdes.`
    );
  }

  // F. Électroménager, Smart TV & Équipements de Maison
  if (
    msgLower.includes('electromenager') ||
    msgLower.includes('électroménager') ||
    msgLower.includes('frigo') ||
    msgLower.includes('refrigerateur') ||
    msgLower.includes('réfrigérateur') ||
    msgLower.includes('congelateur') ||
    msgLower.includes('congélateur') ||
    msgLower.includes('tv') ||
    msgLower.includes('climatiseur') ||
    msgLower.includes('mixeur') ||
    msgLower.includes('fer a repasser')
  ) {
    return (
      `📺 **Électroménager & Téléviseurs Smart TV 4K**\n\n` +
      `• **Smart TV 4K :** Écrans plats sans bordures de 32" à 75", Android TV avec YouTube, Netflix et décodeur intégré.\n` +
      `• **Froid & Congélation :** Réfrigérateurs combinés et congélateurs basse consommation, compatibles installations solaires.\n` +
      `• **Climatiseurs Inverter :** Split 1 CV, 1.5 CV et 2 CV économes en énergie.\n` +
      `🚢 Acheminement maritime sécurisé au mètre cube (CBM) avec palettes filmées et assurance transport.`
    );
  }

  // G. Motos, Véhicules, Tricycles & Pièces Détachées
  if (
    msgLower.includes('moto') ||
    msgLower.includes('tricycle') ||
    msgLower.includes('voiture') ||
    msgLower.includes('véhicule') ||
    msgLower.includes('piece detachee') ||
    msgLower.includes('pièce détachée') ||
    msgLower.includes('pneu') ||
    msgLower.includes('casque')
  ) {
    return (
      `🏍️ **Motos, Tricycles de Charge & Pièces Détachées Mécaniques**\n\n` +
      `• Motos utilitaires 125cc et 150cc très robustes adaptées aux pistes et routes africaines.\n` +
      `• Tricycles cargos benne basculante (200cc / 250cc) pour transport de marchandises et matériaux.\n` +
      `• Lots de pièces de rechange d'origine en gros (pneus, amortisseurs, cylindres, kits chaîne).\n` +
      `🚢 Expédition en caisse métallique sécurisée (CKD / SKD) par conteneur maritime.`
    );
  }

  // H. Chaussures, Baskets, Sneakers & Mocassins
  if (
    msgLower.includes('chaussure') ||
    msgLower.includes('basket') ||
    msgLower.includes('sneaker') ||
    msgLower.includes('botte') ||
    msgLower.includes('mocassin') ||
    msgLower.includes('sandale') ||
    msgLower.includes('talon')
  ) {
    return (
      `👟 **Chaussures, Baskets Tendance & Mocassins d'Usine**\n\n` +
      `• Chaussures hommes, femmes et enfants confectionnées avec des matériaux durables et confortables.\n` +
      `• Baskets respirantes, semelles amortissantes, mocassins en cuir et sandales design.\n` +
      `• Pointures du 36 au 46.\n` +
      `• Tarifs dégressifs par carton pour approvisionner votre magasin ou boutique en ligne !`
    );
  }

  // I. Vêtements, Mode, Sacs à Main, Valises & Montres
  if (
    msgLower.includes('vetement') ||
    msgLower.includes('vêtement') ||
    msgLower.includes('robe') ||
    msgLower.includes('chemise') ||
    msgLower.includes('costume') ||
    msgLower.includes('pantalon') ||
    msgLower.includes('sac') ||
    msgLower.includes('valise') ||
    msgLower.includes('montre') ||
    msgLower.includes('bijou')
  ) {
    return (
      `👗 **Mode, Prêt-à-porter, Maroquinerie & Accessoires**\n\n` +
      `• Collections de vêtements chics pour femmes, costumes d'affaires hommes et tenues décontractées.\n` +
      `• Sacs à main de luxe, valises rigides de voyage, sacs à dos professionnels pour ordinateurs.\n` +
      `• Montres étanches, ceintures en cuir et parures de bijoux.\n` +
      `Consultez les rubriques « Vêtements » et « Sacs et accessoires » de notre boutique pour faire votre sélection !`
    );
  }

  // J. Articles pour Enfants, Bébés & Jouets
  if (
    msgLower.includes('enfant') ||
    msgLower.includes('bébé') ||
    msgLower.includes('bebe') ||
    msgLower.includes('jouet') ||
    msgLower.includes('poussette') ||
    msgLower.includes('peluche')
  ) {
    return (
      `🧸 **Articles Pour Enfants, Jouets & Puériculture**\n\n` +
      `• Poussettes légères et pliables, lits parapluie, parcs pour bébés.\n` +
      `• Jouets éducatifs, voitures électriques rechargeables pour enfants avec télécommande parentale.\n` +
      `• Vêtements bébés et layettes en coton doux vendus par lots économiques.`
    );
  }

  // K. Match any specific product in database by SKU or Title words
  const matchedProd = products.find((p) => {
    const pName = p.name.toLowerCase();
    const pSku = p.sku.toLowerCase();
    return (
      (pSku && msgLower.includes(pSku)) ||
      msgLower.includes(pName.slice(0, 12)) ||
      (pName.length > 5 && pName.split(' ').some((word) => word.length > 4 && msgLower.includes(word)))
    );
  });

  if (matchedProd) {
    return (
      `Bonjour ! Concernant l'article **${matchedProd.name}** (Réf : ${matchedProd.sku}) :\n\n` +
      `💰 **Prix d'usine :** ${formatLocal(matchedProd.priceUSD)}\n` +
      `📦 **Stock disponible :** ${matchedProd.stock} unités prêtes à l'entrepôt de Shenzhen\n` +
      `✈️ **Fret Aérien Express :** ${matchedProd.transitAirDays || '7 à 10 jours ouvrés'}\n` +
      `🚢 **Groupage Maritime :** ${matchedProd.transitSeaDays || '30 à 45 jours'}\n\n` +
      `📝 **Caractéristiques :** ${matchedProd.description.slice(0, 190)}...\n\n` +
      `Souhaitez-vous que je vous aide à l'ajouter à votre chariot ou désirez-vous un devis pour un volume plus important ?`
    );
  }

  // --- 10. DEVISES AFRICAINES & CONVERSION INSTANTANÉE ---
  const currencyMatch = AFRICAN_CURRENCIES.find(
    (c) =>
      msgLower.includes(c.code.toLowerCase()) ||
      msgLower.includes(c.name.toLowerCase()) ||
      msgLower.includes(c.symbol.toLowerCase()) ||
      c.countries.some((cnt) => msgLower.includes(cnt.toLowerCase()))
  );

  if (
    currencyMatch ||
    msgLower.includes('devise') ||
    msgLower.includes('monnaie') ||
    msgLower.includes('taux de change') ||
    msgLower.includes('combien en') ||
    msgLower.includes('fcfa') ||
    msgLower.includes('naira') ||
    msgLower.includes('franc congolais') ||
    msgLower.includes('shilling') ||
    msgLower.includes('dinar') ||
    msgLower.includes('dirham')
  ) {
    const targetCurr = currencyMatch || currInfo;
    return (
      `🌍 **Support de Toutes les Devises Africaines sur ${settings.name}**\n\n` +
      `Nous couvrons l'intégralité des monnaies des **54 pays du continent africain** :\n\n` +
      `• **Devise active sélectionnée :** ${targetCurr.flag} **${targetCurr.name} (${targetCurr.code} - ${targetCurr.symbol})**\n` +
      `• **Taux de change indicatif :** 1 $ USD ≈ **${targetCurr.rateToUSD.toLocaleString('fr-FR')} ${targetCurr.symbol}**\n\n` +
      `💡 **Comment afficher les prix dans la monnaie de votre pays ?**\n` +
      `Il vous suffit de cliquer sur le sélecteur de devise en haut du site (ou dans le menu mobile). Choisissez votre pays (Cameroun, RDC, Côte d'Ivoire, Gabon, Congo, Sénégal, Bénin, Nigeria, etc.) et tous les prix du catalogue se convertiront automatiquement et fidèlement !`
    );
  }

  // --- 11. EXPÉDITION, TRANSIT & DÉLAIS CHINE ➔ AFRIQUE ---
  if (
    msgLower.includes('livraison') ||
    msgLower.includes('fret') ||
    msgLower.includes('delai') ||
    msgLower.includes('délai') ||
    msgLower.includes('combien de jour') ||
    msgLower.includes('combien de temps') ||
    msgLower.includes('avion') ||
    msgLower.includes('bateau') ||
    msgLower.includes('chine') ||
    msgLower.includes('cameroun') ||
    msgLower.includes('douala') ||
    msgLower.includes('yaounde') ||
    msgLower.includes('yaoundé') ||
    msgLower.includes('congo') ||
    msgLower.includes('brazzaville') ||
    msgLower.includes('pointe-noire') ||
    msgLower.includes('gabon') ||
    msgLower.includes('libreville') ||
    msgLower.includes('côte d\'ivoire') ||
    msgLower.includes('cote d\'ivoire') ||
    msgLower.includes('abidjan') ||
    msgLower.includes('kinshasa') ||
    msgLower.includes('rdc') ||
    msgLower.includes('senegal') ||
    msgLower.includes('sénégal') ||
    msgLower.includes('dakar') ||
    msgLower.includes('benin') ||
    msgLower.includes('bénin') ||
    msgLower.includes('cotonou') ||
    msgLower.includes('togo') ||
    msgLower.includes('lome') ||
    msgLower.includes('lomé') ||
    msgLower.includes('mali') ||
    msgLower.includes('bamako') ||
    msgLower.includes('guinée') ||
    msgLower.includes('conakry') ||
    msgLower.includes('transport') ||
    msgLower.includes('transit')
  ) {
    return (
      `✈️🚢 **Modalités d'Expédition Directe : Chine 🇨🇳 ➔ Afrique 🌍**\n\n` +
      `Nous assurons deux circuits logistiques sécurisés chaque semaine :\n\n` +
      `1️⃣ **Fret Aérien Express (7 à 10 jours ouvrés) :**\n` +
      `• Départs directs de Shenzhen chaque mardi et vendredi.\n` +
      `• **Dédouanement complet inclus** jusqu'au dépôt partenaire de votre ville.\n` +
      `• Idéal pour téléphones, perruques, ordinateurs, électronique et colis légers/urgents.\n\n` +
      `2️⃣ **Groupage Maritime Économique (30 à 45 jours) :**\n` +
      `• Tarification au mètre cube (CBM) ou au carton lourd.\n` +
      `• Idéal pour vêtements en gros, électroménager, machines et gros volumes revendeurs.\n\n` +
      `📍 **Mise à disposition :** Retrait à notre agence locale ou livraison à domicile dans votre ville. Indiquez votre pays pour que l'administrateur vous communique les coordonnées exactes !`
    );
  }

  // --- 12. DÉDOUANEMENT & FORMALITÉS DOUANIÈRES ---
  if (
    msgLower.includes('douane') ||
    msgLower.includes('dédouanement') ||
    msgLower.includes('dedouanement') ||
    msgLower.includes('taxe') ||
    msgLower.includes('frais de douane')
  ) {
    return (
      `🛡️ **Dédouanement 100% Inclus & Zéro Tracas !**\n\n` +
      `Vous n'avez aucune démarche administrative complexe à effectuer :\n\n` +
      `• En **Fret Aérien Express**, le dédouanement est **entièrement pris en charge** par nos transitaires agréés jusqu'à la mise à disposition dans nos dépôts locaux en Afrique.\n` +
      `• Le tarif global annoncé inclut l'acheminement depuis Shenzhen et les formalités d'entrée dans votre pays.\n` +
      `• Vous venez simplement retirer votre marchandise avec votre pièce d'identité et votre référence de commande sans mauvaise surprise !`
    );
  }

  // --- 13. MOYENS DE PAIEMENT LOCAUX EN AFRIQUE ---
  if (
    msgLower.includes('payer') ||
    msgLower.includes('paiement') ||
    msgLower.includes('mobile money') ||
    msgLower.includes('orange') ||
    msgLower.includes('mtn') ||
    msgLower.includes('wave') ||
    msgLower.includes('moov') ||
    msgLower.includes('airtel') ||
    msgLower.includes('virement') ||
    msgLower.includes('espece') ||
    msgLower.includes('espèces') ||
    msgLower.includes('comment régler') ||
    msgLower.includes('acompte')
  ) {
    return (
      `💳 **Moyens de Paiement Disponibles Partout en Afrique**\n\n` +
      `Pour vous permettre de régler facilement sans carte bancaire internationale, nous proposons :\n\n` +
      `📱 **Mobile Money Local (instantané) :**\n` +
      `• **Orange Money** (Cameroun, Côte d'Ivoire, Sénégal, Mali, RDC, Guinée)\n` +
      `• **MTN Mobile Money** (Cameroun, Côte d'Ivoire, Bénin, Congo, Ghana, Nigeria)\n` +
      `• **Wave** (Côte d'Ivoire, Sénégal)\n` +
      `• **Moov Money & Airtel Money** selon votre pays\n\n` +
      `🏦 **Virement bancaire / Western Union / MoneyGram** pour les commandes d'importation en gros.\n` +
      `🤝 **Paiement avec acompte de sécurité :** Possibilité de verser un acompte à la commande puis le solde au retrait de vos articles au dépôt local.\n\n` +
      `L'administrateur vous transmettra les numéros officiels de compte dans cette discussion.`
    );
  }

  // --- 14. COMMENT COMMANDER SUR LE SITE (ÉTAPE PAR ÉTAPE) ---
  if (
    msgLower.includes('comment commander') ||
    msgLower.includes('comment acheter') ||
    msgLower.includes('passer commande') ||
    msgLower.includes('comment faire pour commander') ||
    msgLower.includes('procédure') ||
    msgLower.includes('etapes') ||
    msgLower.includes('étapes')
  ) {
    return (
      `🛒 **Comment Passer Commande sur ${settings.name} en 4 Étapes Simples :**\n\n` +
      `1️⃣ **Ajoutez vos articles :** Parcourez le catalogue et cliquez sur **« Ajouter au chariot »**.\n` +
      `2️⃣ **Choisissez votre devise :** Sélectionnez votre monnaie nationale en haut de page pour vérifier le total converti.\n` +
      `3️⃣ **Renseignez vos coordonnées :** Ouvrez le chariot, indiquez votre nom, numéro de téléphone et ville de livraison.\n` +
      `4️⃣ **Validation automatique :** Votre commande est instantanément transmise ici dans l'espace de discussion avec photos, prix et descriptions, et/ou sur WhatsApp avec le commerçant.\n\n` +
      `L'équipe commerciale valide immédiatement la préparation de votre colis à Shenzhen !`
    );
  }

  // --- 15. SOURCING SUR-MESURE & ARTICLES HORS CATALOGUE ---
  if (
    msgLower.includes('sourcing') ||
    msgLower.includes('sur mesure') ||
    msgLower.includes('autre produit') ||
    msgLower.includes('trouver un produit') ||
    msgLower.includes('recherche usine') ||
    msgLower.includes('produit spécifique') ||
    msgLower.includes('vous avez aussi') ||
    msgLower.includes('je cherche') ||
    msgLower.includes('je voudrais')
  ) {
    return (
      `🏭 **Service de Sourcing Usine Sur-Mesure en Chine**\n\n` +
      `Vous avez besoin d'un article qui ne figure pas encore sur notre site ? Nous le trouvons pour vous en 24h !\n\n` +
      `• Envoyez-nous simplement une photo, un lien ou une description de l'article recherché dans cette discussion ou sur WhatsApp.\n` +
      `• Nos acheteurs situés sur place à Shenzhen, Guangzhou et Yiwu contactent directement les usines mères pour vous négocier le tarif le plus bas.\n` +
      `• Nous inspectons les échantillons et organisons l'expédition complète jusqu'à votre ville en Afrique.`
    );
  }

  // --- 16. FIABILITÉ, CONFIANCE & SÉCURITÉ ---
  if (
    msgLower.includes('arnaque') ||
    msgLower.includes('fiable') ||
    msgLower.includes('confiance') ||
    msgLower.includes('garantie') ||
    msgLower.includes('sécurité') ||
    msgLower.includes('peur') ||
    msgLower.includes('vrai')
  ) {
    return (
      `🛡️ **Pourquoi vous pouvez commander en toute confiance sur ${settings.name} :**\n\n` +
      `✅ **Présence réelle sur le terrain :** Un entrepôt logistique permanent à Shenzhen (Chine) et des agences de dépôt partenaires dans les principales métropoles d'Afrique (Douala, Abidjan, Libreville, Brazzaville, Kinshasa, etc.).\n` +
      `✅ **Contrôle Qualité :** Vérification systématique des articles et envoi de photos/vidéos de confirmation avant scellage des colis.\n` +
      `✅ **Assurance transit incluse :** En cas d'incident rare lors du vol ou de la traversée maritime, votre marchandise est réexpédiée ou remboursée intégralement.\n` +
      `✅ **Contact direct :** Le propriétaire est joignable 7j/7 au **${settings.whatsappPhone || '+237 6 99 45 20 10'}**.`
    );
  }

  // --- 17. CONTACT HUMAIN, PROPRIÉTAIRE & WHATSAPP ---
  if (
    msgLower.includes('humain') ||
    msgLower.includes('proprietaire') ||
    msgLower.includes('propriétaire') ||
    msgLower.includes('admin') ||
    msgLower.includes('responsable') ||
    msgLower.includes('téléphone') ||
    msgLower.includes('telephone') ||
    msgLower.includes('numéro') ||
    msgLower.includes('numero') ||
    msgLower.includes('whatsapp') ||
    msgLower.includes('appeler')
  ) {
    return (
      `👤 **Contacter Directement le Propriétaire / Service Commercial :**\n\n` +
      `• **Discussion en direct sur le site :** Votre message est visible par l'administrateur qui peut vous répondre directement ici.\n` +
      `• **WhatsApp Direct :** **${settings.whatsappPhone || '+237 6 99 45 20 10'}**\n` +
      `• **Téléphone :** **${settings.phone || '+237 6 99 45 20 10'}**\n` +
      `• **Email :** ${settings.email || 'contact@afrotrade-express.com'}\n` +
      `• **Horaires de bureau :** ${settings.openingHours || 'Lun - Sam : 08h00 - 19h00 (GMT+1)'}\n\n` +
      `L'administrateur prendra connaissance de vos messages sous peu.`
    );
  }

  // --- 18. SALUTATIONS POLIES & ACCUEIL ---
  if (
    msgLower.includes('bonjour') ||
    msgLower.includes('bonsoir') ||
    msgLower.includes('salut') ||
    msgLower.includes('hello') ||
    msgLower.includes('coucou') ||
    msgLower.includes('merci') ||
    msgLower === 'bjr' ||
    msgLower === 'bsr'
  ) {
    return (
      `Bonjour et bienvenue sur **${settings.name}** ! 🇨🇳 ➔ 🌍\n\n` +
      `Je suis l'assistant commercial virtuel actif 24h/24 et 7j/7. En l'absence temporaire du propriétaire, je suis à votre entière disposition pour répondre à toutes vos demandes :\n\n` +
      `1️⃣ **Articles & Catalogue :** Prix d'usine, caractéristiques et disponibilités à Shenzhen.\n` +
      `2️⃣ **Devise :** Affichage de nos prix dans la monnaie de votre pays (${currInfo.flag} ${currInfo.code} - ${currInfo.symbol}).\n` +
      `3️⃣ **Expédition :** Fret aérien express (7 à 10 jours ouvrés) ou groupage maritime (30 à 45 jours).\n` +
      `4️⃣ **Paiements :** Mobile Money (Orange, MTN, Wave, Moov, Airtel) ou virement.\n\n` +
      `L'administrateur a été prévenu en direct de votre message. Quelle est votre question ou quel produit vous intéresse aujourd'hui ?`
    );
  }

  // --- 19. ASSISTANCE GÉNÉRALE CONTEXTUELLE SUR-MESURE ---
  return (
    `Bonjour ! J'ai bien pris note de votre message : « *${userMessage.slice(0, 100)}* ».\n\n` +
    `En tant qu'assistant commercial virtuel d'**${settings.name}**, je peux répondre immédiatement à toutes vos demandes :\n\n` +
    `• **Achat d'usine en Chine :** Tous nos articles (téléphones, perruques, ordinateurs, drones, vêtements, électroménager) sont expédiés directement depuis nos entrepôts de Shenzhen aux prix d'usine les plus compétitifs.\n` +
    `• **Devise de votre pays :** Vos prix sont convertibles en **${currInfo.name} (${currInfo.code} - ${currInfo.symbol})** en un clic via le sélecteur en haut du site.\n` +
    `• **Expédition sécurisée :** Fret aérien express (7 à 10 jours ouvrés avec dédouanement complet inclus) ou groupage maritime.\n` +
    `• **Prise en charge par le commerçant :** L'administrateur a reçu une alerte en direct dans son panneau de gestion et se joindra également à cette discussion.\n\n` +
    `Vous pouvez aussi nous contacter directement sur WhatsApp au **${settings.whatsappPhone || '+237 6 99 45 20 10'}**.`
  );
}
