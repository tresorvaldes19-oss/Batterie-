import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase.ts';
import {
  Product,
  Category,
  Order,
  Conversation,
  Message,
  StoreSettings,
  CustomerProfile,
} from '../types/index.ts';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function isPermissionError(error: unknown): boolean {
  if (!error) return false;
  const msg = error instanceof Error ? error.message : String(error);
  const code = (error as any)?.code;
  return (
    code === 'permission-denied' ||
    msg.toLowerCase().includes('missing or insufficient permissions') ||
    msg.toLowerCase().includes('permission-denied')
  );
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export function cleanData<T extends Record<string, any>>(obj: T): Partial<T> {
  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      if (value && typeof value === 'object' && !Array.isArray(value) && !(value instanceof Date)) {
        result[key] = cleanData(value);
      } else {
        result[key] = value;
      }
    }
  }
  return result as Partial<T>;
}

export const DEFAULT_STORE_SETTINGS: StoreSettings = {
  id: 'main',
  name: 'AfroTrade Express',
  tagline: 'Import Chine → Afrique',
  description:
    'Votre partenaire de confiance pour l’importation de produits directement depuis la Chine (Shenzhen/Guangzhou) vers le Cameroun, Congo, Gabon, Côte d’Ivoire, Bénin et l’Afrique.',
  logoUrl: '',
  primaryColor: '#0A2540',
  email: 'contact@afrotrade-express.com',
  phone: '+237 6 99 45 20 10',
  whatsappPhone: '+237699452010',
  address: 'Boutique & Dépôt Transit : Douala & Shenzhen Hub',
  openingHours: 'Lun - Sam : 08h00 - 19h00 (GMT+1)',
  socialLinks: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    whatsapp: 'https://wa.me/237699452010',
  },
  deliveryNotice: 'Livraison en Afrique : Cameroun, Congo, Gabon, Côte d’Ivoire, Bénin et autres pays',
  promoBannerText: '🚢 Groupage maritime & Fret aérien Chine-Afrique : Départ chaque semaine depuis Shenzhen !',
  promoBannerEnabled: true,
  freeShippingThresholdEUR: 200,
  freeShippingThresholdUSD: 220,
  defaultShippingCostEUR: 15,
  defaultShippingCostUSD: 18,
  exchangeRateUSD_FCFA: 610, // 1 USD = 610 FCFA (typical average)
  termsAndConditions: `Conditions Générales d'Importation - AfroTrade Express
1. Commandes et Délais : Les délais moyens par fret aérien sont de 7 à 10 jours ouvrés, et par conteneur maritime de 30 à 45 jours.
2. Tarification : Les prix sont affichés en Dollars ($), Euros (€) et convertis en FCFA. Le dédouanement et le transit sont pris en charge selon l'option choisie.
3. Vérification Qualité : Inspection rigoureuse des marchandises à Shenzhen avant expédition vers l'Afrique.`,
  privacyPolicy: `Politique de Confidentialité - AfroTrade Express
Vos données personnelles ne sont utilisées que pour la gestion de vos expéditions, bordereaux de suivi et notifications de livraison.`,
  shippingInfo: `Zones Desservies :
- Cameroun (Douala, Yaoundé)
- Congo (Brazzaville, Pointe-Noire)
- Gabon (Libreville, Port-Gentil)
- Côte d'Ivoire (Abidjan)
- Bénin (Cotonou)
- Sénégal, Mali, Togo, RDC et autres pays d'Afrique.`,
  returnsInfo: `Garantie & Conformité :
Garantie de conformité à l'arrivée au dépôt local. Échange ou dédommagement en cas de casse durant le transport aérien ou maritime.`,
  adminUsername: 'admin',
  adminPasswordHash: '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918',
  aiAssistantEnabled: true,
  aiMode: 'chat',
  aiUnavailabilityMessage:
    "Bonjour ! L'équipe commerciale d'AfroTrade Express est actuellement occupée à préparer les expéditions de Shenzhen. Votre message a bien été enregistré en attente de réponse de l'administrateur, qui vous répondra ici très rapidement. Pour toute question urgente, vous pouvez aussi le joindre directement sur WhatsApp au +237 6 99 45 20 10 !",
  aiCustomSystemPrompt: `Tu es l'assistant commercial virtuel d'AfroTrade Express, plateforme d'importation de produits directement depuis les usines de Shenzhen (Chine) vers l'Afrique (Cameroun, Congo, Gabon, Côte d'Ivoire, Bénin, etc.).
Ton rôle est d'accueillir le client chaleureusement, de répondre à ses questions sur les articles du catalogue, les prix en USD/EUR et FCFA, les expéditions (fret aérien 7-10j, maritime 30-45j) et la commande sur le site ou via WhatsApp.
Règles importantes:
1. Sois courtois, professionnel, concis et rassurant.
2. Rappelle toujours gentiment au client que le propriétaire/administrateur a été prévenu et consultera la discussion sous peu pour finaliser ou confirmer personnellement la demande.
3. Si le client a transmis une commande ou demande un devis, confirme la bonne réception des informations.`,
  aiResponseDelaySeconds: 2,
  heroTitle: "Achetez Directement en Chine aux Prix d'Usine",
  heroSubtitle:
    "Téléphones, drones, perruques, ordinateurs, électronique et équipements professionnels expédiés chaque semaine depuis Shenzhen vers le Cameroun, Congo, Gabon, Côte d'Ivoire, Bénin et toute l'Afrique.",
  heroImageUrl:
    'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=2000&q=80',
  heroBadge: "Plateforme d'Importation Chine → Afrique",
  logisticAirTitle: 'Fret Aérien Express',
  logisticAirDesc:
    'Départ direct de Shenzhen chaque mardi et vendredi. Réception au dépôt sous 7 à 10 jours ouvrés avec dédouanement inclus.',
  logisticSeaTitle: 'Groupage Maritime Économique',
  logisticSeaDesc:
    'Conteneurs complets et groupage au mètre cube (CBM) pour gros volumes et marchandises lourdes. Transit 30 à 45 jours.',
  logisticQualityTitle: 'Contrôle Qualité à Shenzhen',
  logisticQualityDesc:
    'Inspection minutieuse avant embarquement. Photos et vidéos de conformité envoyées avant tout départ pour l’Afrique.',
};

// Exact categories as requested:
export const DEFAULT_CATEGORIES: Category[] = [
  { id: 'tous', name: 'Tous', slug: 'tous' },
  { id: 'vetements', name: 'Vêtements', slug: 'vetements' },
  { id: 'chaussures', name: 'Chaussures', slug: 'chaussures' },
  { id: 'sacs-accessoires', name: 'Sacs et accessoires', slug: 'sacs-accessoires' },
  { id: 'perruques', name: 'Perruques', slug: 'perruques' },
  { id: 'telephones', name: 'Téléphones', slug: 'telephones' },
  { id: 'ordinateurs', name: 'Ordinateurs', slug: 'ordinateurs' },
  { id: 'electromenager', name: 'Électroménager', slug: 'electromenager' },
  { id: 'motos', name: 'Motos', slug: 'motos' },
  { id: 'voitures', name: 'Voitures', slug: 'voitures' },
  { id: 'cameras', name: 'Caméras', slug: 'cameras' },
  { id: 'drones', name: 'Drones', slug: 'drones' },
  { id: 'gaming', name: 'Gaming', slug: 'gaming' },
  { id: 'pour-enfants', name: 'Pour enfants', slug: 'pour-enfants' },
  { id: 'tablettes', name: 'Tablettes', slug: 'tablettes' },
  { id: 'autres', name: 'Autres', slug: 'autres' },
];

export const DEMO_PRODUCTS: Product[] = [
  {
    id: 'prod-001',
    name: 'Smartphone Android Professionnel 256 Go Dual SIM 5G',
    sku: 'ATE-TEL-101',
    description: `Smartphone haute performance importé directement des usines partenaires de Shenzhen. Écran AMOLED 6,7 pouces 120Hz, batterie ultra-endurante 5500 mAh avec charge rapide 67W.

Idéal pour les commerçants, professionnels et cadres en Afrique nécessitant une autonomie maximale et une double carte SIM compatible avec tous les opérateurs (Orange, MTN, Moov, Airtel).`,
    category: 'Téléphones',
    priceUSD: 150,
    priceEUR: 138,
    oldPriceUSD: 195,
    stock: 45,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1580910051074-3eb694886505?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Écran AMOLED 6.7 pouces 120 Hz Full HD+',
      'Mémoire RAM 8 Go + Stockage 256 Go UFS 3.1',
      'Appareil photo 64 MP Ultra-Clear + Grand angle',
      'Batterie 5 500 mAh & Charge rapide 67W Type-C',
      'Débloqué tout opérateur en Afrique et mondialement',
    ],
    specifications: {
      'Réseau': '5G / 4G LTE Dual SIM',
      'Système': 'Android 14 multilingue (FR/EN/AR)',
      'Origine': 'Shenzhen, Chine',
      'Garantie': '12 mois atelier',
      'Transit Aérien': '7 à 10 jours vers Afrique',
    },
    rating: 4.9,
    reviewsCount: 38,
    badge: 'Top Vente',
    featured: true,
    origin: 'Shenzhen, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-20T10:00:00.000Z',
    updatedAt: '2026-09-30T10:00:00.000Z',
  },
  {
    id: 'prod-002',
    name: 'Drone Professionnel 4K Ultra HD avec Évitement d’Obstacles 360°',
    sku: 'ATE-DRO-202',
    description: `Drone de prises de vues aériennes et de surveillance de chantier, doté d'une nacelle stabilisée 3 axes et d'une portée de contrôle jusqu'à 5 km.

Caméra 4K HDR avec retour vidéo en direct sur smartphone. Fourni avec 3 batteries rechargeables offrant chacune 32 minutes de vol continu et un sac de transport rigide.`,
    category: 'Drones',
    priceUSD: 185,
    priceEUR: 170,
    oldPriceUSD: 240,
    stock: 22,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1507582020474-9a35b7d455d9?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1527977966376-1c8408f9f108?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1473968512647-3e447244af8f?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1508614589041-895b88991e3e?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1507582020474-9a35b7d455d9?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Capteur 4K UHD 60fps avec zoom numérique 5x',
      '3 batteries haute capacité incluses (96 min cumulées)',
      'Détection d’obstacles infrarouge et optique 360°',
      'Retour automatique GPS au point de départ en un clic',
      'Mallette de transport renforcée antichoc offerte',
    ],
    specifications: {
      'Portée': 'Jusqu’à 5 000 m (Wi-Fi 5.8 GHz)',
      'Poids': '249 g (exempté d’enregistrement lourd)',
      'Moteurs': 'Brushless silencieux classe 7',
      'Origine': 'Guangdong, Chine',
    },
    rating: 4.8,
    reviewsCount: 24,
    badge: 'Nouveau',
    featured: true,
    origin: 'Guangdong, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-22T14:00:00.000Z',
    updatedAt: '2026-09-30T11:00:00.000Z',
  },
  {
    id: 'prod-003',
    name: 'Perruque Lace Frontal 13x4 Cheveux 100% Naturels Brésiliens HD',
    sku: 'ATE-PER-303',
    description: `Perruque de qualité supérieure confectionnée avec des cheveux humains 100% vierges sans traitement chimique. Dentelle suisse invisible HD adaptable à toutes les carnations.

Densité 180%, mèches soyeuses faciles à lisser, boucler ou teindre. Confort aéré et tenue impeccable pour les cérémonies, mariages et le quotidien.`,
    category: 'Perruques',
    priceUSD: 110,
    priceEUR: 102,
    oldPriceUSD: 155,
    stock: 58,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1527799820374-dcf8d9d4a388?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1595476108010-b4d1f102b1b1?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      '100% Cheveux humains vierges grade 12A',
      'Dentelle transparente HD Lace 13x4 prédécoupée',
      'Densité volumineuse 180% avec baby hair naturel',
      'Longueur 24 pouces (environ 60 cm)',
      'Bonnet respirant avec attaches élastiques réglables',
    ],
    specifications: {
      'Texture': 'Lisse soyeux / Straight',
      'Couleur': 'Noir naturel #1B',
      'Entretien': 'Lavable au shampoing doux et après-shampoing',
      'Origine': 'Atelier spécialisé Xuchang, Chine',
    },
    rating: 5.0,
    reviewsCount: 52,
    badge: 'Promotion',
    featured: true,
    origin: 'Xuchang, Chine',
    transitAirDays: '5-8 jours',
    transitSeaDays: '25-35 jours',
    createdAt: '2026-09-24T09:30:00.000Z',
    updatedAt: '2026-09-30T12:00:00.000Z',
  },
  {
    id: 'prod-004',
    name: 'Ordinateur Portable Ultra-Slim 15.6" Intel N95 16Go RAM 512Go SSD',
    sku: 'ATE-ORD-404',
    description: `PC portable fin et élégant en alliage d'aluminium, idéal pour les étudiants, PME, secrétariat et télétravail. Clavier rétroéclairé avec pavé numérique et lecteur d'empreintes digitales intégré.

Autonomie de 8 heures, port USB-C multifonction et écran IPS Full HD antireflet pour travailler confortablement dans toutes les conditions.`,
    category: 'Ordinateurs',
    priceUSD: 295,
    priceEUR: 275,
    oldPriceUSD: 380,
    stock: 20,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Processeur Intel Alder Lake N95 Quad-Core jusqu’à 3.4 GHz',
      '16 Go RAM DDR4 + SSD 512 Go M.2 NVMe rapide',
      'Écran 15.6 pouces IPS Full HD 1920x1080 bordures fines',
      'Clavier AZERTY / QWERTY avec pavé numérique rétroéclairé',
      'Windows 11 Pro activé avec pack Office préinstallé',
    ],
    specifications: {
      'Poids': '1.6 kg seulement',
      'Connectique': 'USB 3.0 x2, USB-C x1, HDMI, Jack 3.5mm, MicroSD',
      'Origine': 'Shenzhen High-Tech Park, Chine',
    },
    rating: 4.7,
    reviewsCount: 19,
    badge: 'Stock limité',
    featured: true,
    origin: 'Shenzhen, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-25T11:00:00.000Z',
    updatedAt: '2026-09-30T14:00:00.000Z',
  },
  {
    id: 'prod-005',
    name: 'Baskets Sneakers Running Tendance Unisexe Semelle Amortissante',
    sku: 'ATE-CHA-505',
    description: `Chaussures de sport ultra-légères et respirantes avec semelle ergonomique en mousse TPU réactive. Conception moderne et finitions renforcées pour un usage quotidien intensif.

Disponibles du 38 au 45 en plusieurs coloris tendance. Très prisées pour la revente en boutique et en ligne en Afrique.`,
    category: 'Chaussures',
    priceUSD: 28,
    priceEUR: 26,
    oldPriceUSD: 45,
    stock: 120,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Tissu mesh respirant anti-transpiration',
      'Semelle extérieure antidérapante en caoutchouc haute densité',
      'Semelle intérieure à mémoire de forme amovible',
      'Pointures disponibles : du 38 au 45',
      'Emballage individuel sous boîte carton rigide',
    ],
    specifications: {
      'Genre': 'Unisexe (Homme & Femme)',
      'Origine': 'Jinjiang / Putian, Chine',
      'Poids unitaire': '650 g la paire avec boîte',
    },
    rating: 4.9,
    reviewsCount: 88,
    badge: 'Top Vente',
    featured: false,
    origin: 'Jinjiang, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-26T15:00:00.000Z',
    updatedAt: '2026-09-30T15:30:00.000Z',
  },
  {
    id: 'prod-006',
    name: 'Caméra de Surveillance Solaire 4G Sans Fil 1080P Vision Nocturne',
    sku: 'ATE-CAM-606',
    description: `Caméra de sécurité autonome alimentée par panneau solaire intégré et batterie lithium 18650, fonctionnant avec une simple carte SIM 4G locale sans avoir besoin de box internet ni de câble électrique.

Vision nocturne couleur, détecteur de mouvement PIR avec alerte instantanée sur votre smartphone et interphone bidirectionnel pour parler à distance. Idéale pour les chantiers, concessions, fermes et résidences.`,
    category: 'Caméras',
    priceUSD: 75,
    priceEUR: 70,
    oldPriceUSD: 110,
    stock: 40,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1549109926-58f039549485?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      '100% Autonome : Panneau solaire 8W + Batterie rechargeable',
      'Connectivité 4G LTE compatible tout réseau africain (Orange/MTN)',
      'Étanchéité IP66 résistant aux fortes pluies et chaleur tropicale',
      'Rotation 355° horizontale et 90° verticale pilotable par appli',
      'Enregistrement sur carte micro-SD jusqu’à 128 Go et Cloud',
    ],
    specifications: {
      'Résolution': 'Full HD 1080P / 2 Megapixels',
      'Application': 'UBox / Tuya Smart en français',
      'Origine': 'Shenzhen, Chine',
    },
    rating: 4.8,
    reviewsCount: 31,
    badge: 'Nouveau',
    featured: true,
    origin: 'Shenzhen, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-27T08:00:00.000Z',
    updatedAt: '2026-09-30T16:00:00.000Z',
  },
  {
    id: 'prod-007',
    name: 'Blender Mixeur Professionnel Multifonction 2 Litres 2200W',
    sku: 'ATE-ELE-707',
    description: `Mixeur broyeur commercial haute puissance doté de lames en acier inoxydable trempé capables de broyer graines dures, manioc, maïs, fruits congelés et glaçons en quelques secondes.

Conçu pour les foyers exigeants, restaurants, bars et commerces de jus en Afrique. Bol incassable sans BPA de 2 litres et moteur avec protection anti-surchauffe.`,
    category: 'Électroménager',
    priceUSD: 45,
    priceEUR: 42,
    oldPriceUSD: 68,
    stock: 65,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1584269600464-37b1b58a9fe7?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1585515320310-259814833e62?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1570222094114-d054a817e56b?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Moteur en cuivre pur haute vitesse 2 200 Watts',
      'Lames en inox renforcé 6 couteaux double action',
      'Bol en polycarbonate incassable 2,0 Litres gradué',
      'Variateur de vitesse réglable 10 positions + fonction Pulse',
      'Alimentation 220-240V 50Hz prise européenne',
    ],
    specifications: {
      'Poids': '3.8 kg',
      'Origine': 'Zhejiang, Chine',
      'Certifications': 'CE & CB Approved',
    },
    rating: 4.9,
    reviewsCount: 64,
    badge: 'Top Vente',
    featured: false,
    origin: 'Zhejiang, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-28T10:00:00.000Z',
    updatedAt: '2026-09-30T17:00:00.000Z',
  },
  {
    id: 'prod-008',
    name: 'Tablette Éducative pour Enfants 10" avec Coque Antichoc & Stylet',
    sku: 'ATE-TAB-808',
    description: `Tablette spécialement configurée pour l'apprentissage et le divertissement des enfants de 3 à 12 ans. Plus de 50 applications éducatives préinstallées pour apprendre à lire, compter et dessiner.

Contrôle parental complet pour gérer le temps d'écran et bloquer les contenus inadaptés. Fournie avec une coque en silicone renforcée avec poignée/support et verre trempé préinstallé.`,
    category: 'Pour enfants',
    priceUSD: 65,
    priceEUR: 60,
    oldPriceUSD: 95,
    stock: 50,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1561154464-82e9adf32764?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1589739900243-4b52cd9b104e?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Écran tactile HD 10.1 pouces avec filtre anti-lumière bleue',
      'Mémoire 4 Go RAM + 64 Go extensible via MicroSD jusqu’à 256 Go',
      'Coque de protection épaisse antichoc en silicone non-toxique',
      'Stylet tactile et chargeur inclus dans le coffret',
      'Batterie 6 000 mAh longue autonomie (jusqu’à 7h en continu)',
    ],
    specifications: {
      'Système': 'Android 13 Édition Spéciale Enfants (IWAWA)',
      'Origine': 'Shenzhen, Chine',
    },
    rating: 4.8,
    reviewsCount: 41,
    badge: 'Nouveau',
    featured: false,
    origin: 'Shenzhen, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-29T14:00:00.000Z',
    updatedAt: '2026-09-30T17:30:00.000Z',
  },
  {
    id: 'prod-009',
    name: 'PC Portable Compact 14" Intel Celeron 8Go RAM 256Go SSD Windows 11',
    sku: 'ATE-ORD-409',
    description: `Ordinateur portable ultra-économique et léger (1.3 kg), idéal pour les étudiants, la saisie bureautique, la comptabilité et la navigation web.

Écran 14 pouces HD antireflet, autonomie 6 heures, webcam intégrée pour visioconférences et clavier chiclet confortable. L'ordinateur d'entrée de gamme le plus accessible de notre catalogue importé directement de Shenzhen.`,
    category: 'Ordinateurs',
    priceUSD: 180,
    priceEUR: 168,
    oldPriceUSD: 240,
    stock: 35,
    status: 'disponible',
    images: [
      'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80',
      'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=900&q=80',
    ],
    mainImage: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?auto=format&fit=crop&w=900&q=80',
    characteristics: [
      'Processeur Intel Celeron Dual-Core 2.8 GHz économe en énergie',
      '8 Go de mémoire vive RAM DDR4 + Disque SSD 256 Go M.2',
      'Écran 14 pouces HD 1366x768 avec traitement antireflet',
      'Système Windows 11 préinstallé en français',
      'Connectique complète : USB 3.0, Mini HDMI, Prise casque, Wi-Fi & Bluetooth',
    ],
    specifications: {
      'Poids': '1.35 kg',
      'Autonomie': 'Jusqu’à 6 heures en usage bureautique',
      'Origine': 'Shenzhen, Chine',
      'Garantie': '12 mois atelier',
    },
    rating: 4.6,
    reviewsCount: 29,
    badge: 'Top Vente',
    featured: true,
    origin: 'Shenzhen, Chine',
    transitAirDays: '7-10 jours',
    transitSeaDays: '30-40 jours',
    createdAt: '2026-09-30T10:00:00.000Z',
    updatedAt: '2026-10-01T10:00:00.000Z',
  }
];

export async function initializeStoreIfEmpty() {
  try {
    const settingsDoc = await getDoc(doc(db, 'settings', 'main'));
    if (!settingsDoc.exists()) {
      await setDoc(doc(db, 'settings', 'main'), DEFAULT_STORE_SETTINGS);
    }

    const categoriesSnap = await getDocs(collection(db, 'categories'));
    if (categoriesSnap.empty) {
      for (const cat of DEFAULT_CATEGORIES) {
        await setDoc(doc(db, 'categories', cat.id), cat);
      }
    }

    const productsSnap = await getDocs(collection(db, 'products'));
    if (productsSnap.empty) {
      for (const prod of DEMO_PRODUCTS) {
        await setDoc(doc(db, 'products', prod.id), prod);
      }
    }
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.WRITE, 'settings/main');
    } else {
      console.info('Firestore initial sync in offline/cached mode');
    }
  }
}

export async function fetchStoreSettings(): Promise<StoreSettings> {
  try {
    const snap = await getDoc(doc(db, 'settings', 'main'));
    if (snap.exists()) {
      return snap.data() as StoreSettings;
    }
    return DEFAULT_STORE_SETTINGS;
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.GET, 'settings/main');
    }
    return DEFAULT_STORE_SETTINGS;
  }
}

export async function saveStoreSettings(settings: StoreSettings): Promise<void> {
  const path = 'settings/main';
  try {
    await setDoc(doc(db, 'settings', 'main'), settings);
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } else {
      console.warn(`Write fallback for ${path}:`, error);
    }
  }
}

export function subscribeProducts(callback: (products: Product[]) => void) {
  const path = 'products';
  try {
    return onSnapshot(
      collection(db, 'products'),
      (snapshot) => {
        const prods: Product[] = [];
        snapshot.forEach((docSnap) => {
          prods.push({ id: docSnap.id, ...(docSnap.data() as Omit<Product, 'id'>) });
        });
        if (prods.length > 0) {
          callback(prods);
        } else {
          let isInit = false;
          try {
            isInit = localStorage.getItem('ate_store_initialized') === 'true';
          } catch {}
          if (!isInit) {
            callback(DEMO_PRODUCTS);
          } else {
            callback([]);
          }
        }
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return () => {};
  }
}

export async function saveProduct(product: Product): Promise<void> {
  const path = `products/${product.id}`;
  try {
    await setDoc(doc(db, 'products', product.id), product);
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } else {
      console.warn(`Write note for ${path}:`, error);
    }
  }
}

export async function deleteProductById(productId: string): Promise<void> {
  const path = `products/${productId}`;
  try {
    await deleteDoc(doc(db, 'products', productId));
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.DELETE, path);
    } else {
      console.warn(`Delete note for ${path}:`, error);
    }
  }
}

export function subscribeCategories(callback: (categories: Category[]) => void) {
  const path = 'categories';
  try {
    return onSnapshot(
      collection(db, 'categories'),
      (snapshot) => {
        const cats: Category[] = [];
        snapshot.forEach((docSnap) => {
          cats.push({ id: docSnap.id, ...(docSnap.data() as Omit<Category, 'id'>) });
        });
        if (cats.length > 0) {
          callback(cats);
        } else {
          callback(DEFAULT_CATEGORIES);
        }
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return () => {};
  }
}

export async function saveCategory(category: Category): Promise<void> {
  const path = `categories/${category.id}`;
  try {
    await setDoc(doc(db, 'categories', category.id), category);
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } else {
      console.warn(`Write note for ${path}:`, error);
    }
  }
}

export async function deleteCategoryById(categoryId: string): Promise<void> {
  const path = `categories/${categoryId}`;
  try {
    await deleteDoc(doc(db, 'categories', categoryId));
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.DELETE, path);
    } else {
      console.warn(`Delete note for ${path}:`, error);
    }
  }
}

export function subscribeOrders(callback: (orders: Order[]) => void) {
  const path = 'orders';
  try {
    const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
    return onSnapshot(
      q,
      (snapshot) => {
        const orders: Order[] = [];
        snapshot.forEach((docSnap) => {
          orders.push({ id: docSnap.id, ...(docSnap.data() as Omit<Order, 'id'>) });
        });
        callback(orders);
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return () => {};
  }
}

export async function createOrder(order: Order): Promise<void> {
  const path = `orders/${order.id}`;
  try {
    await setDoc(doc(db, 'orders', order.id), cleanData(order));
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.CREATE, path);
    } else {
      console.warn(`Create note for ${path}:`, error);
    }
  }
}

export async function updateOrderStatus(orderId: string, status: Order['status'], internalNote?: string): Promise<void> {
  const path = `orders/${orderId}`;
  try {
    const updatePayload: Record<string, any> = {
      status,
      updatedAt: new Date().toISOString(),
    };
    if (internalNote !== undefined) {
      updatePayload.internalNote = internalNote;
    }
    await updateDoc(doc(db, 'orders', orderId), updatePayload);
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    } else {
      console.warn(`Update note for ${path}:`, error);
    }
  }
}

export function subscribeConversations(callback: (conversations: Conversation[]) => void) {
  const path = 'conversations';

  // Instant local read for zero-latency UI
  try {
    const stored = localStorage.getItem('ate_conversations');
    if (stored) {
      const parsed: Conversation[] = JSON.parse(stored);
      if (Array.isArray(parsed) && parsed.length > 0) {
        callback(parsed);
      }
    }
  } catch {}

  const handleStorage = () => {
    try {
      const stored = localStorage.getItem('ate_conversations');
      if (stored) {
        const parsed: Conversation[] = JSON.parse(stored);
        if (Array.isArray(parsed)) callback(parsed);
      }
    } catch {}
  };
  const handleConvosUpdate = (e: Event) => {
    const customEv = e as CustomEvent;
    if (Array.isArray(customEv.detail)) {
      callback(customEv.detail);
    } else {
      handleStorage();
    }
  };
  window.addEventListener('storage', handleStorage);
  window.addEventListener('ate_conversations_update', handleConvosUpdate);

  try {
    const q = query(collection(db, 'conversations'), orderBy('updatedAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const convos: Conversation[] = [];
        snapshot.forEach((docSnap) => {
          convos.push({ id: docSnap.id, ...(docSnap.data() as Omit<Conversation, 'id'>) });
        });
        if (convos.length > 0) {
          callback(convos);
          try {
            localStorage.setItem('ate_conversations', JSON.stringify(convos));
          } catch {}
        } else {
          // Check local cache if Firestore is initially empty
          try {
            const stored = localStorage.getItem('ate_conversations');
            if (stored) {
              const parsed: Conversation[] = JSON.parse(stored);
              if (Array.isArray(parsed) && parsed.length > 0) {
                callback(parsed);
                return;
              }
            }
          } catch {}
          callback([]);
        }
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('ate_conversations_update', handleConvosUpdate);
      unsub();
    };
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('ate_conversations_update', handleConvosUpdate);
    };
  }
}

export function subscribeMessages(conversationId: string, callback: (messages: Message[]) => void) {
  const path = `conversations/${conversationId}/messages`;

  const readLocalMessages = () => {
    try {
      const stored = localStorage.getItem(`ate_msgs_${conversationId}`);
      if (stored) {
        const parsed: Message[] = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          callback(parsed);
        }
      }
    } catch {}
  };

  // Initial local read for instant render
  readLocalMessages();

  // Instant local event bus listener for real-time same-window updates
  const handleChatUpdate = (e: Event) => {
    const customEv = e as CustomEvent;
    if (customEv.detail && customEv.detail.conversationId === conversationId) {
      readLocalMessages();
    }
  };
  window.addEventListener('ate_chat_update', handleChatUpdate);

  const handleStorage = () => {
    readLocalMessages();
  };
  window.addEventListener('storage', handleStorage);

  let unsubFirestore = () => {};

  try {
    const q = query(collection(db, 'conversations', conversationId, 'messages'), orderBy('createdAt', 'asc'));
    unsubFirestore = onSnapshot(
      q,
      (snapshot) => {
        const msgs: Message[] = [];
        snapshot.forEach((docSnap) => {
          msgs.push({ id: docSnap.id, ...(docSnap.data() as Omit<Message, 'id'>) });
        });
        if (msgs.length > 0) {
          callback(msgs);
          try {
            localStorage.setItem(`ate_msgs_${conversationId}`, JSON.stringify(msgs));
          } catch {}
        } else {
          // If Firestore returns empty, check local fallback
          readLocalMessages();
        }
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  }

  return () => {
    window.removeEventListener('ate_chat_update', handleChatUpdate);
    window.removeEventListener('storage', handleStorage);
    unsubFirestore();
  };
}

export async function sendChatMessage(params: {
  conversationId: string;
  sender: 'customer' | 'admin' | 'system' | 'ai';
  senderName: string;
  content: string;
  customerEmail?: string;
  customerPhone?: string;
  customerId?: string;
  orderReference?: string;
  productId?: string;
  productName?: string;
  attachedOrder?: import('../types/index.ts').AttachedOrderSummary;
  subject?: string;
  isAi?: boolean;
}): Promise<string> {
  const now = new Date().toISOString();
  const convoRef = doc(db, 'conversations', params.conversationId);
  const msgId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const msgRef = doc(db, 'conversations', params.conversationId, 'messages', msgId);

  const isCustomer = params.sender === 'customer';
  const isAdmin = params.sender === 'admin';
  const isAi = params.sender === 'ai' || params.isAi === true;

  // New status: if client sends, it's 'en_attente' (waiting for admin).
  // If admin sends, it's 'repondu'.
  // If AI sends, keep 'en_attente' so admin still knows to review/confirm.
  const targetStatus: import('../types/index.ts').ConversationStatus = isAdmin
    ? 'repondu'
    : 'en_attente';

  const messageData: Message = {
    id: msgId,
    conversationId: params.conversationId,
    sender: params.sender,
    senderName: params.senderName,
    content: params.content,
    attachedOrderRef: params.orderReference,
    attachedProductId: params.productId,
    attachedProductName: params.productName,
    attachedOrder: params.attachedOrder,
    read: false,
    createdAt: now,
    isAi: isAi,
  };

  // Local fallback storage to guarantee zero-loss discussions
  try {
    const localMsgsKey = `ate_msgs_${params.conversationId}`;
    const stored = localStorage.getItem(localMsgsKey);
    const list: Message[] = stored ? JSON.parse(stored) : [];
    list.push(messageData);
    localStorage.setItem(localMsgsKey, JSON.stringify(list));
    // Immediately notify all active chat subscribers in current window
    window.dispatchEvent(
      new CustomEvent('ate_chat_update', {
        detail: { conversationId: params.conversationId, message: messageData },
      })
    );
  } catch {}

  // Update conversation in local storage cache immediately
  try {
    const storedConvos = localStorage.getItem('ate_conversations');
    const convosList: Conversation[] = storedConvos ? JSON.parse(storedConvos) : [];
    const idx = convosList.findIndex((c) => c.id === params.conversationId);

    const prevUnread = idx >= 0 ? convosList[idx].unreadCountAdmin || 0 : 0;
    const newUnreadAdmin = isCustomer ? prevUnread + 1 : (isAdmin ? 0 : prevUnread);

    const updatedConvo: Conversation = {
      id: params.conversationId,
      customerId: params.customerId || (idx >= 0 ? convosList[idx].customerId : undefined),
      customerName: isCustomer ? params.senderName : (idx >= 0 ? convosList[idx].customerName : params.senderName),
      customerEmail: params.customerEmail || (idx >= 0 ? convosList[idx].customerEmail : 'client@afrotrade.com'),
      customerPhone: params.customerPhone || (idx >= 0 ? convosList[idx].customerPhone : undefined),
      subject:
        params.subject ||
        (idx >= 0 && convosList[idx].subject
          ? convosList[idx].subject
          : params.orderReference
          ? `Commande transmise #${params.orderReference}`
          : 'Demande d’information'),
      status: targetStatus,
      orderReference: params.orderReference || (idx >= 0 ? convosList[idx].orderReference : undefined),
      productId: params.productId || (idx >= 0 ? convosList[idx].productId : undefined),
      productName: params.productName || (idx >= 0 ? convosList[idx].productName : undefined),
      lastMessage: params.content,
      unreadCountAdmin: newUnreadAdmin,
      unreadCountCustomer: isAdmin ? (idx >= 0 ? (convosList[idx].unreadCountCustomer || 0) + 1 : 1) : (idx >= 0 ? convosList[idx].unreadCountCustomer || 0 : 0),
      createdAt: idx >= 0 ? convosList[idx].createdAt : now,
      updatedAt: now,
    };

    if (idx >= 0) {
      convosList[idx] = updatedConvo;
    } else {
      convosList.unshift(updatedConvo);
    }
    localStorage.setItem('ate_conversations', JSON.stringify(convosList));
    window.dispatchEvent(new Event('storage'));
    window.dispatchEvent(new CustomEvent('ate_conversations_update', { detail: convosList }));
  } catch {}

  try {
    const convoSnap = await getDoc(convoRef);
    if (!convoSnap.exists()) {
      const convoData: Conversation = {
        id: params.conversationId,
        customerId: params.customerId,
        customerName: params.senderName,
        customerEmail: params.customerEmail || 'client@afrotrade.com',
        customerPhone: params.customerPhone,
        subject:
          params.subject ||
          (params.orderReference
            ? `Commande transmise #${params.orderReference}`
            : 'Demande d’information'),
        status: targetStatus,
        orderReference: params.orderReference,
        productId: params.productId,
        productName: params.productName,
        lastMessage: params.content,
        unreadCountAdmin: isCustomer ? 1 : 0,
        unreadCountCustomer: isAdmin ? 1 : 0,
        createdAt: now,
        updatedAt: now,
      };
      await setDoc(convoRef, cleanData(convoData));
    } else {
      const existing = convoSnap.data() as Conversation;
      const updateData: Record<string, any> = {
        lastMessage: params.content,
        updatedAt: now,
        status: targetStatus,
        unreadCountAdmin: isCustomer
          ? (existing.unreadCountAdmin || 0) + 1
          : isAdmin
          ? 0
          : existing.unreadCountAdmin || 0,
        unreadCountCustomer: isAdmin
          ? (existing.unreadCountCustomer || 0) + 1
          : existing.unreadCountCustomer || 0,
      };
      if (params.orderReference) updateData.orderReference = params.orderReference;
      if (params.customerPhone && !existing.customerPhone)
        updateData.customerPhone = params.customerPhone;
      if (params.customerId && !existing.customerId) updateData.customerId = params.customerId;
      await updateDoc(convoRef, cleanData(updateData));
    }

    await setDoc(msgRef, cleanData(messageData));
    return msgId;
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(
        error,
        OperationType.WRITE,
        `conversations/${params.conversationId}/messages/${msgId}`
      );
    } else {
      console.warn(`Message write notice:`, error);
    }
    return msgId;
  }
}

export async function updateConversationStatus(conversationId: string, status: Conversation['status']): Promise<void> {
  const path = `conversations/${conversationId}`;
  try {
    await updateDoc(doc(db, 'conversations', conversationId), {
      status,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    } else {
      console.warn(`Conversation update note for ${path}:`, error);
    }
  }
}

export function subscribeCustomers(callback: (customers: CustomerProfile[]) => void) {
  const path = 'customers';
  try {
    return onSnapshot(
      collection(db, 'customers'),
      (snapshot) => {
        const custs: CustomerProfile[] = [];
        snapshot.forEach((docSnap) => {
          custs.push({ id: docSnap.id, ...(docSnap.data() as Omit<CustomerProfile, 'id'>) });
        });
        callback(custs);
      },
      (error) => {
        if (isPermissionError(error)) {
          handleFirestoreError(error, OperationType.LIST, path);
        } else {
          console.info(`Firestore notice for ${path}: offline mode active`);
        }
      }
    );
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
    return () => {};
  }
}

export async function saveCustomerProfile(customer: CustomerProfile): Promise<void> {
  const path = `customers/${customer.id}`;
  try {
    await setDoc(doc(db, 'customers', customer.id), customer);
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.WRITE, path);
    } else {
      console.warn(`Customer write note for ${path}:`, error);
    }
  }
}

export async function toggleCustomerActive(customerId: string, isActive: boolean): Promise<void> {
  const path = `customers/${customerId}`;
  try {
    await updateDoc(doc(db, 'customers', customerId), { isActive });
  } catch (error) {
    if (isPermissionError(error)) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    } else {
      console.warn(`Customer toggle note for ${path}:`, error);
    }
  }
}
