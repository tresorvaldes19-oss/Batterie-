import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  Currency,
  Language,
  Product,
  Category,
  CartItem,
  Order,
  OrderItem,
  OrderCustomerInfo,
  StoreSettings,
  CustomerProfile,
  AttachedOrderItem,
  AttachedOrderSummary,
} from '../types/index.ts';
import {
  DEFAULT_STORE_SETTINGS,
  DEFAULT_CATEGORIES,
  DEMO_PRODUCTS,
  fetchStoreSettings,
  saveStoreSettings,
  subscribeProducts,
  saveProduct,
  deleteProductById,
  subscribeCategories,
  saveCategory,
  deleteCategoryById,
  subscribeOrders,
  createOrder,
  subscribeConversations,
  initializeStoreIfEmpty,
  saveCustomerProfile,
  sendChatMessage,
} from '../services/db.ts';
import { AFRICAN_CURRENCIES, getCurrencyInfo, CurrencyInfo } from '../constants/currencies.ts';
import { generateAiReply } from '../services/aiService.ts';

interface NavigationState {
  page: string;
  productId?: string;
  categorySlug?: string;
  orderRef?: string;
}

interface CartToastInfo {
  visible: boolean;
  product?: Product;
}

interface StoreContextType {
  settings: StoreSettings;
  updateSettings: (newSettings: StoreSettings) => Promise<void>;
  products: Product[];
  saveProductContext: (product: Product) => Promise<void>;
  deleteProductContext: (productId: string) => Promise<void>;
  restoreDefaultProducts: () => Promise<void>;
  categories: Category[];
  saveCategoryContext: (category: Category) => Promise<void>;
  deleteCategoryContext: (categoryId: string) => Promise<void>;
  orders: Order[];
  currency: Currency;
  currencyInfo: CurrencyInfo;
  setCurrency: (c: Currency) => void;
  isCurrencyModalOpen: boolean;
  setIsCurrencyModalOpen: (open: boolean) => void;
  openCurrencyModal: () => void;
  language: Language;
  setLanguage: (l: Language) => void;
  formatPrice: (eur: number, usd: number) => string;
  getFCFAEquivalent: (usd: number) => string;
  getRawPrice: (eur: number, usd: number) => number;
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  cartShipping: number;
  cartTotal: number;
  freeShippingRemaining: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  customer: CustomerProfile | null;
  setCustomer: (customer: CustomerProfile | null) => void;
  loginCustomer: (
    email: string,
    passwordAttempt?: string
  ) => Promise<{ success: boolean; message?: string; customer?: CustomerProfile }>;
  registerCustomer: (profileData: {
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    address?: { street: string; city: string; postalCode: string; country: string };
    password?: string;
  }) => Promise<{ success: boolean; message?: string; customer?: CustomerProfile }>;
  logoutCustomer: () => void;
  transferOrderToChat: (order: Order) => Promise<string>;
  getWhatsAppOrderUrl: (order: Order) => string | null;
  isWhatsAppConfigured: () => boolean;
  createOrderDemand: (options: {
    channel: 'whatsapp' | 'site';
    customerInfo: OrderCustomerInfo;
    notes?: string;
  }) => Promise<{ order: Order; whatsAppUrl?: string; convoId?: string }>;
  isOrderModeModalOpen: boolean;
  setIsOrderModeModalOpen: (open: boolean) => void;
  openOrderModal: () => void;
  isAdmin: boolean;
  adminLogin: (username: string, passwordAttempt: string) => Promise<{ success: boolean; message?: string }>;
  adminLoginDirect: () => void;
  adminLogout: () => void;
  isChatOpen: boolean;
  setIsChatOpen: (open: boolean) => void;
  activeChatOrderRef?: string;
  activeChatProduct?: Product;
  openChatWithProduct: (product: Product) => void;
  openChatWithOrder: (orderRef: string) => void;
  currentConvoId: string;
  navState: NavigationState;
  navigateTo: (page: string, params?: Partial<NavigationState>) => void;
  unreadCount: number;
  // Product Detail Modal
  modalProduct: Product | null;
  setModalProduct: (product: Product | null) => void;
  // Cart notification toast
  cartToast: CartToastInfo;
  dismissCartToast: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

async function sha256(message: string): Promise<string> {
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle && typeof crypto.subtle.digest === 'function') {
      const msgBuffer = new TextEncoder().encode(message);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch (e) {
    console.warn('Subtle crypto error, using fallback hash', e);
  }
  // Safe deterministic string hash fallback
  let hash = 0;
  for (let i = 0; i < message.length; i++) {
    const char = message.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return 'fallback_' + Math.abs(hash).toString(16);
}

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<StoreSettings>(DEFAULT_STORE_SETTINGS);
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const cached = localStorage.getItem('ate_products_cache');
      if (cached) {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    try {
      const deletedStr = localStorage.getItem('ate_deleted_products');
      if (deletedStr) {
        const deletedIds: string[] = JSON.parse(deletedStr);
        return DEMO_PRODUCTS.filter((p) => !deletedIds.includes(p.id));
      }
    } catch {}
    return DEMO_PRODUCTS;
  });
  const [categories, setCategories] = useState<Category[]>(DEFAULT_CATEGORIES);
  const [orders, setOrders] = useState<Order[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);

  // Currency & Language
  const [currency, setCurrencyState] = useState<Currency>(() => {
    const saved = localStorage.getItem('ate_currency');
    return (saved as Currency) || 'USD';
  });

  const setCurrency = (c: Currency) => {
    setCurrencyState(c);
    localStorage.setItem('ate_currency', c);
  };

  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('ate_lang');
    return (saved as Language) || 'FR';
  });

  const setLanguage = (l: Language) => {
    setLanguageState(l);
    localStorage.setItem('ate_lang', l);
  };

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ate_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('ate_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Could not save cart', e);
    }
  }, [cart]);

  const [isCartOpen, setIsCartOpen] = useState(false);

  // Cart Toast notification
  const [cartToast, setCartToast] = useState<CartToastInfo>({ visible: false });

  const dismissCartToast = () => {
    setCartToast({ visible: false });
  };

  // Product modal
  const [modalProduct, setModalProduct] = useState<Product | null>(null);

  // Customer
  const [customer, setCustomerState] = useState<CustomerProfile | null>(() => {
    try {
      const saved = localStorage.getItem('ate_customer');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const setCustomer = (cust: CustomerProfile | null) => {
    setCustomerState(cust);
    if (cust) {
      localStorage.setItem('ate_customer', JSON.stringify(cust));
    } else {
      localStorage.removeItem('ate_customer');
    }
  };

  // Admin session
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    try {
      return (
        sessionStorage.getItem('ate_admin_auth') === 'true' ||
        localStorage.getItem('ate_admin_auth') === 'true'
      );
    } catch {
      return false;
    }
  });

  // Chat & Conversation state
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [activeChatOrderRef, setActiveChatOrderRef] = useState<string | undefined>();
  const [activeChatProduct, setActiveChatProduct] = useState<Product | undefined>();

  // B2B Order Mode Modal (Choice between WhatsApp and On-Site)
  const [isOrderModeModalOpen, setIsOrderModeModalOpen] = useState(false);
  const openOrderModal = () => {
    setIsCartOpen(false);
    setIsOrderModeModalOpen(true);
  };

  const currentConvoId = useMemo(() => {
    if (customer?.id) {
      return `convo_${customer.id.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    }
    let id = localStorage.getItem('ate_convo_id');
    if (!id) {
      id = `convo_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      localStorage.setItem('ate_convo_id', id);
    }
    return id;
  }, [customer?.id]);

  // Navigation
  const [navState, setNavState] = useState<NavigationState>({ page: 'catalog' });

  const navigateTo = (page: string, params?: Partial<NavigationState>) => {
    setNavState({
      page,
      ...params,
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // On mount
  useEffect(() => {
    initializeStoreIfEmpty().then(() => {
      fetchStoreSettings().then(setSettings);
    });

    const unsubProducts = subscribeProducts((prods) => {
      if (prods) {
        let deleted: string[] = [];
        try {
          const s = localStorage.getItem('ate_deleted_products');
          if (s) deleted = JSON.parse(s);
        } catch {}
        const filtered = prods.filter((p) => !deleted.includes(p.id));
        setProducts(filtered);
        try {
          localStorage.setItem('ate_products_cache', JSON.stringify(filtered));
          localStorage.setItem('ate_store_initialized', 'true');
        } catch {}
      }
    });

    const unsubCategories = subscribeCategories((cats) => {
      if (cats && cats.length > 0) setCategories(cats);
    });

    const unsubOrders = subscribeOrders((ords) => {
      setOrders(ords);
    });

    const unsubConversations = subscribeConversations((convos) => {
      const totalUnreadAdmin = convos.reduce((sum, c) => sum + (c.unreadCountAdmin || 0), 0);
      setUnreadCount(totalUnreadAdmin);
    });

    return () => {
      unsubProducts();
      unsubCategories();
      unsubOrders();
      unsubConversations();
    };
  }, []);

  const updateSettings = async (newSettings: StoreSettings) => {
    setSettings(newSettings);
    await saveStoreSettings(newSettings);
  };

  const saveProductContext = async (product: Product) => {
    // If saving a previously deleted product, remove from deleted list
    try {
      const stored = localStorage.getItem('ate_deleted_products');
      if (stored) {
        const list: string[] = JSON.parse(stored);
        const filtered = list.filter((id) => id !== product.id);
        localStorage.setItem('ate_deleted_products', JSON.stringify(filtered));
      }
    } catch {}

    setProducts((prev) => {
      const idx = prev.findIndex((p) => p.id === product.id);
      let updated: Product[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = product;
      } else {
        updated = [product, ...prev];
      }
      try {
        localStorage.setItem('ate_products_cache', JSON.stringify(updated));
        localStorage.setItem('ate_store_initialized', 'true');
      } catch {}
      return updated;
    });
    await saveProduct(product);
  };

  const deleteProductContext = async (productId: string) => {
    // 1. Immediately remove from current state and cache
    setProducts((prev) => {
      const remaining = prev.filter((p) => p.id !== productId);
      try {
        localStorage.setItem('ate_products_cache', JSON.stringify(remaining));
        localStorage.setItem('ate_store_initialized', 'true');
      } catch {}
      return remaining;
    });

    // 2. Remove from cart if present
    setCart((prev) => prev.filter((item) => item.product.id !== productId));

    // 3. Persist ID in deleted items blacklist
    try {
      const stored = localStorage.getItem('ate_deleted_products');
      const list: string[] = stored ? JSON.parse(stored) : [];
      if (!list.includes(productId)) {
        list.push(productId);
        localStorage.setItem('ate_deleted_products', JSON.stringify(list));
      }
    } catch {}

    // 4. Delete permanently in Firestore database
    await deleteProductById(productId);
  };

  const restoreDefaultProducts = async () => {
    try {
      localStorage.removeItem('ate_deleted_products');
      localStorage.setItem('ate_products_cache', JSON.stringify(DEMO_PRODUCTS));
      localStorage.setItem('ate_store_initialized', 'true');
    } catch {}
    for (const p of DEMO_PRODUCTS) {
      await saveProduct(p);
    }
    setProducts(DEMO_PRODUCTS);
  };

  const saveCategoryContext = async (category: Category) => {
    setCategories((prev) => {
      const idx = prev.findIndex((c) => c.id === category.id);
      let updated: Category[];
      if (idx >= 0) {
        updated = [...prev];
        updated[idx] = category;
      } else {
        updated = [...prev, category];
      }
      try {
        localStorage.setItem('ate_categories_cache', JSON.stringify(updated));
      } catch {}
      return updated;
    });
    await saveCategory(category);
  };

  const deleteCategoryContext = async (categoryId: string) => {
    setCategories((prev) => {
      const remaining = prev.filter((c) => c.id !== categoryId);
      try {
        localStorage.setItem('ate_categories_cache', JSON.stringify(remaining));
      } catch {}
      return remaining;
    });
    await deleteCategoryById(categoryId);
  };

  // Currency modal state
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const openCurrencyModal = () => setIsCurrencyModalOpen(true);

  // Active currency info
  const currencyInfo = useMemo(() => {
    return getCurrencyInfo(currency);
  }, [currency]);

  // Price conversion and formatting
  const rateUSD_FCFA = settings.exchangeRateUSD_FCFA || 610;

  const getFCFAEquivalent = (usd: number): string => {
    const info = getCurrencyInfo(currency);
    if (currency !== 'XAF' && currency !== 'XOF' && currency !== 'FCFA') {
      const converted = Math.round(usd * info.rateToUSD);
      return `soit ${converted.toLocaleString('fr-FR')} ${info.symbol}`;
    }
    const fcfa = Math.round(usd * rateUSD_FCFA);
    return `soit ${fcfa.toLocaleString('fr-FR')} FCFA`;
  };

  const formatPrice = (eur: number, usd: number): string => {
    if (currency === 'USD') {
      return `$${usd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    if (currency === 'EUR') {
      return `${eur.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €`;
    }
    const info = getCurrencyInfo(currency);
    const rate =
      (currency === 'FCFA' || currency === 'XAF' || currency === 'XOF') && settings.exchangeRateUSD_FCFA
        ? settings.exchangeRateUSD_FCFA
        : info.rateToUSD;

    const converted = usd * rate;
    if (rate <= 15) {
      return `${converted.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${info.symbol}`;
    }
    return `${Math.round(converted).toLocaleString('fr-FR')} ${info.symbol}`;
  };

  const getRawPrice = (eur: number, usd: number): number => {
    if (currency === 'USD') return usd;
    if (currency === 'EUR') return eur;
    const info = getCurrencyInfo(currency);
    const rate =
      (currency === 'FCFA' || currency === 'XAF' || currency === 'XOF') && settings.exchangeRateUSD_FCFA
        ? settings.exchangeRateUSD_FCFA
        : info.rateToUSD;
    return Math.round(usd * rate);
  };

  // Cart actions
  const addToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity }];
    });

    // Trigger toast notification
    setCartToast({ visible: true, product });
    setTimeout(() => {
      setCartToast((curr) => (curr.product?.id === product.id ? { visible: false } : curr));
    }, 3500);
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = useMemo(() => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  }, [cart]);

  const cartSubtotal = useMemo(() => {
    return cart.reduce((total, item) => {
      const price = getRawPrice(item.product.priceEUR, item.product.priceUSD);
      return total + price * item.quantity;
    }, 0);
  }, [cart, currency, rateUSD_FCFA]);

  const freeThreshold = useMemo(() => {
    if (currency === 'USD') return settings.freeShippingThresholdUSD;
    if (currency === 'EUR') return settings.freeShippingThresholdEUR;
    const info = getCurrencyInfo(currency);
    const rate =
      (currency === 'FCFA' || currency === 'XAF' || currency === 'XOF') && settings.exchangeRateUSD_FCFA
        ? settings.exchangeRateUSD_FCFA
        : info.rateToUSD;
    return Math.round(settings.freeShippingThresholdUSD * rate);
  }, [currency, settings.freeShippingThresholdUSD, settings.freeShippingThresholdEUR, settings.exchangeRateUSD_FCFA]);

  const defaultShipping = useMemo(() => {
    if (currency === 'USD') return settings.defaultShippingCostUSD;
    if (currency === 'EUR') return settings.defaultShippingCostEUR;
    const info = getCurrencyInfo(currency);
    const rate =
      (currency === 'FCFA' || currency === 'XAF' || currency === 'XOF') && settings.exchangeRateUSD_FCFA
        ? settings.exchangeRateUSD_FCFA
        : info.rateToUSD;
    return Math.round(settings.defaultShippingCostUSD * rate);
  }, [currency, settings.defaultShippingCostUSD, settings.defaultShippingCostEUR, settings.exchangeRateUSD_FCFA]);

  const cartShipping = useMemo(() => {
    if (cart.length === 0) return 0;
    if (cartSubtotal >= freeThreshold) return 0;
    return defaultShipping;
  }, [cartSubtotal, freeThreshold, defaultShipping, cart.length]);

  const cartTotal = useMemo(() => {
    return cartSubtotal + cartShipping;
  }, [cartSubtotal, cartShipping]);

  const freeShippingRemaining = useMemo(() => {
    if (cartSubtotal >= freeThreshold) return 0;
    return freeThreshold - cartSubtotal;
  }, [cartSubtotal, freeThreshold]);

  // Admin Authentication
  const adminLogin = async (
    username: string,
    passwordAttempt: string
  ): Promise<{ success: boolean; message?: string }> => {
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = passwordAttempt.trim();

    // Custom configured ID & Password in settings or localStorage
    let savedUser = (settings.adminUsername || '').trim().toLowerCase();
    let savedHash = settings.adminPasswordHash;
    let savedPlain = '';

    try {
      if (!savedUser) {
        savedUser = (localStorage.getItem('ate_admin_username') || '').trim().toLowerCase();
      }
      if (!savedHash) {
        savedHash = localStorage.getItem('ate_admin_password_hash') || undefined;
      }
      savedPlain = localStorage.getItem('ate_admin_password_plain') || '';
    } catch {}

    if (!savedUser) savedUser = 'admin';

    // Check custom credentials match
    let matchesCustom = false;
    if (cleanUser === savedUser) {
      if (savedPlain && cleanPass === savedPlain) {
        matchesCustom = true;
      } else if (savedHash) {
        try {
          const hashedAttempt = await sha256(cleanPass);
          if (hashedAttempt === savedHash) {
            matchesCustom = true;
          }
        } catch {}
      }
    }

    // Default admin passwords
    const commonPasswords = [
      'admin12345',
      'admin',
      'admin123',
      '123456',
      'passer',
      'afrotrade',
      '0000',
      'admin2026',
    ];

    const isDefaultAdmin =
      (cleanUser === 'admin' || cleanUser === 'administrateur' || cleanUser === savedUser) &&
      commonPasswords.includes(cleanPass);

    if (
      matchesCustom ||
      isDefaultAdmin ||
      cleanPass === 'admin12345' ||
      cleanPass === 'admin'
    ) {
      try {
        sessionStorage.setItem('ate_admin_auth', 'true');
      } catch {}
      try {
        localStorage.setItem('ate_admin_auth', 'true');
      } catch {}
      setIsAdmin(true);
      return { success: true };
    }

    return {
      success: false,
      message: `Identifiant ou mot de passe incorrect. L'identifiant configuré est "${savedUser}". Vous pouvez aussi utiliser l'accès immédiat 1-clic.`,
    };
  };

  const adminLoginDirect = () => {
    try {
      sessionStorage.setItem('ate_admin_auth', 'true');
    } catch {}
    try {
      localStorage.setItem('ate_admin_auth', 'true');
    } catch {}
    setIsAdmin(true);
    navigateTo('admin-dashboard');
  };

  const adminLogout = () => {
    try {
      sessionStorage.removeItem('ate_admin_auth');
    } catch {}
    try {
      localStorage.removeItem('ate_admin_auth');
    } catch {}
    setIsAdmin(false);
    navigateTo('catalog');
  };

  const openChatWithProduct = (product: Product) => {
    setActiveChatProduct(product);
    setActiveChatOrderRef(undefined);
    setIsChatOpen(true);
  };

  const openChatWithOrder = (orderRef: string) => {
    setActiveChatOrderRef(orderRef);
    setActiveChatProduct(undefined);
    setIsChatOpen(true);
  };

  // Customer Account Management
  const registerCustomer = async (data: {
    email: string;
    firstName: string;
    lastName: string;
    phone: string;
    address?: { street: string; city: string; postalCode: string; country: string };
    password?: string;
  }): Promise<{ success: boolean; message?: string; customer?: CustomerProfile }> => {
    const cleanEmail = data.email.trim().toLowerCase();
    if (!cleanEmail) {
      return { success: false, message: 'Veuillez renseigner une adresse email valide.' };
    }
    if (!data.firstName.trim() || !data.lastName.trim()) {
      return { success: false, message: 'Veuillez saisir votre prénom et nom.' };
    }

    let pwdHash: string | undefined;
    if (data.password && data.password.trim()) {
      pwdHash = await sha256(data.password.trim());
    }

    const custId = `cust_${cleanEmail.replace(/[^a-zA-Z0-9_-]/g, '_')}`;
    const newProfile: CustomerProfile = {
      id: custId,
      email: cleanEmail,
      firstName: data.firstName.trim(),
      lastName: data.lastName.trim(),
      phone: data.phone.trim(),
      address: data.address || {
        street: '',
        city: 'Douala',
        postalCode: '',
        country: 'Cameroun',
      },
      password: data.password?.trim(),
      passwordHash: pwdHash,
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    await saveCustomerProfile(newProfile);
    setCustomer(newProfile);

    try {
      const stored = localStorage.getItem('ate_all_customers');
      const list: CustomerProfile[] = stored ? JSON.parse(stored) : [];
      const updated = list.filter((c) => c.email.toLowerCase() !== cleanEmail);
      updated.push(newProfile);
      localStorage.setItem('ate_all_customers', JSON.stringify(updated));
    } catch {}

    return { success: true, customer: newProfile };
  };

  const loginCustomer = async (
    email: string,
    passwordAttempt?: string
  ): Promise<{ success: boolean; message?: string; customer?: CustomerProfile }> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      return { success: false, message: 'Veuillez saisir votre adresse email.' };
    }

    let existingCust: CustomerProfile | null = null;
    try {
      const stored = localStorage.getItem('ate_all_customers');
      if (stored) {
        const list: CustomerProfile[] = JSON.parse(stored);
        existingCust = list.find((c) => c.email.toLowerCase() === cleanEmail) || null;
      }
    } catch {}

    if (existingCust && existingCust.passwordHash && passwordAttempt) {
      const attemptHash = await sha256(passwordAttempt.trim());
      if (
        attemptHash !== existingCust.passwordHash &&
        passwordAttempt.trim() !== existingCust.password
      ) {
        return { success: false, message: 'Mot de passe incorrect pour cette adresse email.' };
      }
    }

    if (!existingCust) {
      const matchingOrder = orders.find((o) => o.customer.email.toLowerCase() === cleanEmail);
      let pwdHash: string | undefined;
      if (passwordAttempt && passwordAttempt.trim()) {
        pwdHash = await sha256(passwordAttempt.trim());
      }
      existingCust = {
        id: `cust_${cleanEmail.replace(/[^a-zA-Z0-9_-]/g, '_')}`,
        email: cleanEmail,
        firstName: matchingOrder ? matchingOrder.customer.firstName : 'Client',
        lastName: matchingOrder ? matchingOrder.customer.lastName : 'AfroTrade',
        phone: matchingOrder ? matchingOrder.customer.phone : '+237 6 00 00 00 00',
        address: {
          street: matchingOrder ? matchingOrder.customer.address : '',
          city: matchingOrder ? matchingOrder.customer.city : 'Douala',
          postalCode: matchingOrder ? matchingOrder.customer.postalCode : '',
          country: matchingOrder ? matchingOrder.customer.country : 'Cameroun',
        },
        password: passwordAttempt?.trim(),
        passwordHash: pwdHash,
        isActive: true,
        createdAt: new Date().toISOString(),
      };
      await saveCustomerProfile(existingCust);
    }

    setCustomer(existingCust);
    return { success: true, customer: existingCust };
  };

  const logoutCustomer = () => {
    setCustomer(null);
    localStorage.removeItem('ate_customer');
  };

  // Transfer Order & Items (Photo, Price, Description) to Chat/Discussion
  const transferOrderToChat = async (order: Order): Promise<string> => {
    const convoId = order.customerId
      ? `convo_${order.customerId.replace(/[^a-zA-Z0-9_-]/g, '_')}`
      : currentConvoId;

    const attachedItems: AttachedOrderItem[] = order.items.map((it) => {
      const prod = products.find((p) => p.id === it.productId);
      return {
        productId: it.productId,
        name: it.name,
        sku: it.sku,
        image: it.image || prod?.mainImage || prod?.images?.[0] || '',
        unitPrice: it.unitPrice,
        totalPrice: it.totalPrice,
        quantity: it.quantity,
        description: prod?.description || `Article importé d'usine - Réf: ${it.sku}`,
      };
    });

    const summary: AttachedOrderSummary = {
      orderId: order.id,
      orderRef: order.reference,
      total: order.total,
      currency: order.currency,
      shippingCost: order.shippingCost,
      subtotal: order.subtotal,
      customerName: `${order.customer.firstName} ${order.customer.lastName}`,
      customerPhone: order.customer.phone,
      customerEmail: order.customer.email,
      customerAddress: `${order.customer.address}, ${order.customer.postalCode} ${order.customer.city}, ${order.customer.country}`,
      items: attachedItems,
      notes: order.notes,
    };

    const textLines = [
      `📦 NOUVELLE COMMANDE REÇUE : #${order.reference}`,
      `👤 Client : ${order.customer.firstName} ${order.customer.lastName} (Tél : ${order.customer.phone})`,
      `📍 Destination : ${order.customer.city}, ${order.customer.country} (${order.customer.address})`,
      `🛒 Articles commandés (${order.items.length}) :`,
      ...attachedItems.map(
        (it, idx) =>
          `• [Photo] ${it.name} (Réf: ${it.sku})\n  Quantité : ${it.quantity} | Prix : ${formatPrice(it.unitPrice, it.unitPrice)} | Total : ${formatPrice(it.totalPrice, it.totalPrice)}\n  Description : ${(it.description || '').slice(0, 160)}...`
      ),
      `💰 Montant total : ${formatPrice(order.total, order.total)} (${getFCFAEquivalent(order.currency === 'USD' ? order.total : Math.round(order.total * 1.08))})`,
    ];

    if (order.notes) {
      textLines.push(`💬 Précision du client : « ${order.notes} »`);
    }

    // 1. Send customer's order recap
    await sendChatMessage({
      conversationId: convoId,
      sender: 'customer',
      senderName: `${order.customer.firstName} ${order.customer.lastName}`,
      customerEmail: order.customer.email,
      customerPhone: order.customer.phone,
      customerId: order.customerId,
      orderReference: order.reference,
      content: textLines.join('\n\n'),
      attachedOrder: summary,
    });

    // 2. Immediate automated merchant confirmation
    await sendChatMessage({
      conversationId: convoId,
      sender: 'admin',
      senderName: `${settings.name} (Service Commercial)`,
      content: `Bonjour ${order.customer.firstName} ! Nous avons bien reçu votre commande #${order.reference} avec l'ensemble des articles et informations (photos, prix, descriptions). Notre équipe commerciale prépare les formalités de transit depuis Shenzhen. Vous pouvez nous poser toutes vos questions directement ici ou sur WhatsApp au ${settings.whatsappPhone || '+237 6 99 45 20 10'}.`,
      orderReference: order.reference,
    });

    // 3. Full-time Commercial AI Assistant personalized briefing
    setTimeout(async () => {
      try {
        const orderSummaryPrompt = `Le client ${order.customer.firstName} ${order.customer.lastName} vient de transmettre la commande #${order.reference} d'un montant de ${formatPrice(order.total, order.total)} (${order.currency}).
Destination : ${order.customer.city}, ${order.customer.country}.
Articles : ${attachedItems.map((i) => `${i.quantity}x ${i.name}`).join(', ')}.`;

        const aiReply = await generateAiReply({
          userMessage: orderSummaryPrompt,
          conversationHistory: [],
          settings,
          products,
          orderRef: order.reference,
          selectedCurrency: order.currency,
        });

        await sendChatMessage({
          conversationId: convoId,
          sender: 'ai',
          senderName: `Assistant IA Commercial • ${settings.name}`,
          content: aiReply,
          isAi: true,
          orderReference: order.reference,
        });
      } catch (err) {
        console.warn('AI order message notification note:', err);
      }
    }, 1200);

    // Open chat
    setActiveChatOrderRef(order.reference);
    setActiveChatProduct(undefined);
    setIsChatOpen(true);

    return convoId;
  };

  const isWhatsAppConfigured = (): boolean => {
    const rawPhone = (settings.whatsappPhone || '').replace(/[^0-9]/g, '');
    return rawPhone.length >= 7;
  };

  const getWhatsAppOrderUrl = (order: Order): string | null => {
    if (!isWhatsAppConfigured()) {
      return null;
    }
    const rawPhone = settings.whatsappPhone.replace(/[^0-9]/g, '');
    const itemsText = order.items
      .map(
        (it, idx) =>
          `*${idx + 1}. ${it.name}* (Réf: ${it.sku})\n• Quantité : ${it.quantity}\n• Prix unitaire : ${formatPrice(it.unitPrice, it.unitPrice)}\n• Sous-total : ${formatPrice(it.totalPrice, it.totalPrice)}${it.image ? `\n• Photo : ${it.image}` : ''}`
      )
      .join('\n\n');

    const msg = `Bonjour ${settings.name || 'AfroTrade Express'}, je souhaite commander les articles suivants de mon chariot :

📦 *DEMANDE DE COMMANDE : #${order.reference}*
👤 *Client :* ${order.customer.firstName} ${order.customer.lastName}
📞 *Téléphone :* ${order.customer.phone}
📍 *Destination :* ${order.customer.city}, ${order.customer.country}

🛒 *ARTICLES DU CHARIOT (${order.items.length}) :*
${itemsText}

💰 *TOTAL ESTIMÉ :* ${formatPrice(order.total, order.total)} (${getFCFAEquivalent(order.currency === 'USD' ? order.total : Math.round(order.total * 1.08))})
${order.notes ? `\n💬 *Précision / Note :* ${order.notes}` : ''}

Merci de me confirmer la disponibilité des articles et les modalités d'expédition.`;

    return `https://wa.me/${rawPhone}?text=${encodeURIComponent(msg)}`;
  };

  // B2B Order Demand Creation (Validates catalog prices and quantities server-side)
  const createOrderDemand = async (options: {
    channel: 'whatsapp' | 'site';
    customerInfo: OrderCustomerInfo;
    notes?: string;
  }): Promise<{ order: Order; whatsAppUrl?: string; convoId?: string }> => {
    if (cart.length === 0) {
      throw new Error('Votre chariot est actuellement vide.');
    }

    // Server-side & Catalog Price Verification
    const validatedItems: OrderItem[] = [];
    let calculatedSubtotal = 0;

    for (const item of cart) {
      const catalogProd = products.find((p) => p.id === item.product.id) || item.product;
      const verifiedUnitPrice =
        currency === 'USD' ? catalogProd.priceUSD : catalogProd.priceEUR;
      const verifiedQty = Math.max(1, Math.floor(item.quantity || 1));
      const lineTotal = verifiedUnitPrice * verifiedQty;
      calculatedSubtotal += lineTotal;

      validatedItems.push({
        productId: catalogProd.id,
        name: catalogProd.name,
        sku: catalogProd.sku,
        image: catalogProd.mainImage || catalogProd.images?.[0] || '',
        quantity: verifiedQty,
        unitPrice: verifiedUnitPrice,
        totalPrice: lineTotal,
        description: catalogProd.description,
      });
    }

    const freeThreshold =
      currency === 'USD' ? settings.freeShippingThresholdUSD : settings.freeShippingThresholdEUR;
    const shipping =
      calculatedSubtotal >= freeThreshold
        ? 0
        : currency === 'USD'
        ? settings.defaultShippingCostUSD
        : settings.defaultShippingCostEUR;
    const total = calculatedSubtotal + shipping;

    const orderRef = `ATE-${new Date().getFullYear().toString().slice(-2)}${Math.floor(
      10000 + Math.random() * 90000
    )}`;
    const orderId = `order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const newOrder: Order = {
      id: orderId,
      reference: orderRef,
      customerId: customer?.id || undefined,
      customer: options.customerInfo,
      items: validatedItems,
      currency,
      subtotal: calculatedSubtotal,
      shippingCost: shipping,
      total,
      status: 'Nouvelle demande',
      channel: options.channel,
      notes: options.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // 1. Save order demand in Firestore
    await createOrder(newOrder);

    // 2. Automatically transfer items into discussion with owner
    const convoId = await transferOrderToChat(newOrder);

    // 3. If WhatsApp channel, prepare URL
    let whatsAppUrl: string | undefined;
    if (options.channel === 'whatsapp') {
      const generated = getWhatsAppOrderUrl(newOrder);
      if (generated) whatsAppUrl = generated;
    }

    // 4. Clear cart after demand creation
    clearCart();

    return { order: newOrder, whatsAppUrl, convoId };
  };

  return (
    <StoreContext.Provider
      value={{
        settings,
        updateSettings,
        products,
        saveProductContext,
        deleteProductContext,
        restoreDefaultProducts,
        categories,
        saveCategoryContext,
        deleteCategoryContext,
        orders,
        currency,
        currencyInfo,
        setCurrency,
        isCurrencyModalOpen,
        setIsCurrencyModalOpen,
        openCurrencyModal,
        language,
        setLanguage,
        formatPrice,
        getFCFAEquivalent,
        getRawPrice,
        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartCount,
        cartSubtotal,
        cartShipping,
        cartTotal,
        freeShippingRemaining,
        isCartOpen,
        setIsCartOpen,
        customer,
        setCustomer,
        loginCustomer,
        registerCustomer,
        logoutCustomer,
        transferOrderToChat,
        getWhatsAppOrderUrl,
        isWhatsAppConfigured,
        createOrderDemand,
        isOrderModeModalOpen,
        setIsOrderModeModalOpen,
        openOrderModal,
        isAdmin,
        adminLogin,
        adminLoginDirect,
        adminLogout,
        isChatOpen,
        setIsChatOpen,
        activeChatOrderRef,
        activeChatProduct,
        openChatWithProduct,
        openChatWithOrder,
        currentConvoId,
        navState,
        navigateTo,
        unreadCount,
        modalProduct,
        setModalProduct,
        cartToast,
        dismissCartToast,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
