export type Currency =
  | 'USD'
  | 'EUR'
  | 'FCFA'
  | 'XAF'
  | 'XOF'
  | 'CDF'
  | 'NGN'
  | 'GHS'
  | 'KES'
  | 'ZAR'
  | 'MAD'
  | 'DZD'
  | 'TND'
  | 'EGP'
  | 'RWF'
  | 'UGX'
  | 'TZS'
  | 'ETB'
  | 'GNF'
  | 'MGA'
  | 'AOA'
  | 'MZN'
  | 'ZMW'
  | 'BWP'
  | 'NAD'
  | 'MRU'
  | 'SCR'
  | 'MUR'
  | 'KMF'
  | 'DJF'
  | 'SOS'
  | 'SLE'
  | 'LRD'
  | 'GMD'
  | 'CVE'
  | 'STN'
  | 'LYD'
  | 'SSP'
  | 'SDG'
  | 'ERN'
  | 'BIF'
  | 'MWK'
  | 'LSL'
  | 'SZL'
  | (string & {});

export type Language = 'FR' | 'EN' | 'AR';

export type ProductStatus = 'disponible' | 'indisponible' | 'brouillon' | 'archive';

export interface Product {
  id: string;
  name: string;
  sku: string;
  description: string;
  category: string;
  priceEUR: number;
  priceUSD: number;
  oldPriceUSD?: number;
  stock: number;
  status: ProductStatus;
  images: string[];
  mainImage: string;
  characteristics: string[];
  specifications: Record<string, string>;
  featured?: boolean;
  rating?: number;
  reviewsCount?: number;
  badge?: 'Nouveau' | 'Promotion' | 'Stock limité' | 'Import direct' | 'Top Vente';
  origin?: string;
  transitAirDays?: string;
  transitSeaDays?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus =
  | 'Nouvelle demande'
  | 'En discussion'
  | 'Confirmée'
  | 'Terminée'
  | 'Nouvelle'
  | 'En préparation'
  | 'Expédiée'
  | 'Livrée'
  | 'Annulée'
  | 'Remboursée';

export interface OrderCustomerInfo {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  sku: string;
  image: string;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  description?: string;
}

export interface Order {
  id: string;
  reference: string;
  customerId?: string;
  customer: OrderCustomerInfo;
  items: OrderItem[];
  currency: Currency;
  subtotal: number;
  shippingCost: number;
  total: number;
  status: OrderStatus;
  channel?: 'whatsapp' | 'site';
  notes?: string;
  internalNote?: string;
  createdAt: string;
  updatedAt: string;
}

export type ConversationStatus =
  | 'en_attente'
  | 'nouveau'
  | 'en_cours'
  | 'repondu'
  | 'ferme';

export interface AttachedOrderItem {
  productId: string;
  name: string;
  sku: string;
  image: string;
  unitPrice: number;
  totalPrice: number;
  quantity: number;
  description?: string;
}

export interface AttachedOrderSummary {
  orderId: string;
  orderRef: string;
  total: number;
  currency: Currency;
  shippingCost: number;
  subtotal: number;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  customerAddress: string;
  items: AttachedOrderItem[];
  notes?: string;
}

export interface Conversation {
  id: string;
  customerId?: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  subject?: string;
  status: ConversationStatus;
  orderReference?: string;
  productId?: string;
  productName?: string;
  lastMessage: string;
  unreadCountAdmin: number;
  unreadCountCustomer: number;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  sender: 'customer' | 'admin' | 'system' | 'ai';
  senderName: string;
  content: string;
  attachedOrderRef?: string;
  attachedProductId?: string;
  attachedProductName?: string;
  attachedOrder?: AttachedOrderSummary;
  read: boolean;
  createdAt: string;
  isAi?: boolean;
}

export interface CustomerProfile {
  id: string;
  uid?: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  address?: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
  };
  password?: string;
  passwordHash?: string;
  isActive: boolean;
  createdAt: string;
}

export interface StoreSettings {
  id: string;
  name: string;
  tagline: string;
  description: string;
  logoUrl: string;
  primaryColor: string;
  email: string;
  phone: string;
  whatsappPhone: string;
  address: string;
  openingHours: string;
  socialLinks: {
    instagram?: string;
    facebook?: string;
    whatsapp?: string;
    tiktok?: string;
  };
  deliveryNotice: string;
  promoBannerText: string;
  promoBannerEnabled: boolean;
  freeShippingThresholdEUR: number;
  freeShippingThresholdUSD: number;
  defaultShippingCostEUR: number;
  defaultShippingCostUSD: number;
  exchangeRateUSD_FCFA: number; // e.g. 610
  termsAndConditions: string;
  privacyPolicy: string;
  shippingInfo: string;
  returnsInfo: string;
  adminUsername: string;
  adminPasswordHash?: string;

  // AI Assistant & Unavailability Responder Configuration
  aiAssistantEnabled?: boolean;
  aiMode?: 'chat' | 'unavailability_only';
  aiUnavailabilityMessage?: string;
  aiCustomSystemPrompt?: string;
  aiResponseDelaySeconds?: number;

  // Editable Homepage Contents & Logistics Highlights
  heroTitle?: string;
  heroSubtitle?: string;
  heroImageUrl?: string;
  heroBadge?: string;
  logisticAirTitle?: string;
  logisticAirDesc?: string;
  logisticSeaTitle?: string;
  logisticSeaDesc?: string;
  logisticQualityTitle?: string;
  logisticQualityDesc?: string;
}
