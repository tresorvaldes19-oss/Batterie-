import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { Conversation, Message, ConversationStatus } from '../../types/index.ts';
import {
  subscribeConversations,
  subscribeMessages,
  sendChatMessage,
  updateConversationStatus,
} from '../../services/db.ts';
import {
  MessageSquare,
  Search,
  Filter,
  Send,
  CheckCircle,
  Clock,
  Package,
  User,
  Check,
  CheckCheck,
  FolderOpen,
  FolderClosed,
  Phone,
  Mail,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  Bot,
  Sparkles,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { generateAiReply } from '../../services/aiService.ts';

export const AdminMessages: React.FC = () => {
  const { settings, orders, products, formatPrice, navigateTo } = useStore();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selectedConvoId, setSelectedConvoId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [replyText, setReplyText] = useState('');
  const [statusTab, setStatusTab] = useState<'all' | 'en_attente' | 'repondu' | 'ferme'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sending, setSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({});

  // Link order modal state
  const [linkingOrder, setLinkingOrder] = useState(false);
  const [orderToLink, setOrderToLink] = useState('');
  const [generatingAiSuggestion, setGeneratingAiSuggestion] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscribe to all conversations
  useEffect(() => {
    const unsub = subscribeConversations((convos) => {
      if (convos.length === 0) {
        // Seed default demo discussions for immediate testing if totally empty
        const sampleConvoId = 'convo_demo_moussa';
        const sampleOrderRef = 'ATE-26-84920';
        const sampleConvo: Conversation = {
          id: sampleConvoId,
          customerName: 'Moussa Traoré',
          customerEmail: 'moussa.traore@gmail.com',
          customerPhone: '+225 07 48 92 10 33',
          subject: `Commande transmise #${sampleOrderRef}`,
          status: 'en_attente',
          orderReference: sampleOrderRef,
          lastMessage: `Bonjour ! J'ai passé ma commande #${sampleOrderRef} pour 2 Smartphones Android et 1 perruque. Pouvez-vous me confirmer le délai pour Abidjan et si je peux payer le solde par Wave ?`,
          unreadCountAdmin: 1,
          unreadCountCustomer: 0,
          createdAt: new Date(Date.now() - 3600000).toISOString(),
          updatedAt: new Date().toISOString(),
        };

        const sampleMsg1: Message = {
          id: 'msg_demo_1',
          conversationId: sampleConvoId,
          sender: 'customer',
          senderName: 'Moussa Traoré',
          content: `Bonjour ! J'ai validé ma commande #${sampleOrderRef} d'un montant de 345 000 FCFA pour Abidjan. Pouvez-vous me confirmer si les articles sont bien en stock à Shenzhen et si je peux verser un acompte par Wave ? Merci !`,
          attachedOrderRef: sampleOrderRef,
          read: false,
          createdAt: new Date(Date.now() - 3600000).toISOString(),
        };

        const sampleMsg2: Message = {
          id: 'msg_demo_2',
          conversationId: sampleConvoId,
          sender: 'ai',
          senderName: `Assistant Virtuel IA • ${settings.name}`,
          content: `Bonjour Moussa ! Merci pour votre confiance pour votre commande #${sampleOrderRef} vers Abidjan.\n\n📦 Les articles sont bien en stock à notre entrepôt de Shenzhen et prêts pour le contrôle qualité.\n\n💳 Pour le paiement depuis la Côte d'Ivoire, nous acceptons parfaitement Wave et Orange Money avec la formule d'acompte à la commande puis le solde au retrait au dépôt d'Abidjan (Treichville/Yopougon).\n\nLe propriétaire du site a été alerté en direct et va vous transmettre les coordonnées de paiement dans ce fil de discussion !`,
          isAi: true,
          read: false,
          createdAt: new Date(Date.now() - 3500000).toISOString(),
        };

        try {
          localStorage.setItem('ate_conversations', JSON.stringify([sampleConvo]));
          localStorage.setItem(`ate_msgs_${sampleConvoId}`, JSON.stringify([sampleMsg1, sampleMsg2]));
        } catch {}

        setConversations([sampleConvo]);
        setSelectedConvoId(sampleConvoId);
      } else {
        setConversations(convos);
        setSelectedConvoId((prev) => {
          // If previous was the sample conversation and real conversations arrived, switch to real one
          if (prev === 'convo_sample_ci_001') {
            const realConvo = convos.find((c) => c.id !== 'convo_sample_ci_001');
            if (realConvo) return realConvo.id;
          }
          if (prev && convos.some((c) => c.id === prev)) return prev;
          const pending = convos.find((c) => c.status === 'en_attente' || c.status === 'nouveau');
          return pending ? pending.id : convos[0]?.id || null;
        });
      }
    });
    return () => unsub();
  }, [settings.name]);

  // Subscribe to messages in active conversation with smart optimistic merging
  useEffect(() => {
    if (!selectedConvoId) return;
    const unsub = subscribeMessages(selectedConvoId, (newMsgs) => {
      setMessages((prev) => {
        const map = new Map<string, Message>();
        newMsgs.forEach((m) => map.set(m.id, m));
        // Preserve any active optimistic admin messages until persisted
        prev.forEach((m) => {
          if (m.id.startsWith('msg-admin-opt-') || m.id.startsWith('msg-opt-')) {
            const alreadyStored = newMsgs.some(
              (nm) => nm.content === m.content && nm.sender === m.sender
            );
            if (!alreadyStored) {
              map.set(m.id, m);
            }
          }
        });
        return Array.from(map.values()).sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
      });
    });
    return () => unsub();
  }, [selectedConvoId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const selectedConvo = conversations.find((c) => c.id === selectedConvoId);

  const toggleExpand = (id: string) => {
    setExpandedOrders((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Counts
  const pendingCount = conversations.filter(
    (c) => c.status === 'en_attente' || c.status === 'nouveau'
  ).length;
  const repliedCount = conversations.filter((c) => c.status === 'repondu').length;
  const closedCount = conversations.filter((c) => c.status === 'ferme').length;

  // Filter conversations
  const filteredConvos = conversations.filter((c) => {
    // Current active selection should always remain visible to prevent disappearing when replied to!
    if (c.id === selectedConvoId) {
      return true;
    }
    if (statusTab === 'en_attente' && c.status !== 'en_attente' && c.status !== 'nouveau') {
      return false;
    }
    if (statusTab === 'repondu' && c.status !== 'repondu') {
      return false;
    }
    if (statusTab === 'ferme' && c.status !== 'ferme') {
      return false;
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = (c.customerName || '').toLowerCase().includes(q);
      const matchEmail = (c.customerEmail || '').toLowerCase().includes(q);
      const matchPhone = (c.customerPhone || '').includes(q);
      const matchLast = (c.lastMessage || '').toLowerCase().includes(q);
      const matchRef = (c.orderReference || '').toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchPhone && !matchLast && !matchRef) return false;
    }
    return true;
  });

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    const textToSend = replyText.trim();
    if (!selectedConvoId || !textToSend) return;

    // 1. INSTANT DIRECT VISIBILITY: Render admin reply immediately in the discussion window (0ms delay)
    const optimisticMsg: Message = {
      id: `msg-admin-opt-${Date.now()}`,
      conversationId: selectedConvoId,
      sender: 'admin',
      senderName: `${settings.name} (Service Commercial)`,
      content: textToSend,
      read: true,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, optimisticMsg]);
    setReplyText('');
    setSending(true);

    // Optimistically update conversation status in list
    setConversations((prev) =>
      prev.map((c) =>
        c.id === selectedConvoId
          ? {
              ...c,
              status: 'repondu',
              lastMessage: textToSend,
              unreadCountAdmin: 0,
              updatedAt: new Date().toISOString(),
            }
          : c
      )
    );

    try {
      await sendChatMessage({
        conversationId: selectedConvoId,
        sender: 'admin',
        senderName: `${settings.name} (Service Commercial)`,
        content: textToSend,
        customerEmail: selectedConvo?.customerEmail,
        customerPhone: selectedConvo?.customerPhone,
        orderReference: selectedConvo?.orderReference,
      });
    } catch (err) {
      console.error('Error replying:', err);
    } finally {
      setSending(false);
    }
  };

  const handleUpdateStatus = async (newStatus: ConversationStatus) => {
    if (!selectedConvo) return;
    await updateConversationStatus(selectedConvo.id, newStatus);
    setConversations((prev) =>
      prev.map((c) => (c.id === selectedConvo.id ? { ...c, status: newStatus } : c))
    );
  };

  const handleLinkOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConvo || !orderToLink.trim()) return;
    await sendChatMessage({
      conversationId: selectedConvo.id,
      sender: 'admin',
      senderName: `${settings.name}`,
      content: `[Information] La commande #${orderToLink.trim()} a été associée à cette discussion.`,
      orderReference: orderToLink.trim(),
    });
    setLinkingOrder(false);
    setOrderToLink('');
  };

  const handleGenerateAiSuggestion = async () => {
    if (!selectedConvo) return;
    setGeneratingAiSuggestion(true);
    try {
      const lastCust = [...messages].reverse().find((m) => m.sender === 'customer');
      const lastText = lastCust?.content || selectedConvo.lastMessage || 'Demande client';
      const suggestion = await generateAiReply({
        userMessage: lastText,
        conversationHistory: messages,
        settings,
        products,
        orderRef: selectedConvo.orderReference,
      });
      setReplyText(suggestion);
    } catch (err) {
      console.error('Error generating AI suggestion for admin:', err);
    } finally {
      setGeneratingAiSuggestion(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <span className="text-xs font-black uppercase tracking-wider text-[#F59E0B]">
            Service Client & Commandes Transférées
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
            Discussions Clients & Messages
          </h1>
          <p className="text-xs text-[#64748B] mt-0.5">
            Gérez directement les échanges clients sauvegardés avec le statut « En attente de l'administrateur ».
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="px-3.5 py-2 bg-[#EDE9FE] border border-[#DDD6FE] text-[#6D28D9] rounded-xl text-xs font-bold flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#7C3AED] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#6D28D9]"></span>
            </span>
            <Bot className="w-3.5 h-3.5 text-[#7C3AED]" />
            <span>IA Commerciale Active 24/7 (Temps Plein)</span>
          </div>

          {pendingCount > 0 && (
            <div className="px-4 py-2 bg-[#FEF3C7] border border-[#FDE68A] text-[#92400E] rounded-xl text-xs font-bold flex items-center gap-2 self-start sm:self-auto">
              <span className="w-2 h-2 rounded-full bg-[#D97706] animate-pulse" />
              <span>{pendingCount} discussion{pendingCount > 1 ? 's' : ''} en attente de votre réponse</span>
            </div>
          )}
        </div>
      </div>

      {/* Main split inbox container */}
      <div className="bg-white rounded-3xl border border-[#CBD5E1] shadow-md h-[720px] flex flex-col md:flex-row overflow-hidden">
        {/* Left column: Conversations list */}
        <div className={`w-full md:w-96 border-r border-[#E2E8F0] flex flex-col bg-[#F8FAFC] ${selectedConvoId ? 'hidden md:flex' : 'flex'}`}>
          {/* Status Tabs */}
          <div className="p-3 border-b border-[#E2E8F0] space-y-2">
            <div className="grid grid-cols-4 gap-1 p-1 bg-[#E2E8F0]/70 rounded-xl text-[10px] font-bold">
              <button
                type="button"
                onClick={() => setStatusTab('en_attente')}
                className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer ${
                  statusTab === 'en_attente'
                    ? 'bg-white text-[#B45309] shadow-2xs font-black'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <span>En attente</span>
                {pendingCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 rounded-full bg-[#F59E0B] text-[#0A2540] text-[9px]">
                    {pendingCount}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setStatusTab('all')}
                className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer ${
                  statusTab === 'all'
                    ? 'bg-white text-[#0A2540] shadow-2xs font-black'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <span>Toutes</span> ({conversations.length})
              </button>

              <button
                type="button"
                onClick={() => setStatusTab('repondu')}
                className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer ${
                  statusTab === 'repondu'
                    ? 'bg-white text-[#166534] shadow-2xs font-black'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <span>Répondues</span> ({repliedCount})
              </button>

              <button
                type="button"
                onClick={() => setStatusTab('ferme')}
                className={`py-1.5 px-1 rounded-lg text-center transition-all cursor-pointer ${
                  statusTab === 'ferme'
                    ? 'bg-white text-[#475569] shadow-2xs font-black'
                    : 'text-[#64748B] hover:text-[#0F172A]'
                }`}
              >
                <span>Fermées</span> ({closedCount})
              </button>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher nom, email, réf..."
                className="w-full pl-8 pr-3 py-1.5 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
              />
            </div>
          </div>

          {/* List items */}
          <div className="flex-1 overflow-y-auto divide-y divide-[#E2E8F0]">
            {filteredConvos.length === 0 ? (
              <div className="p-8 text-center text-xs text-[#94A3B8]">
                Aucune discussion dans cette catégorie.
              </div>
            ) : (
              filteredConvos.map((convo) => {
                const isSelected = convo.id === selectedConvoId;
                const isPending = convo.status === 'en_attente' || convo.status === 'nouveau';
                const hasUnread = (convo.unreadCountAdmin || 0) > 0;

                return (
                  <button
                    key={convo.id}
                    type="button"
                    onClick={() => setSelectedConvoId(convo.id)}
                    className={`w-full p-3.5 text-left transition-colors flex items-start gap-3 cursor-pointer ${
                      isSelected
                        ? 'bg-[#0A2540]/10 border-l-4 border-[#0A2540]'
                        : isPending
                        ? 'bg-[#FFFBEB]/40 hover:bg-[#FEF3C7]/40'
                        : 'hover:bg-[#F1F5F9]'
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs shrink-0 mt-0.5 ${
                        isPending ? 'bg-[#F59E0B] text-[#0A2540]' : 'bg-[#0A2540] text-white'
                      }`}
                    >
                      {convo.customerName?.charAt(0) || 'C'}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <p className="font-bold text-xs text-[#0F172A] truncate">
                          {convo.customerName}
                        </p>
                        <span className="text-[10px] text-[#94A3B8] shrink-0 font-medium">
                          {new Date(convo.updatedAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      <p className="text-[11px] text-[#64748B] truncate mt-0.5 line-clamp-1">
                        {convo.lastMessage || 'Nouvelle commande transmise'}
                      </p>

                      <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                        {isPending ? (
                          <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-[#FEF3C7] text-[#B45309] border border-[#FDE68A] flex items-center gap-1">
                            <Clock className="w-2.5 h-2.5 text-[#D97706] animate-pulse" />
                            <span>En attente admin</span>
                          </span>
                        ) : convo.status === 'repondu' ? (
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#DCFCE7] text-[#166534] flex items-center gap-1">
                            <Check className="w-2.5 h-2.5" />
                            <span>Répondu</span>
                          </span>
                        ) : convo.status === 'ferme' ? (
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#F1F5F9] text-[#64748B]">
                            Fermé
                          </span>
                        ) : (
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-[#EFF6FF] text-[#1D4ED8]">
                            En cours
                          </span>
                        )}

                        {convo.orderReference && (
                          <span className="text-[9px] font-mono font-bold text-[#0A2540] bg-[#0A2540]/10 px-1.5 py-0.5 rounded">
                            #{convo.orderReference}
                          </span>
                        )}

                        {hasUnread && (
                          <span className="ml-auto w-2.5 h-2.5 bg-[#EF4444] rounded-full animate-pulse" />
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right column: Chat history and reply view */}
        <div className={`flex-1 flex flex-col bg-white ${!selectedConvoId ? 'hidden md:flex' : 'flex'}`}>
          {selectedConvo ? (
            <>
              {/* Header inside thread */}
              <div className="p-4 sm:px-6 sm:py-3.5 border-b border-[#E2E8F0] flex flex-wrap items-center justify-between gap-3 bg-white">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setSelectedConvoId(null)}
                    className="md:hidden p-2 -ml-2 text-[#64748B] hover:text-[#0F172A] rounded-xl bg-[#F1F5F9] transition-colors cursor-pointer"
                    title="Retour aux discussions"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <div className="w-10 h-10 rounded-full bg-[#0A2540] text-[#F59E0B] flex items-center justify-center font-bold text-sm shrink-0">
                    {selectedConvo.customerName?.charAt(0) || 'C'}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-sm text-[#0F172A]">
                        {selectedConvo.customerName}
                      </h3>
                      {selectedConvo.orderReference && (
                        <span className="text-[10px] font-mono font-bold bg-[#FEF3C7] text-[#92400E] px-2 py-0.5 rounded-md">
                          Commande #{selectedConvo.orderReference}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-[#64748B]">
                      {selectedConvo.customerPhone && (
                        <span className="flex items-center gap-1 font-mono">
                          <Phone className="w-3 h-3 text-[#22C55E]" />
                          <span>{selectedConvo.customerPhone}</span>
                        </span>
                      )}
                      <span>•</span>
                      <span>{selectedConvo.customerEmail}</span>
                    </div>
                  </div>
                </div>

                {/* Status Switcher & Actions */}
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Status Dropdown */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-semibold text-[#64748B]">Statut :</span>
                    <select
                      value={selectedConvo.status}
                      onChange={(e) => handleUpdateStatus(e.target.value as ConversationStatus)}
                      className={`text-xs font-bold py-1.5 px-2.5 rounded-xl border cursor-pointer focus:outline-none ${
                        selectedConvo.status === 'en_attente' || selectedConvo.status === 'nouveau'
                          ? 'bg-[#FEF3C7] border-[#FDE68A] text-[#B45309]'
                          : selectedConvo.status === 'repondu'
                          ? 'bg-[#DCFCE7] border-[#86EFAC] text-[#166534]'
                          : selectedConvo.status === 'ferme'
                          ? 'bg-[#F1F5F9] border-[#CBD5E1] text-[#64748B]'
                          : 'bg-[#EFF6FF] border-[#BFDBFE] text-[#1D4ED8]'
                      }`}
                    >
                      <option value="en_attente">⏳ En attente de l'administrateur</option>
                      <option value="en_cours">💬 En cours</option>
                      <option value="repondu">✅ Répondu par l'admin</option>
                      <option value="ferme">📁 Fermé / Terminé</option>
                    </select>
                  </div>

                  {selectedConvo.customerPhone && (
                    <a
                      href={`https://wa.me/${selectedConvo.customerPhone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3 py-1.5 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      title="Contacter sur WhatsApp"
                    >
                      <span>WhatsApp</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => setLinkingOrder(!linkingOrder)}
                    className="px-3 py-1.5 border border-[#CBD5E1] rounded-lg text-xs font-bold text-[#334155] hover:bg-[#F1F5F9] flex items-center gap-1.5 cursor-pointer"
                    title="Lier une commande"
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">Lier commande</span>
                  </button>
                </div>
              </div>

              {/* Link Order Form bar if active */}
              {linkingOrder && (
                <form
                  onSubmit={handleLinkOrderSubmit}
                  className="bg-[#FEF3C7] px-6 py-2.5 border-b border-[#FDE68A] flex items-center gap-3 text-xs"
                >
                  <span className="font-bold text-[#92400E]">Numéro de commande à associer :</span>
                  <input
                    type="text"
                    required
                    value={orderToLink}
                    onChange={(e) => setOrderToLink(e.target.value)}
                    placeholder="Ex: ATE-261234"
                    className="px-3 py-1 bg-white border border-[#F59E0B] rounded-lg text-xs font-mono text-[#0F172A] focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-lg text-xs font-bold cursor-pointer"
                  >
                    Associer
                  </button>
                  <button
                    type="button"
                    onClick={() => setLinkingOrder(false)}
                    className="text-[#64748B] hover:text-[#0F172A] text-xs ml-auto cursor-pointer"
                  >
                    Annuler
                  </button>
                </form>
              )}

              {/* Messages Scroll Area */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#F8FAFC]">
                {messages.length === 0 ? (
                  <div className="text-center py-12 text-xs text-[#94A3B8]">
                    Début de la discussion avec {selectedConvo.customerName}.
                  </div>
                ) : (
                  messages.map((m) => {
                    const isAdminMsg = m.sender === 'admin';
                    const isAiMsg = m.sender === 'ai' || m.isAi === true;
                    const isSystem = m.sender === 'system' && !isAiMsg;
                    const isExpanded = !!expandedOrders[m.id];

                    if (isSystem) {
                      return (
                        <div key={m.id} className="text-center py-1">
                          <span className="text-[11px] bg-[#E2E8F0] text-[#475569] px-3 py-1 rounded-full inline-block">
                            {m.content}
                          </span>
                        </div>
                      );
                    }

                    if (isAiMsg) {
                      return (
                        <div key={m.id} className="flex flex-col items-start space-y-1 my-1">
                          <div className="max-w-[85%] sm:max-w-[78%] p-3.5 rounded-2xl text-xs leading-relaxed bg-[#EDE9FE] text-[#3B0764] rounded-tl-xs border border-[#C4B5FD] shadow-2xs">
                            <div className="flex items-center gap-1.5 text-[10px] font-black uppercase mb-1 tracking-wider text-[#6D28D9]">
                              <Bot className="w-3.5 h-3.5 text-[#7C3AED]" />
                              <span>Assistant Virtuel IA (Réponse en attente de l'admin)</span>
                            </div>
                            <p className="whitespace-pre-line">{m.content}</p>
                            <span className="block text-[10px] text-[#7C3AED]/70 mt-1.5 text-right font-mono">
                              {new Date(m.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          </div>
                        </div>
                      );
                    }

                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col ${isAdminMsg ? 'items-end' : 'items-start'} space-y-1`}
                      >
                        <div
                          className={`max-w-[85%] sm:max-w-[78%] p-4 rounded-2xl text-xs leading-relaxed ${
                            isAdminMsg
                              ? 'bg-[#0A2540] text-white rounded-tr-xs shadow-xs'
                              : 'bg-white text-[#0F172A] rounded-tl-xs border border-[#CBD5E1] shadow-2xs'
                          }`}
                        >
                          <span
                            className={`block text-[10px] font-black uppercase mb-1 tracking-wider ${
                              isAdminMsg ? 'text-[#F59E0B]' : 'text-[#D97706]'
                            }`}
                          >
                            {m.senderName}
                          </span>

                          {/* Rich Order Summary Card with Photos, Prices & Descriptions */}
                          {m.attachedOrder ? (
                            <div
                              className={`rounded-xl p-3.5 border mb-2 text-left ${
                                isAdminMsg
                                  ? 'bg-[#183E66] border-[#2E5B88] text-white'
                                  : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0F172A]'
                              }`}
                            >
                              <div className="flex items-center justify-between pb-2 border-b border-current/15 gap-2">
                                <div className="flex items-center gap-1.5 font-bold text-xs">
                                  <Package className="w-4 h-4 text-[#F59E0B] shrink-0" />
                                  <span>Commande transmise #{m.attachedOrder.orderRef}</span>
                                </div>
                                <span className="text-xs font-bold text-[#F59E0B]">
                                  {formatPrice(m.attachedOrder.total, m.attachedOrder.total)}
                                </span>
                              </div>

                              <div className="mt-2 text-[11px] opacity-85 space-y-0.5">
                                <p>
                                  Client : <strong>{m.attachedOrder.customerName}</strong> ({m.attachedOrder.customerPhone})
                                </p>
                                <p>Email : {m.attachedOrder.customerEmail}</p>
                                <p>Livraison : {m.attachedOrder.customerAddress}</p>
                              </div>

                              {/* Items list with images and description toggle */}
                              <div className="mt-3 space-y-2 border-t border-current/15 pt-2">
                                <div className="flex items-center justify-between text-[11px] font-bold opacity-90">
                                  <span>Articles du panier ({m.attachedOrder.items.length})</span>
                                  <button
                                    type="button"
                                    onClick={() => toggleExpand(m.id)}
                                    className="text-[10px] underline flex items-center gap-0.5 cursor-pointer"
                                  >
                                    <span>{isExpanded ? 'Réduire' : 'Afficher photos & descriptions'}</span>
                                    {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                                  </button>
                                </div>

                                <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                                  {m.attachedOrder.items.map((it, idx) => (
                                    <div
                                      key={idx}
                                      className={`p-2.5 rounded-lg flex items-start gap-3 ${
                                        isAdminMsg
                                          ? 'bg-[#0A2540]/60'
                                          : 'bg-white border border-[#E2E8F0]'
                                      }`}
                                    >
                                      <img
                                        src={it.image}
                                        alt={it.name}
                                        className="w-12 h-12 rounded-lg object-contain bg-white border border-current/10 shrink-0"
                                      />
                                      <div className="flex-1 min-w-0">
                                        <p className="font-bold text-xs truncate">{it.name}</p>
                                        <div className="flex items-center justify-between text-[11px] opacity-85 mt-0.5">
                                          <span>Réf: {it.sku} • Qté: {it.quantity}</span>
                                          <span className="font-bold text-[#F59E0B]">
                                            {formatPrice(it.totalPrice, it.totalPrice)}
                                          </span>
                                        </div>
                                        {isExpanded && it.description && (
                                          <p className="text-[10px] mt-1.5 opacity-80 leading-relaxed border-t border-current/10 pt-1">
                                            {it.description}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          ) : null}

                          <p className="whitespace-pre-line">{m.content}</p>

                          <div className="flex items-center justify-end gap-1 mt-1 text-[10px] opacity-75">
                            <span>
                              {new Date(m.createdAt).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                            {isAdminMsg && <CheckCheck className="w-3 h-3 text-[#F59E0B]" />}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Quick AI & African e-commerce templates */}
              <div className="px-4 py-2.5 border-t border-[#E2E8F0] bg-[#F8FAFC] flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={handleGenerateAiSuggestion}
                  disabled={generatingAiSuggestion}
                  className="px-3 py-1.5 bg-[#EDE9FE] hover:bg-[#DDD6FE] text-[#6D28D9] border border-[#C4B5FD] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                  title="Générer une réponse commerciale assistée par IA pour ce client"
                >
                  {generatingAiSuggestion ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5 text-[#7C3AED]" />
                  )}
                  <span>{generatingAiSuggestion ? 'Génération IA...' : 'Suggérer réponse avec IA'}</span>
                </button>

                <span className="text-[10px] text-[#94A3B8] font-bold uppercase tracking-wider hidden sm:inline">
                  Réponses rapides :
                </span>

                <button
                  type="button"
                  onClick={() =>
                    setReplyText(
                      `Bonjour ${selectedConvo.customerName} ! Votre commande #${selectedConvo.orderReference || ''} a été validée. Les articles sont en cours d'inspection et d'emballage à Shenzhen.`
                    )
                  }
                  className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#334155] border border-[#CBD5E1] rounded-lg text-[11px] font-medium transition-colors cursor-pointer truncate max-w-[190px]"
                >
                  ✓ Valider commande
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setReplyText(
                      `Pour le règlement depuis votre pays, nous acceptons Mobile Money (Orange Money, MTN Mobile Money, Wave) ou virement bancaire. Souhaitez-vous recevoir les coordonnées pour effectuer le paiement ?`
                    )
                  }
                  className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#334155] border border-[#CBD5E1] rounded-lg text-[11px] font-medium transition-colors cursor-pointer truncate max-w-[190px]"
                >
                  💳 Mobile Money
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setReplyText(
                      `Pour l'expédition depuis Shenzhen, le fret aérien express prend entre 7 et 10 jours ouvrés avec dédouanement complet inclus. Pouvez-vous nous préciser votre ville de destination ?`
                    )
                  }
                  className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#334155] border border-[#CBD5E1] rounded-lg text-[11px] font-medium transition-colors cursor-pointer truncate max-w-[190px]"
                >
                  ✈️ Délais de fret
                </button>
              </div>

              {/* Admin reply input */}
              <div className="p-4 border-t border-[#E2E8F0] bg-white">
                <form onSubmit={handleSendReply} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder={`Répondre à ${selectedConvo.customerName}...`}
                    className="flex-1 px-4 py-3 bg-[#F8FAFC] border border-[#CBD5E1] rounded-2xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] min-h-[46px]"
                  />

                  <button
                    type="submit"
                    disabled={sending || !replyText.trim()}
                    className="px-5 py-3 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-2xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-sm transition-all min-h-[46px]"
                  >
                    <Send className="w-4 h-4 text-[#F59E0B]" />
                    <span className="hidden sm:inline">Envoyer</span>
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-[#94A3B8]">
              <div className="w-16 h-16 rounded-full bg-[#F1F5F9] flex items-center justify-center text-[#CBD5E1] mb-3">
                <MessageSquare className="w-8 h-8" />
              </div>
              <p className="text-sm font-bold text-[#0F172A]">Sélectionnez une discussion</p>
              <p className="text-xs text-[#64748B] mt-1 max-w-xs">
                Consultez les messages des clients, l'historique des articles demandés et répondez en direct.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
