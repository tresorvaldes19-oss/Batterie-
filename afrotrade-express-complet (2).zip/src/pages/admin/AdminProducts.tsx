import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { Product, ProductStatus } from '../../types/index.ts';
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Copy,
  Archive,
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Upload,
  Image as ImageIcon,
  Check,
  X,
  Star,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Sparkles,
  Layers,
  ArrowRight,
} from 'lucide-react';

export const AdminProducts: React.FC = () => {
  const {
    products,
    categories,
    formatPrice,
    navigateTo,
    saveProductContext,
    deleteProductContext,
    restoreDefaultProducts,
  } = useStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 12;

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [originalProduct, setOriginalProduct] = useState<Product | null>(null);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Delete confirmation modal
  const [deleteConfirmProduct, setDeleteConfirmProduct] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState(false);

  // New Image URL input inside modal
  const [newImageUrl, setNewImageUrl] = useState('');

  // Characteristic text input
  const [newCharText, setNewCharText] = useState('');

  // Specification key-value inputs
  const [specKey, setSpecKey] = useState('');
  const [specVal, setSpecVal] = useState('');

  // Filter products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchSku = p.sku.toLowerCase().includes(q);
        const matchCat = p.category.toLowerCase().includes(q);
        if (!matchName && !matchSku && !matchCat) return false;
      }
      if (filterCategory !== 'all' && p.category.toLowerCase() !== filterCategory.toLowerCase()) {
        return false;
      }
      if (filterStatus !== 'all' && p.status !== filterStatus) {
        return false;
      }
      return true;
    });
  }, [products, searchTerm, filterCategory, filterStatus]);

  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE) || 1;
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredProducts.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredProducts, currentPage]);

  const showNotification = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  // Open modal for NEW product
  const handleAddNew = () => {
    const newProd: Product = {
      id: `prod-${Date.now()}`,
      name: '',
      sku: `ATE-${Math.floor(100 + Math.random() * 900)}`,
      description: '',
      category: categories[0]?.name || 'Téléphones',
      priceEUR: 0,
      priceUSD: 0,
      stock: 10,
      status: 'disponible',
      images: [],
      mainImage: '',
      characteristics: [],
      specifications: {},
      featured: false,
      origin: 'Shenzhen, Chine',
      transitAirDays: '7-10 jours',
      transitSeaDays: '30-45 jours',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setOriginalProduct(null);
    setEditingProduct(newProd);
    setValidationError(null);
    setIsModalOpen(true);
  };

  // Open modal for EDITING product
  const handleEdit = (prod: Product) => {
    setOriginalProduct({ ...prod });
    setEditingProduct({ ...prod });
    setValidationError(null);
    setIsModalOpen(true);
  };

  // Duplicate product
  const handleDuplicate = async (prod: Product) => {
    const duplicated: Product = {
      ...prod,
      id: `prod-${Date.now()}`,
      name: `${prod.name} (Copie)`,
      sku: `${prod.sku}-CP`,
      status: 'brouillon',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await saveProductContext(duplicated);
    showNotification(`Produit "${duplicated.name}" dupliqué avec succès.`);
  };

  // Toggle publish / unpublish
  const handleToggleStatus = async (prod: Product) => {
    const newStatus: ProductStatus =
      prod.status === 'disponible' ? 'brouillon' : 'disponible';
    await saveProductContext({
      ...prod,
      status: newStatus,
      updatedAt: new Date().toISOString(),
    });
    showNotification(
      `Statut du produit "${prod.name}" changé en : ${newStatus === 'disponible' ? 'Disponible' : 'Brouillon'}.`
    );
  };

  // Trigger delete from table row or modal
  const handleRequestDelete = (prod: Product) => {
    setDeleteConfirmProduct(prod);
  };

  // Execute deletion
  const handleDeleteConfirm = async () => {
    if (!deleteConfirmProduct) return;
    setDeleting(true);
    try {
      const prodName = deleteConfirmProduct.name;
      await deleteProductContext(deleteConfirmProduct.id);
      setDeleteConfirmProduct(null);
      if (isModalOpen && editingProduct?.id === deleteConfirmProduct.id) {
        setIsModalOpen(false);
        setEditingProduct(null);
      }
      showNotification(`Publication "${prodName}" définitivement supprimée.`);
    } catch (err) {
      console.error('Error deleting product:', err);
    } finally {
      setDeleting(false);
    }
  };

  // Reset / Revert modifications to the original state
  const handleRevertModifications = () => {
    if (originalProduct) {
      setEditingProduct({ ...originalProduct });
      setValidationError(null);
      showNotification('Les modifications ont été annulées et réinitialisées.');
    } else {
      // New product reset
      handleAddNew();
    }
  };

  // Save product from modal
  const handleSaveModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    setValidationError(null);

    // Mandatory requirements check
    if (!editingProduct.name?.trim()) {
      setValidationError('Le nom ou titre du produit est obligatoire.');
      return;
    }
    if (!editingProduct.sku?.trim()) {
      setValidationError('La référence ou code SKU est obligatoire.');
      return;
    }
    if (!editingProduct.description?.trim() || editingProduct.description.trim().length < 20) {
      setValidationError('Une description détaillée d’au moins 20 caractères est obligatoire.');
      return;
    }

    // Mandatory: At least 5 photos before saving
    const imagesList = editingProduct.images || [];
    if (imagesList.length < 5) {
      setValidationError(
        `Au minimum 5 photos sont obligatoires pour publier cette fiche (actuellement ${imagesList.length} photo(s)). Veuillez en ajouter ci-dessous.`
      );
      return;
    }

    // Main image
    const mainImage = editingProduct.mainImage || imagesList[0];

    setSaving(true);
    try {
      const finalProduct: Product = {
        id: editingProduct.id || `prod-${Date.now()}`,
        name: editingProduct.name!.trim(),
        sku: editingProduct.sku!.trim(),
        description: editingProduct.description!.trim(),
        category: editingProduct.category || categories[0]?.name || 'Téléphones',
        priceEUR: Number(editingProduct.priceEUR) || 0,
        priceUSD: Number(editingProduct.priceUSD) || 0,
        stock: Number(editingProduct.stock) || 0,
        status: (editingProduct.status as ProductStatus) || 'disponible',
        images: imagesList,
        mainImage,
        characteristics: editingProduct.characteristics || [],
        specifications: editingProduct.specifications || {},
        featured: !!editingProduct.featured,
        badge: (editingProduct.badge as any) || undefined,
        origin: editingProduct.origin || 'Shenzhen, Chine',
        transitAirDays: editingProduct.transitAirDays || '7-10 jours',
        transitSeaDays: editingProduct.transitSeaDays || '30-45 jours',
        createdAt: editingProduct.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await saveProductContext(finalProduct);
      setIsModalOpen(false);
      setEditingProduct(null);
      showNotification(`Publication "${finalProduct.name}" enregistrée avec succès.`);
    } catch (err: any) {
      console.error('Error saving product:', err);
      setValidationError('Une erreur est survenue lors de l’enregistrement de la fiche.');
    } finally {
      setSaving(false);
    }
  };

  // Image helpers
  const handleAddImage = () => {
    if (!newImageUrl.trim()) return;
    const current = editingProduct?.images || [];
    setEditingProduct({
      ...editingProduct,
      images: [...current, newImageUrl.trim()],
      mainImage: editingProduct?.mainImage || newImageUrl.trim(),
    });
    setNewImageUrl('');
  };

  const handleRemoveImage = (indexToRemove: number) => {
    const current = editingProduct?.images || [];
    const updated = current.filter((_, idx) => idx !== indexToRemove);
    setEditingProduct({
      ...editingProduct,
      images: updated,
      mainImage: updated[0] || '',
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        const current = editingProduct?.images || [];
        setEditingProduct({
          ...editingProduct,
          images: [...current, result],
          mainImage: editingProduct?.mainImage || result,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  // Characteristic helpers
  const handleAddChar = () => {
    if (!newCharText.trim()) return;
    const current = editingProduct?.characteristics || [];
    setEditingProduct({
      ...editingProduct,
      characteristics: [...current, newCharText.trim()],
    });
    setNewCharText('');
  };

  const handleRemoveChar = (idx: number) => {
    const current = editingProduct?.characteristics || [];
    setEditingProduct({
      ...editingProduct,
      characteristics: current.filter((_, i) => i !== idx),
    });
  };

  // Specification helpers
  const handleAddSpec = () => {
    if (!specKey.trim() || !specVal.trim()) return;
    const current = editingProduct?.specifications || {};
    setEditingProduct({
      ...editingProduct,
      specifications: {
        ...current,
        [specKey.trim()]: specVal.trim(),
      },
    });
    setSpecKey('');
    setSpecVal('');
  };

  const handleRemoveSpec = (keyToRemove: string) => {
    const current = { ...(editingProduct?.specifications || {}) };
    delete current[keyToRemove];
    setEditingProduct({
      ...editingProduct,
      specifications: current,
    });
  };

  return (
    <div className="space-y-6 max-w-7xl font-sans text-[#0F172A] pb-16">
      {/* Toast Notification */}
      {successToast && (
        <div className="p-4 bg-[#DCFCE7] border border-[#86EFAC] rounded-2xl flex items-center justify-between gap-3 text-[#166534] text-xs font-bold animate-in fade-in shadow-md">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-[#16A34A] shrink-0" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-[#166534] hover:text-[#14532D] p-1 min-w-[32px] min-h-[32px] flex items-center justify-center cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Header & Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#D97706]">
            Catalogue & Publications
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
            Gestion des Fiches Produits
          </h1>
          <p className="text-xs text-[#64748B] mt-0.5">
            Ajoutez, modifiez ou supprimez les publications du catalogue Chine-Afrique. Exigence : 5 photos minimum par article.
          </p>
        </div>

        <button
          onClick={handleAddNew}
          className="w-full sm:w-auto px-5 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer min-h-[44px] active:scale-95"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Nouvelle Publication</span>
        </button>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-[#E2E8F0] shadow-sm flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Rechercher par nom, SKU ou catégorie..."
            className="w-full pl-9 pr-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] min-h-[44px]"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => {
              setFilterCategory(e.target.value);
              setCurrentPage(1);
            }}
            className="flex-1 md:flex-initial px-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px] cursor-pointer"
          >
            <option value="all">Toutes les catégories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.name}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setCurrentPage(1);
            }}
            className="flex-1 md:flex-initial px-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px] cursor-pointer"
          >
            <option value="all">Tous les statuts</option>
            <option value="disponible">Disponible</option>
            <option value="brouillon">Brouillon</option>
            <option value="indisponible">Indisponible / Rupture</option>
            <option value="archive">Archivé</option>
          </select>
        </div>
      </div>

      {/* Publications List Table / Responsive Card Stack */}
      <div className="bg-white rounded-3xl border border-[#E2E8F0] shadow-sm overflow-hidden">
        {/* Table View (Desktop & Tablet) */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[700px]">
            <thead className="bg-[#0A2540] text-white uppercase text-[10px] font-bold tracking-wider">
              <tr>
                <th className="px-5 py-3.5">Visuel & Titre</th>
                <th className="px-4 py-3.5">Catégorie</th>
                <th className="px-4 py-3.5">Prix ($ / €)</th>
                <th className="px-3 py-3.5">Stock</th>
                <th className="px-4 py-3.5">Statut</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#F1F5F9]">
              {paginated.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-[#64748B]">
                    <div className="max-w-sm mx-auto space-y-3">
                      <p className="font-semibold text-sm text-[#0F172A]">
                        Aucune publication trouvée
                      </p>
                      <p className="text-xs text-[#64748B]">
                        Toutes les publications ont peut-être été supprimées ou filtrées.
                      </p>
                      <button
                        onClick={restoreDefaultProducts}
                        className="px-4 py-2 bg-[#F59E0B] text-[#0A2540] rounded-xl font-bold text-xs uppercase"
                      >
                        Restaurer les articles par défaut
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                paginated.map((prod) => (
                  <tr key={prod.id} className="hover:bg-[#F8FAFC] transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={prod.mainImage || prod.images?.[0]}
                          alt={prod.name}
                          className="w-12 h-12 rounded-xl object-contain bg-[#F8FAFC] border border-[#E2E8F0] shrink-0 p-0.5"
                        />
                        <div className="min-w-0">
                          <p className="font-bold text-[#0F172A] line-clamp-1 max-w-xs">
                            {prod.name}
                          </p>
                          <p className="text-[10px] text-[#64748B] font-mono mt-0.5">
                            Réf: {prod.sku} • {prod.images?.length || 0} photo(s)
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3.5">
                      <span className="px-2.5 py-1 rounded-full bg-[#FEF3C7] text-[#92400E] text-[10px] font-bold">
                        {prod.category}
                      </span>
                    </td>

                    <td className="px-4 py-3.5">
                      <span className="font-black text-[#0A2540] block">${prod.priceUSD}</span>
                      <span className="text-[#64748B] text-[10px] block">{prod.priceEUR} €</span>
                    </td>

                    <td className="px-3 py-3.5">
                      <span
                        className={`font-bold ${
                          prod.stock <= 5 ? 'text-rose-600' : 'text-[#0F172A]'
                        }`}
                      >
                        {prod.stock} ex.
                      </span>
                    </td>

                    <td className="px-4 py-3.5">
                      <button
                        onClick={() => handleToggleStatus(prod)}
                        className={`px-2.5 py-1 rounded-full text-[10px] font-bold transition-colors cursor-pointer min-h-[28px] ${
                          prod.status === 'disponible'
                            ? 'bg-[#DCFCE7] text-[#166534] hover:bg-[#BBF7D0]'
                            : prod.status === 'brouillon'
                            ? 'bg-[#FEF3C7] text-[#92400E] hover:bg-[#FDE68A]'
                            : prod.status === 'archive'
                            ? 'bg-[#E2E8F0] text-[#475569]'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                        title="Cliquer pour basculer Publié / Brouillon"
                      >
                        {prod.status}
                      </button>
                    </td>

                    <td className="px-5 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleEdit(prod)}
                          className="p-2 text-[#0A2540] hover:text-[#D97706] hover:bg-[#FEF3C7] rounded-xl transition-colors cursor-pointer min-w-[40px] min-h-[40px] flex items-center justify-center"
                          title="Modifier la fiche"
                        >
                          <Edit className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleDuplicate(prod)}
                          className="p-2 text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9] rounded-xl transition-colors cursor-pointer min-w-[40px] min-h-[40px] flex items-center justify-center"
                          title="Dupliquer"
                        >
                          <Copy className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleRequestDelete(prod)}
                          className="p-2 text-rose-600 hover:text-white hover:bg-rose-600 rounded-xl transition-colors cursor-pointer min-w-[40px] min-h-[40px] flex items-center justify-center"
                          title="Supprimer définitivement la publication"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-[#E2E8F0] flex items-center justify-between text-xs text-[#64748B] flex-wrap gap-2">
            <span>
              Page <strong>{currentPage}</strong> sur <strong>{totalPages}</strong> ({filteredProducts.length} articles)
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="min-w-[44px] min-h-[44px] p-2.5 rounded-xl border border-[#E2E8F0] disabled:opacity-40 hover:bg-[#F8FAFC] flex items-center justify-center cursor-pointer"
                aria-label="Précédent"
              >
                <ChevronLeft className="w-4 h-4 text-[#0A2540]" />
              </button>
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="min-w-[44px] min-h-[44px] p-2.5 rounded-xl border border-[#E2E8F0] disabled:opacity-40 hover:bg-[#F8FAFC] flex items-center justify-center cursor-pointer"
                aria-label="Suivant"
              >
                <ChevronRight className="w-4 h-4 text-[#0A2540]" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {deleteConfirmProduct && (
        <div className="fixed inset-0 z-50 bg-[#0A2540]/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl border border-[#E2E8F0] animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <Trash2 className="w-7 h-7" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="text-base sm:text-lg font-black text-[#0A2540]">
                Supprimer cette publication ?
              </h3>
              <p className="text-xs text-[#64748B] leading-relaxed">
                Êtes-vous sûr de vouloir supprimer définitivement « <strong className="text-[#0F172A]">{deleteConfirmProduct.name}</strong> » (Réf: {deleteConfirmProduct.sku}) ?
              </p>
              <p className="text-[11px] text-rose-600 font-semibold">
                Cette publication sera retirée du catalogue et de la base de données.
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmProduct(null)}
                disabled={deleting}
                className="flex-1 min-h-[44px] py-2.5 rounded-xl border border-[#CBD5E1] text-[#0F172A] text-xs font-bold hover:bg-[#F8FAFC] cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirm}
                disabled={deleting}
                className="flex-1 min-h-[44px] py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-black uppercase tracking-wider cursor-pointer shadow-sm active:scale-98 transition-all flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>{deleting ? 'Suppression...' : 'Supprimer'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Create / Edit Modal */}
      {isModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 bg-[#0A2540]/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-[#E2E8F0] flex flex-col my-4">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-[#E2E8F0] flex items-center justify-between sticky top-0 bg-white z-20">
              <div>
                <h2 className="text-lg sm:text-xl font-black text-[#0A2540]">
                  {originalProduct ? 'Modifier la Fiche Publication' : 'Nouvelle Publication Produit'}
                </h2>
                <p className="text-xs text-[#64748B] mt-0.5">
                  Règle obligatoire : au minimum 5 photographies de qualité et description détaillée.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {/* Delete button from modal if editing existing publication */}
                {originalProduct && (
                  <button
                    type="button"
                    onClick={() => handleRequestDelete(originalProduct)}
                    className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-colors min-w-[40px] min-h-[40px] flex items-center justify-center cursor-pointer"
                    title="Supprimer cette publication"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 text-[#64748B] hover:text-[#0F172A] rounded-xl hover:bg-[#F1F5F9] min-w-[40px] min-h-[40px] flex items-center justify-center cursor-pointer"
                  aria-label="Fermer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveModal} className="p-5 sm:p-6 space-y-6 flex-1">
              {validationError && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-center gap-2 font-semibold">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span>{validationError}</span>
                </div>
              )}

              {/* General Information */}
              <div className="space-y-4">
                <h3 className="text-xs font-bold text-[#0A2540] uppercase tracking-wider border-b border-[#F1F5F9] pb-1.5">
                  1. Informations Générales
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Nom / Titre du Produit *
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProduct.name || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                      placeholder="Ex: Drone Professionnel 4K Ultra HD..."
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Code SKU / Référence *
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProduct.sku || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                      placeholder="ATE-DRO-202"
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-mono font-bold min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Catégorie *
                    </label>
                    <select
                      value={editingProduct.category || categories[0]?.name}
                      onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                      className="w-full px-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px] cursor-pointer"
                    >
                      {categories.map((c) => (
                        <option key={c.id} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Prix en Dollars ($ USD) *
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={editingProduct.priceUSD ?? ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, priceUSD: Number(e.target.value) || 0 })}
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-black min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Prix en Euros (€ EUR) *
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={editingProduct.priceEUR ?? ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, priceEUR: Number(e.target.value) || 0 })}
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-black min-h-[44px]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Quantité en Stock *
                    </label>
                    <input
                      type="number"
                      required
                      value={editingProduct.stock ?? ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) || 0 })}
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-bold min-h-[44px]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Statut de la publication
                    </label>
                    <select
                      value={editingProduct.status || 'disponible'}
                      onChange={(e) => setEditingProduct({ ...editingProduct, status: e.target.value as ProductStatus })}
                      className="w-full px-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px] cursor-pointer"
                    >
                      <option value="disponible">Disponible (En ligne)</option>
                      <option value="brouillon">Brouillon (Non visible)</option>
                      <option value="indisponible">Indisponible / Rupture</option>
                      <option value="archive">Archivé</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Badge promotionnel
                    </label>
                    <select
                      value={editingProduct.badge || ''}
                      onChange={(e) => setEditingProduct({ ...editingProduct, badge: (e.target.value as any) || undefined })}
                      className="w-full px-3 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px] cursor-pointer"
                    >
                      <option value="">Aucun badge</option>
                      <option value="Top Vente">Top Vente</option>
                      <option value="Nouveau">Nouveau</option>
                      <option value="Promotion">Promotion</option>
                      <option value="Stock limité">Stock limité</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#0F172A] mb-1">
                      Origine / Port de départ
                    </label>
                    <input
                      type="text"
                      value={editingProduct.origin || 'Shenzhen, Chine'}
                      onChange={(e) => setEditingProduct({ ...editingProduct, origin: e.target.value })}
                      placeholder="Shenzhen, Chine"
                      className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#0F172A] mb-1">
                    Description détaillée de l'article * (min 20 car.)
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={editingProduct.description || ''}
                    onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                    placeholder="Description complète des matériaux, fonctionnalités, état d'usine, emballage..."
                    className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
                  />
                </div>
              </div>

              {/* Photos Gallery (MANDATORY >= 5 PHOTOS) */}
              <div className="space-y-3 p-4 bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0]">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div>
                    <h3 className="text-xs font-bold text-[#0A2540] uppercase tracking-wider flex items-center gap-1.5">
                      <ImageIcon className="w-4 h-4 text-[#F59E0B]" />
                      <span>2. Galerie Photos (Obligatoire : 5 photos minimum)</span>
                    </h3>
                    <p className="text-[11px] text-[#64748B]">
                      Photos actuellement enregistrées :{' '}
                      <strong className={(editingProduct.images?.length || 0) >= 5 ? 'text-[#16A34A]' : 'text-rose-600'}>
                        {editingProduct.images?.length || 0} / 5 minimum
                      </strong>
                    </p>
                  </div>

                  <label className="cursor-pointer px-4 py-2 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors min-h-[40px]">
                    <Upload className="w-3.5 h-3.5 text-[#F59E0B]" />
                    <span>Téléverser un fichier</span>
                    <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
                  </label>
                </div>

                {/* Add by URL */}
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="Coller l'URL d'une image (https://...)"
                    className="flex-1 px-3.5 py-2.5 bg-white border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={handleAddImage}
                    className="px-4 py-2 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold min-h-[44px] cursor-pointer"
                  >
                    Ajouter Photo
                  </button>
                </div>

                {/* Thumbnails list */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
                  {(editingProduct.images || []).map((imgUrl, idx) => (
                    <div
                      key={idx}
                      className="group relative aspect-square rounded-xl bg-white border border-[#E2E8F0] p-1 flex items-center justify-center overflow-hidden shadow-xs"
                    >
                      <img src={imgUrl} alt={`Photo ${idx + 1}`} className="w-full h-full object-contain" />
                      {idx === 0 && (
                        <span className="absolute bottom-1 left-1 px-1.5 py-0.5 bg-[#0A2540] text-[#F59E0B] text-[8px] font-black uppercase rounded">
                          Principale
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute top-1 right-1 p-1 bg-rose-600 text-white rounded-full opacity-80 hover:opacity-100 transition-opacity min-w-[24px] min-h-[24px] flex items-center justify-center cursor-pointer"
                        title="Supprimer cette photo"
                      >
                        <X className="w-3 h-3 stroke-[3]" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Characteristics points */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-[#0A2540] uppercase tracking-wider border-b border-[#F1F5F9] pb-1.5">
                  3. Points Forts / Caractéristiques
                </h3>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newCharText}
                    onChange={(e) => setNewCharText(e.target.value)}
                    placeholder="Ex: Batterie 5500 mAh longue autonomie"
                    className="flex-1 px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={handleAddChar}
                    className="px-4 py-2 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] rounded-xl text-xs font-bold min-h-[44px] cursor-pointer"
                  >
                    Ajouter
                  </button>
                </div>
                <div className="space-y-1.5">
                  {(editingProduct.characteristics || []).map((char, i) => (
                    <div
                      key={i}
                      className="px-3 py-2 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0] text-xs flex items-center justify-between"
                    >
                      <span>• {char}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveChar(i)}
                        className="text-[#94A3B8] hover:text-rose-600 p-1 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Specifications key-value */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-[#0A2540] uppercase tracking-wider border-b border-[#F1F5F9] pb-1.5">
                  4. Spécifications Techniques
                </h3>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    type="text"
                    value={specKey}
                    onChange={(e) => setSpecKey(e.target.value)}
                    placeholder="Propriété (ex: Poids)"
                    className="sm:w-1/3 px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                  />
                  <input
                    type="text"
                    value={specVal}
                    onChange={(e) => setSpecVal(e.target.value)}
                    placeholder="Valeur (ex: 249 g)"
                    className="flex-1 px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                  />
                  <button
                    type="button"
                    onClick={handleAddSpec}
                    className="px-4 py-2 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] rounded-xl text-xs font-bold min-h-[44px] cursor-pointer"
                  >
                    Ajouter
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {Object.entries(editingProduct.specifications || {}).map(([k, v]) => (
                    <div
                      key={k}
                      className="p-2.5 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0] text-xs flex items-center justify-between"
                    >
                      <span>
                        <strong className="text-[#0A2540]">{k} :</strong> {v}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveSpec(k)}
                        className="text-[#94A3B8] hover:text-rose-600 p-1 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sticky Modal Bottom Actions */}
              <div className="border-t border-[#E2E8F0] pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0 bg-white z-20">
                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {/* Cancel / Revert changes button */}
                  {originalProduct && (
                    <button
                      type="button"
                      onClick={handleRevertModifications}
                      className="px-4 py-2.5 rounded-xl border border-[#CBD5E1] text-[#0F172A] text-xs font-bold hover:bg-[#F8FAFC] transition-colors cursor-pointer min-h-[44px] flex items-center justify-center gap-1.5 flex-1 sm:flex-initial"
                      title="Annuler les modifications faites dans ce formulaire et rétablir la version initiale"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Réinitialiser modifications</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl border border-[#CBD5E1] text-[#64748B] text-xs font-bold hover:bg-[#F8FAFC] cursor-pointer min-h-[44px] flex-1 sm:flex-initial"
                  >
                    Fermer
                  </button>
                </div>

                <div className="flex items-center gap-2 w-full sm:w-auto">
                  {originalProduct && (
                    <button
                      type="button"
                      onClick={() => handleRequestDelete(originalProduct)}
                      className="px-4 py-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold border border-rose-200 transition-colors cursor-pointer min-h-[44px] flex items-center justify-center gap-1.5 flex-1 sm:flex-initial"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Supprimer cette publication</span>
                    </button>
                  )}

                  <button
                    type="submit"
                    disabled={saving}
                    className="px-6 py-2.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer disabled:opacity-50 min-h-[44px] flex items-center justify-center flex-1 sm:flex-initial active:scale-98"
                  >
                    {saving ? 'Enregistrement...' : 'Enregistrer la Publication'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
