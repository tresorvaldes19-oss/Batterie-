import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import {
  Download,
  FileArchive,
  CheckCircle2,
  FolderGit2,
  ShieldCheck,
  Terminal,
  Server,
  Layers,
  Copy,
  Check,
  ExternalLink,
  Sparkles,
  HelpCircle,
  HardDrive,
  Info,
  Globe,
  Cpu,
} from 'lucide-react';

export const AdminExport: React.FC = () => {
  const { settings } = useStore();
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [activeDeployTab, setActiveDeployTab] = useState<'vercel' | 'netlify' | 'lovable' | 'render' | 'docker'>('vercel');

  const handleDownload = () => {
    setDownloading(true);
    setDownloaded(false);

    // Create a virtual anchor to download the zip file
    const link = document.createElement('a');
    link.href = '/afrotrade-express-project.zip';
    link.setAttribute('download', 'afrotrade-express-complet.zip');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setTimeout(() => {
      setDownloading(false);
      setDownloaded(true);
    }, 1200);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2500);
  };

  return (
    <div className="space-y-8 max-w-6xl">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#D97706] flex items-center gap-1.5">
            <FolderGit2 className="w-4 h-4" />
            Sauvegarde, Exportation & Déploiement
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
            Téléchargement du Projet Complet (ZIP)
          </h1>
          <p className="text-xs text-[#64748B] mt-1 max-w-2xl">
            Obtenez une archive ZIP complète contenant l'intégralité du site : code source React, panneau d'administration lui-même,
            configurations Vercel Free (<code className="font-mono bg-[#F1F5F9] px-1 rounded">vercel.json</code>, fonctions serverless <code className="font-mono bg-[#F1F5F9] px-1 rounded">/api</code>), Netlify, Docker et serveur Express.
          </p>
        </div>

        <button
          onClick={handleDownload}
          disabled={downloading}
          className="px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-98 shrink-0 min-h-[48px]"
        >
          {downloading ? (
            <>
              <div className="w-4 h-4 border-2 border-[#0A2540] border-t-transparent rounded-full animate-spin" />
              <span>Génération du ZIP...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4 text-[#0A2540]" />
              <span>Télécharger le Code (ZIP)</span>
            </>
          )}
        </button>
      </div>

      {downloaded && (
        <div className="p-4 bg-[#DCFCE7] border border-[#86EFAC] rounded-2xl flex items-start gap-3 shadow-xs animate-in fade-in duration-300">
          <CheckCircle2 className="w-5 h-5 text-[#16A34A] shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="text-xs font-black text-[#166534]">
              Téléchargement initié avec succès !
            </h4>
            <p className="text-xs text-[#15803D] mt-0.5">
              Le fichier <strong>afrotrade-express-complet.zip</strong> a été téléchargé dans votre dossier Téléchargements.
              Il contient tout votre projet prêt à être déployé sur Vercel, Netlify ou lancé en local avec <code className="bg-[#BBF7D0] px-1.5 py-0.5 rounded font-mono text-[11px]">npm install && npm run dev</code>.
            </p>
          </div>
        </div>
      )}

      {/* Main Download Hero Card */}
      <div className="bg-gradient-to-br from-[#0A2540] to-[#183E66] text-white p-6 sm:p-8 rounded-3xl shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-12 -translate-y-12 w-64 h-64 bg-[#F59E0B]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#F59E0B]/20 text-[#FBBF24] border border-[#F59E0B]/30 rounded-full text-[11px] font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              100% Configuré pour Vercel Free & Hébergement Immédiat
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Archive Source : Boutique AfroTrade Express + Panneau Admin
            </h2>
            <p className="text-xs sm:text-sm text-[#CBD5E1] leading-relaxed">
              Cette archive regroupe 100% des fichiers nécessaires au bon fonctionnement de votre plateforme.
              Les configurations de déploiement en 1 clic (<code className="text-[#FBBF24] font-mono">vercel.json</code>, <code className="text-[#FBBF24] font-mono">api/</code> serverless, <code className="text-[#FBBF24] font-mono">netlify.toml</code>, <code className="text-[#FBBF24] font-mono">Dockerfile</code>) sont incluses à la racine.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-[#94A3B8]">
              <div className="flex items-center gap-1.5">
                <HardDrive className="w-4 h-4 text-[#38BDF8]" />
                <span>Taille : ~160 Ko</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-[#4ADE80]" />
                <span>Prêt pour Vercel Free</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-[#FBBF24]" />
                <span>API Serverless & Node</span>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 w-full sm:w-auto shrink-0">
            <button
              onClick={handleDownload}
              disabled={downloading}
              className="px-8 py-4 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-2xl text-sm uppercase tracking-wider shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-3 cursor-pointer min-h-[52px]"
            >
              <Download className="w-5 h-5 text-[#0A2540]" />
              <span>Télécharger le Fichier ZIP</span>
            </button>

            <a
              href="/afrotrade-express-project.zip"
              download="afrotrade-express-complet.zip"
              className="text-center text-[11px] text-[#94A3B8] hover:text-white underline transition-colors"
            >
              Lien direct alternatif (HTTP direct)
            </a>
          </div>
        </div>
      </div>

      {/* Interactive Deployment Guides Section */}
      <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#E2E8F0]">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#10B981] flex items-center gap-1.5">
              <Globe className="w-4 h-4" />
              Déploiement Simplifié & Gratuit
            </span>
            <h3 className="text-lg font-black text-[#0A2540] mt-0.5">
              Comment Déployer en 1 Clic sur Vercel, Netlify ou Serveur
            </h3>
          </div>

          {/* Platform Tabs */}
          <div className="flex items-center gap-1 bg-[#F1F5F9] p-1 rounded-xl self-start sm:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveDeployTab('vercel')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDeployTab === 'vercel'
                  ? 'bg-black text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0A2540]'
              }`}
            >
              ▲ Vercel (Gratuit)
            </button>
            <button
              onClick={() => setActiveDeployTab('netlify')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDeployTab === 'netlify'
                  ? 'bg-[#00AD9F] text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0A2540]'
              }`}
            >
              🌐 Netlify (Gratuit)
            </button>
            <button
              onClick={() => setActiveDeployTab('lovable')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDeployTab === 'lovable'
                  ? 'bg-[#DB2777] text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0A2540]'
              }`}
            >
              ❤️ Lovable AI / Cursor
            </button>
            <button
              onClick={() => setActiveDeployTab('render')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDeployTab === 'render'
                  ? 'bg-[#46E3B7] text-[#0A2540] shadow-xs'
                  : 'text-[#64748B] hover:text-[#0A2540]'
              }`}
            >
              🚂 Render / Railway
            </button>
            <button
              onClick={() => setActiveDeployTab('docker')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                activeDeployTab === 'docker'
                  ? 'bg-[#2496ED] text-white shadow-xs'
                  : 'text-[#64748B] hover:text-[#0A2540]'
              }`}
            >
              🐳 Docker & VPS
            </button>
          </div>
        </div>

        {/* Tab 1: Vercel */}
        {activeDeployTab === 'vercel' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl flex items-start gap-3">
              <span className="p-2 bg-black text-white rounded-xl font-bold text-xs">▲</span>
              <div>
                <h4 className="text-xs font-black text-[#0F172A]">
                  Prêt pour Vercel Free Tier (Zéro configuration manuelle requise)
                </h4>
                <p className="text-xs text-[#64748B] mt-0.5">
                  Le fichier <code className="font-mono bg-[#E2E8F0] px-1 rounded">vercel.json</code> à la racine gère déjà la redirection SPA (aucune erreur 404 lors des rechargements) et les fonctions serverless dans <code className="font-mono bg-[#E2E8F0] px-1 rounded">/api</code> exécutent l'IA Gemini et le téléchargement de projet gratuitement sans serveur payant.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
                <h5 className="text-xs font-bold text-[#0A2540] flex items-center gap-1.5">
                  <span className="w-5 h-5 bg-[#0A2540] text-white rounded-full flex items-center justify-center text-[10px]">1</span>
                  Méthode GitHub (Plus simple)
                </h5>
                <ol className="text-xs text-[#475569] space-y-2 list-decimal list-inside">
                  <li>Poussez le code décompressé sur votre compte GitHub.</li>
                  <li>Allez sur <strong>vercel.com</strong> → Cliquez sur <strong>"Add New... Project"</strong>.</li>
                  <li>Sélectionnez votre dépôt GitHub. Vercel détecte automatiquement <strong>Vite</strong>.</li>
                  <li>
                    Paramètres pré-remplis :
                    <ul className="pl-4 mt-1 space-y-1 font-mono text-[11px] text-[#0F172A] list-disc list-inside">
                      <li>Framework : Vite</li>
                      <li>Build Command : npm run build</li>
                      <li>Output Directory : dist</li>
                    </ul>
                  </li>
                  <li>Cliquez sur <strong>Deploy</strong> ! En 45 secondes, votre boutique est en ligne.</li>
                </ol>
              </div>

              <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
                <h5 className="text-xs font-bold text-[#0A2540] flex items-center gap-1.5">
                  <span className="w-5 h-5 bg-[#0A2540] text-white rounded-full flex items-center justify-center text-[10px]">2</span>
                  Méthode Vercel CLI (En ligne de commande)
                </h5>
                <p className="text-xs text-[#64748B]">
                  Ouvrez un terminal dans le dossier du projet et tapez :
                </p>
                <div className="flex items-center justify-between p-2.5 bg-[#0F172A] text-emerald-400 font-mono text-xs rounded-xl">
                  <span>npx vercel</span>
                  <button
                    onClick={() => copyToClipboard('npx vercel', 'vercel-cli')}
                    className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                    title="Copier la commande"
                  >
                    {copiedCmd === 'vercel-cli' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-[#64748B]">
                  Appuyez sur Entrée pour accepter les paramètres par défaut détectés automatiquement.
                </p>

                <div className="pt-2 border-t border-[#E2E8F0]">
                  <span className="text-[11px] font-bold text-[#D97706] block">
                    Variable d'environnement Vercel (Optionnelle) :
                  </span>
                  <p className="text-[11px] text-[#64748B] mt-0.5">
                    Dans les paramètres Vercel (<em>Settings &gt; Environment Variables</em>), vous pouvez ajouter votre <code className="font-mono">GEMINI_API_KEY</code> pour booster le répondeur commercial intelligent.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Netlify */}
        {activeDeployTab === 'netlify' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl flex items-start gap-3">
              <span className="p-2 bg-[#00AD9F] text-white rounded-xl font-bold text-xs">🌐</span>
              <div>
                <h4 className="text-xs font-black text-[#0F172A]">
                  Prêt pour Netlify Free Tier
                </h4>
                <p className="text-xs text-[#64748B] mt-0.5">
                  Le fichier <code className="font-mono bg-[#E2E8F0] px-1 rounded">netlify.toml</code> et les règles de réécriture <code className="font-mono bg-[#E2E8F0] px-1 rounded">public/_redirects</code> sont inclus pour router toutes les requêtes vers <code className="font-mono bg-[#E2E8F0] px-1 rounded">/index.html</code> sans erreur 404.
                </p>
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
              <h5 className="text-xs font-bold text-[#0A2540]">Étapes simples sur Netlify :</h5>
              <ol className="text-xs text-[#475569] space-y-2 list-decimal list-inside">
                <li>Rendez-vous sur <strong>app.netlify.com</strong>.</li>
                <li>Importez votre dépôt ou glissez-déposez directement le dossier.</li>
                <li>
                  Les commandes sont déjà pré-définies dans <code className="font-mono bg-[#F1F5F9] px-1 rounded">netlify.toml</code> :
                  <div className="mt-1 p-2 bg-[#0F172A] text-emerald-400 font-mono text-[11px] rounded-lg">
                    Build command: npm run build | Publish directory: dist
                  </div>
                </li>
                <li>Cliquez sur <strong>Deploy site</strong>.</li>
              </ol>
            </div>
          </div>
        )}

        {/* Tab: Lovable AI / Cursor / Bolt */}
        {activeDeployTab === 'lovable' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 bg-[#FDF2F8] border border-[#FBCFE8] rounded-2xl flex items-start gap-3">
              <span className="p-2 bg-[#DB2777] text-white rounded-xl font-bold text-xs">❤️</span>
              <div>
                <h4 className="text-xs font-black text-[#831843]">
                  Compatibilité Totale avec Lovable AI, Cursor, Bolt & v0
                </h4>
                <p className="text-xs text-[#9D174D] mt-0.5">
                  L'archive ZIP respecte à 100% l'architecture moderne standard <strong>Vite + React 19 + TypeScript + Tailwind CSS</strong> avec base de données Firebase Firestore. Elle peut être directement importée dans Lovable AI pour continuer le développement ou la personnalisation visuelle.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
                <h5 className="text-xs font-bold text-[#0A2540] flex items-center gap-1.5">
                  <span className="w-5 h-5 bg-[#DB2777] text-white rounded-full flex items-center justify-center text-[10px]">1</span>
                  Méthode Lovable AI via GitHub (Recommandée)
                </h5>
                <ol className="text-xs text-[#475569] space-y-2 list-decimal list-inside">
                  <li>Téléchargez le fichier ZIP ci-dessus et décompressez-le sur votre machine.</li>
                  <li>Créez un nouveau dépôt sur votre compte GitHub (ex: <code>afrotrade-express</code>).</li>
                  <li>Poussez le code décompressé sur ce dépôt GitHub.</li>
                  <li>Sur <strong>lovable.dev</strong>, connectez votre compte GitHub et cliquez sur <strong>"Import GitHub Repo"</strong>.</li>
                  <li>Lovable détecte immédiatement le projet et vous pouvez continuer à prompter ou modifier l'application visuellement !</li>
                </ol>
              </div>

              <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
                <h5 className="text-xs font-bold text-[#0A2540] flex items-center gap-1.5">
                  <span className="w-5 h-5 bg-[#DB2777] text-white rounded-full flex items-center justify-center text-[10px]">2</span>
                  Utilisation directe dans Cursor / VS Code
                </h5>
                <ol className="text-xs text-[#475569] space-y-2 list-decimal list-inside">
                  <li>Ouvrez le dossier décompressé dans <strong>Cursor</strong> ou <strong>VS Code</strong>.</li>
                  <li>Ouvrez le terminal intégré et lancez :</li>
                  <div className="p-2 bg-[#0F172A] text-emerald-400 font-mono text-xs rounded-xl flex items-center justify-between">
                    <span>npm install && npm run dev</span>
                    <button
                      onClick={() => copyToClipboard('npm install && npm run dev', 'npm-dev')}
                      className="text-slate-400 hover:text-white p-1"
                    >
                      {copiedCmd === 'npm-dev' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                  <li>Le site démarre immédiatement sur <code>http://localhost:3000</code>.</li>
                  <li>Vous pouvez utiliser l'IA de Cursor pour continuer à ajouter des fonctionnalités !</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Render / Railway */}
        {activeDeployTab === 'render' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl flex items-start gap-3">
              <span className="p-2 bg-[#46E3B7] text-[#0A2540] rounded-xl font-bold text-xs">🚂</span>
              <div>
                <h4 className="text-xs font-black text-[#0F172A]">
                  Déploiement Full-Stack Node.js (Render / Railway / Fly.io)
                </h4>
                <p className="text-xs text-[#64748B] mt-0.5">
                  Permet d'exécuter à la fois le frontend Vite et le serveur Node/Express (<code className="font-mono bg-[#E2E8F0] px-1 rounded">server.ts</code>) en mode persistant.
                </p>
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-[#F1F5F9] rounded-xl">
                  <span className="text-[11px] font-bold text-[#64748B] block">Build Command :</span>
                  <code className="font-mono text-[#0A2540] font-bold text-xs">npm run build</code>
                </div>
                <div className="p-3 bg-[#F1F5F9] rounded-xl">
                  <span className="text-[11px] font-bold text-[#64748B] block">Start Command :</span>
                  <code className="font-mono text-[#0A2540] font-bold text-xs">npm start</code>
                </div>
              </div>
              <p className="text-[11px] text-[#64748B]">
                Le port d'écoute s'adapte automatiquement à la variable <code className="font-mono bg-[#F1F5F9] px-1 rounded">PORT</code> fournie par l'hébergeur.
              </p>
            </div>
          </div>
        )}

        {/* Tab 4: Docker & VPS */}
        {activeDeployTab === 'docker' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="p-4 bg-[#F8FAFC] border border-[#E2E8F0] rounded-2xl flex items-start gap-3">
              <span className="p-2 bg-[#2496ED] text-white rounded-xl font-bold text-xs">🐳</span>
              <div>
                <h4 className="text-xs font-black text-[#0F172A]">
                  Conteneurisation Docker & Déploiement VPS en 1 commande
                </h4>
                <p className="text-xs text-[#64748B] mt-0.5">
                  Un <code className="font-mono bg-[#E2E8F0] px-1 rounded">Dockerfile</code> optimisé multi-stage et un <code className="font-mono bg-[#E2E8F0] px-1 rounded">docker-compose.yml</code> sont inclus à la racine du projet.
                </p>
              </div>
            </div>

            <div className="p-4 bg-white border border-[#E2E8F0] rounded-2xl space-y-3">
              <h5 className="text-xs font-bold text-[#0A2540]">Lancement sur votre VPS (Ubuntu / Debian / Docker) :</h5>
              <div className="flex items-center justify-between p-2.5 bg-[#0F172A] text-emerald-400 font-mono text-xs rounded-xl">
                <span>docker compose up -d --build</span>
                <button
                  onClick={() => copyToClipboard('docker compose up -d --build', 'docker-cmd')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                  title="Copier la commande"
                >
                  {copiedCmd === 'docker-cmd' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-[#64748B]">
                Le conteneur démarre et expose la boutique sur le port <code className="font-mono bg-[#F1F5F9] px-1 rounded">3000</code> avec redémarrage automatique en cas de coupure.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Grid: What is included & Launch Guide */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: What is included */}
        <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
            <FileArchive className="w-5 h-5 text-[#D97706]" />
            <h3 className="text-base font-black text-[#0A2540]">
              Contenu Exact Inclus dans l'Archive
            </h3>
          </div>

          <ul className="space-y-3 text-xs text-[#334155]">
            <li className="flex items-start gap-2.5">
              <span className="p-1 bg-[#DCFCE7] text-[#16A34A] rounded-md shrink-0 mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div>
                <strong className="text-[#0F172A]">Panneau d'Administration Intégral :</strong>
                <p className="text-[11px] text-[#64748B]">
                  Tableau de bord, gestion des publications/produits, gestionnaire de bannières & catégories, commandes clients, messagerie directe, et configuration complète.
                </p>
              </div>
            </li>

            <li className="flex items-start gap-2.5">
              <span className="p-1 bg-[#DCFCE7] text-[#16A34A] rounded-md shrink-0 mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div>
                <strong className="text-[#0F172A]">Boutique Publique & E-Commerce :</strong>
                <p className="text-[11px] text-[#64748B]">
                  Catalogue avec filtres par catégorie, fiches articles détaillées, panier multi-devises (€/$/FCFA), checkout, compte client et intégration WhatsApp.
                </p>
              </div>
            </li>

            <li className="flex items-start gap-2.5">
              <span className="p-1 bg-[#DCFCE7] text-[#16A34A] rounded-md shrink-0 mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div>
                <strong className="text-[#0F172A]">Fichiers de Déploiement Vercel, Netlify & Docker :</strong>
                <p className="text-[11px] text-[#64748B]">
                  <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">vercel.json</code>, fonctions <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">api/</code> serverless, <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">netlify.toml</code>, <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">Dockerfile</code> et <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">docker-compose.yml</code>.
                </p>
              </div>
            </li>

            <li className="flex items-start gap-2.5">
              <span className="p-1 bg-[#DCFCE7] text-[#16A34A] rounded-md shrink-0 mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div>
                <strong className="text-[#0F172A]">Serveur Express & Routes API :</strong>
                <p className="text-[11px] text-[#64748B]">
                  Fichier <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">server.ts</code> pour exécuter le serveur Node avec l'API IA Gemini, répondeur d'indisponibilité et téléchargement de projet.
                </p>
              </div>
            </li>

            <li className="flex items-start gap-2.5">
              <span className="p-1 bg-[#DCFCE7] text-[#16A34A] rounded-md shrink-0 mt-0.5">
                <Check className="w-3.5 h-3.5" />
              </span>
              <div>
                <strong className="text-[#0F172A]">Base de Données & Règles Firebase :</strong>
                <p className="text-[11px] text-[#64748B]">
                  Services Firestore avec synchronisation hors-ligne, persistance locale et règles de sécurité <code className="bg-[#F1F5F9] px-1 py-0.5 rounded font-mono">firestore.rules</code>.
                </p>
              </div>
            </li>
          </ul>
        </div>

        {/* Card 2: Quick Start Guide */}
        <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
            <Terminal className="w-5 h-5 text-[#2563EB]" />
            <h3 className="text-base font-black text-[#0A2540]">
              Guide Rapide : Comment Lancer en Local
            </h3>
          </div>

          <div className="space-y-3">
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-[#64748B]">
                Étape 1 : Décompresser le fichier ZIP
              </span>
              <p className="text-xs text-[#334155]">
                Faites un clic droit sur le fichier <code className="font-mono bg-[#F1F5F9] px-1 rounded">afrotrade-express-complet.zip</code> et choisissez <strong>Extraire tout</strong>.
              </p>
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-[#64748B]">
                Étape 2 : Installer les paquets dans un terminal
              </span>
              <div className="flex items-center justify-between p-2.5 bg-[#0F172A] text-emerald-400 font-mono text-xs rounded-xl">
                <span>npm install</span>
                <button
                  onClick={() => copyToClipboard('npm install', 'install')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                  title="Copier la commande"
                >
                  {copiedCmd === 'install' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-[#64748B]">
                Étape 3 : Démarrer le serveur de développement
              </span>
              <div className="flex items-center justify-between p-2.5 bg-[#0F172A] text-emerald-400 font-mono text-xs rounded-xl">
                <span>npm run dev</span>
                <button
                  onClick={() => copyToClipboard('npm run dev', 'dev')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors cursor-pointer"
                  title="Copier la commande"
                >
                  {copiedCmd === 'dev' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-[#64748B]">
                Ouvrez votre navigateur à l'adresse <a href="http://localhost:3000" target="_blank" rel="noreferrer" className="text-[#2563EB] underline font-semibold">http://localhost:3000</a>.
              </p>
            </div>

            <div className="pt-2 border-t border-[#E2E8F0]">
              <div className="p-3 bg-[#FFFBEB] border border-[#FDE68A] rounded-xl text-[11px] text-[#92400E] space-y-1">
                <span className="font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Accès Espace Admin après décompression :
                </span>
                <p>
                  Identifiant : <code className="font-mono font-bold bg-[#FEF3C7] px-1 rounded">{settings.adminUsername || 'admin'}</code>
                  {' '}| Mot de passe par défaut : <code className="font-mono font-bold bg-[#FEF3C7] px-1 rounded">admin123</code> (modifiable dans Paramètres).
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
