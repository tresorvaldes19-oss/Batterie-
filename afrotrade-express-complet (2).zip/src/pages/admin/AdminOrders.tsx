import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { Order, OrderStatus } from '../../types/index.ts';
import { updateOrderStatus } from '../../services/db.ts';
import {
  Search,
  Filter,
  Eye,
  Mail,
  Phone,
  MapPin,
  Clock,
  Save,
  CheckCircle,
  Archive,
  MessageSquare,
  FileText,
  ChevronRight,
  X,
} from 'lucide-react';

const ORDER_STATUSES: OrderStatus[] = [
  'Nouvelle',
  'Confirmée',
  'En préparation',
  'Expédiée',
  'Livrée',
  'Annulée',
  'Remboursée',
];

export const AdminOrders: React.FC = () => {
  const { orders, formatPrice, navigateTo, openChatWithOrder } = useStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Internal note editing
  const [noteText, setNoteText] = useState('');
  const [savingNote, setSavingNote] = useState(false);
  const [noteSuccess, setNoteSuccess] = useState(false);

  const filteredOrders = useMemo(() => {
    return orders.filter((o) => {
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchRef = o.reference.toLowerCase().includes(q);
        const matchName = `${o.customer.firstName} ${o.customer.lastName}`.toLowerCase().includes(q);
        const matchEmail = o.customer.email.toLowerCase().includes(q);
        if (!matchRef && !matchName && !matchEmail) return false;
      }
      if (filterStatus !== 'all' && o.status !== filterStatus) {
        return false;
      }
      return true;
    });
  }, [orders, searchTerm, filterStatus]);

  const handleSelectOrder = (order: Order) => {
    setSelectedOrder(order);
    setNoteText(order.internalNote || '');
    setNoteSuccess(false);
  };

  const handleStatusChange = async (orderId: string, newStatus: OrderStatus) => {
    await updateOrderStatus(orderId, newStatus);
    if (selectedOrder && selectedOrder.id === orderId) {
      setSelectedOrder({ ...selectedOrder, status: newStatus });
    }
  };

  const handleSaveInternalNote = async () => {
    if (!selectedOrder) return;
    setSavingNote(true);
    try {
      await updateOrderStatus(selectedOrder.id, selectedOrder.status, noteText);
      setSelectedOrder({ ...selectedOrder, internalNote: noteText });
      setNoteSuccess(true);
      setTimeout(() => setNoteSuccess(false), 2000);
    } catch (e) {
      console.error('Error saving note:', e);
    } finally {
      setSavingNote(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
            Suivi des Ventes
          </span>
          <h1 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 mt-0.5">
            Gestion des Commandes
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            {orders.length} commandes enregistrées
          </p>
        </div>
      </div>

      {/* Filter toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par référence, client, e-mail..."
            className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-700"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-800 font-medium"
          >
            <option value="all">Tous les statuts ({orders.length})</option>
            {ORDER_STATUSES.map((st) => (
              <option key={st} value={st}>
                {st} ({orders.filter((o) => o.status === st).length})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-stone-500 border-b border-stone-200 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-6 py-3.5">Référence</th>
                <th className="px-6 py-3.5">Client & Contact</th>
                <th className="px-6 py-3.5">Date</th>
                <th className="px-6 py-3.5">Montant Total</th>
                <th className="px-6 py-3.5">Statut de la Commande</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-stone-400">
                    Aucune commande trouvée.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-stone-50/80 transition-colors">
                    <td className="px-6 py-4 font-mono font-bold text-stone-900">
                      #{ord.reference}
                    </td>

                    <td className="px-6 py-4">
                      <div className="font-semibold text-stone-900">
                        {ord.customer.firstName} {ord.customer.lastName}
                      </div>
                      <div className="text-[10px] text-stone-400">{ord.customer.email}</div>
                    </td>

                    <td className="px-6 py-4 text-stone-500">
                      {new Date(ord.createdAt).toLocaleDateString()}
                    </td>

                    <td className="px-6 py-4 font-serif font-bold text-stone-900">
                      {formatPrice(ord.total, ord.total)}
                      <span className="text-[10px] text-stone-400 font-normal block">
                        ({ord.currency})
                      </span>
                    </td>

                    <td className="px-6 py-4">
                      <select
                        value={ord.status}
                        onChange={(e) => handleStatusChange(ord.id, e.target.value as OrderStatus)}
                        className="px-2.5 py-1 rounded-lg text-[11px] font-semibold bg-stone-100 border border-stone-200 text-stone-800"
                      >
                        {ORDER_STATUSES.map((st) => (
                          <option key={st} value={st}>
                            {st}
                          </option>
                        ))}
                      </select>
                    </td>

                    <td className="px-6 py-4 text-right">
                      <button
                        onClick={() => handleSelectOrder(ord)}
                        className="px-3 py-1.5 bg-stone-900 hover:bg-amber-800 text-white rounded-lg font-semibold text-[11px] transition-colors cursor-pointer"
                      >
                        Détails
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Detail Drawer / Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 p-6 sm:p-8 space-y-6 my-6">
            <div className="flex items-start justify-between border-b border-stone-200 pb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">
                  Détail de la Commande
                </span>
                <h2 className="font-serif text-2xl font-normal text-stone-900 font-mono">
                  #{selectedOrder.reference}
                </h2>
                <p className="text-xs text-stone-400 mt-0.5">
                  Enregistrée le {new Date(selectedOrder.createdAt).toLocaleString()}
                </p>
              </div>

              <button
                onClick={() => setSelectedOrder(null)}
                className="p-2 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Status change select */}
            <div className="flex items-center justify-between p-4 bg-stone-50 rounded-2xl border border-stone-200">
              <span className="text-xs font-semibold text-stone-700">
                Modifier le Statut de Traitement :
              </span>
              <select
                value={selectedOrder.status}
                onChange={(e) => handleStatusChange(selectedOrder.id, e.target.value as OrderStatus)}
                className="px-3 py-1.5 bg-white border border-stone-300 rounded-xl text-xs font-bold text-amber-900"
              >
                {ORDER_STATUSES.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </div>

            {/* Customer Information */}
            <div className="space-y-2 text-xs">
              <h3 className="font-bold uppercase tracking-wider text-stone-700">
                Coordonnées du Client
              </h3>
              <div className="bg-stone-50/70 p-4 rounded-2xl border border-stone-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-bold text-stone-900 text-sm">
                    {selectedOrder.customer.firstName} {selectedOrder.customer.lastName}
                  </p>
                  <button
                    onClick={() => openChatWithOrder(selectedOrder.reference)}
                    className="text-amber-800 hover:underline font-semibold flex items-center gap-1"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>Contacter dans la messagerie</span>
                  </button>
                </div>
                <p className="text-stone-600 flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-stone-400" />
                  <a href={`mailto:${selectedOrder.customer.email}`} className="hover:underline">
                    {selectedOrder.customer.email}
                  </a>
                </p>
                <p className="text-stone-600 flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-stone-400" />
                  <span>{selectedOrder.customer.phone}</span>
                </p>
                <p className="text-stone-600 flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                  <span>
                    {selectedOrder.customer.address}, {selectedOrder.customer.postalCode}{' '}
                    {selectedOrder.customer.city} ({selectedOrder.customer.country})
                  </span>
                </p>
                {selectedOrder.notes && (
                  <div className="pt-2 border-t border-stone-200/60 text-stone-500 italic">
                    « Note client : {selectedOrder.notes} »
                  </div>
                )}
              </div>
            </div>

            {/* Items */}
            <div className="space-y-2 text-xs">
              <h3 className="font-bold uppercase tracking-wider text-stone-700">
                Articles Commandés
              </h3>
              <div className="border border-stone-200 rounded-2xl divide-y divide-stone-100 overflow-hidden">
                {selectedOrder.items.map((it, idx) => (
                  <div key={idx} className="p-3.5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img
                        src={it.image}
                        alt={it.name}
                        className="w-10 h-10 rounded-lg object-cover bg-stone-100"
                      />
                      <div>
                        <p className="font-semibold text-stone-900">{it.name}</p>
                        <p className="text-[10px] text-stone-400 font-mono">
                          {it.sku} • Quantité : {it.quantity}
                        </p>
                      </div>
                    </div>
                    <span className="font-serif font-bold text-stone-900">
                      {formatPrice(it.totalPrice, it.totalPrice)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Financials */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-1.5">
              <div className="flex justify-between text-stone-600">
                <span>Sous-total</span>
                <span>{formatPrice(selectedOrder.subtotal, selectedOrder.subtotal)}</span>
              </div>
              <div className="flex justify-between text-stone-600">
                <span>Frais de port</span>
                <span>
                  {selectedOrder.shippingCost === 0
                    ? 'Offerts'
                    : formatPrice(selectedOrder.shippingCost, selectedOrder.shippingCost)}
                </span>
              </div>
              <div className="pt-2 border-t border-stone-200 flex justify-between font-serif font-bold text-stone-900 text-sm">
                <span>Total Commandé ({selectedOrder.currency})</span>
                <span>{formatPrice(selectedOrder.total, selectedOrder.total)}</span>
              </div>
            </div>

            {/* Internal Note Field */}
            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <label className="font-bold uppercase tracking-wider text-stone-700">
                  Note Interne (visible uniquement par l'administrateur)
                </label>
                {noteSuccess && (
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" /> Note enregistrée !
                  </span>
                )}
              </div>
              <textarea
                rows={3}
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder="Ajouter des notes internes sur la préparation, numéro de suivi Colissimo/DHL..."
                className="w-full p-3 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-700"
              />
              <button
                type="button"
                onClick={handleSaveInternalNote}
                disabled={savingNote}
                className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{savingNote ? 'Enregistrement...' : 'Enregistrer la note interne'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
