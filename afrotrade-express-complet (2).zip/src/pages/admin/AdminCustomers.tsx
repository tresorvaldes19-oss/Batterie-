import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { CustomerProfile } from '../../types/index.ts';
import {
  subscribeCustomers,
  saveCustomerProfile,
  toggleCustomerActive,
} from '../../services/db.ts';
import {
  Users,
  Search,
  UserCheck,
  UserX,
  Mail,
  Phone,
  Package,
  MessageSquare,
  Edit,
  X,
  CheckCircle,
} from 'lucide-react';

export const AdminCustomers: React.FC = () => {
  const { orders, formatPrice, navigateTo, openChatWithOrder } = useStore();
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCust, setSelectedCust] = useState<CustomerProfile | null>(null);

  // Edit modal
  const [editingCust, setEditingCust] = useState<CustomerProfile | null>(null);

  useEffect(() => {
    const unsub = subscribeCustomers((custs) => {
      setCustomers(custs);
    });
    return () => unsub();
  }, []);

  // Filter
  const filtered = useMemo(() => {
    return customers.filter((c) => {
      const q = searchTerm.toLowerCase().trim();
      if (!q) return true;
      return (
        `${c.firstName} ${c.lastName}`.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        (c.phone && c.phone.includes(q))
      );
    });
  }, [customers, searchTerm]);

  const handleToggleActive = async (cust: CustomerProfile) => {
    await toggleCustomerActive(cust.id, !cust.isActive);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCust) return;
    await saveCustomerProfile(editingCust);
    setEditingCust(null);
  };

  // Get customer orders
  const getCustomerOrders = (cust: CustomerProfile) => {
    return orders.filter(
      (o) => o.customerId === cust.id || o.customer.email.toLowerCase() === cust.email.toLowerCase()
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-800">
            Répertoire Clientèle
          </span>
          <h1 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 mt-0.5">
            Gestion des Comptes Clients
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">
            {customers.length} clients enregistrés • Consultation des commandes et échanges
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between gap-4">
        <div className="relative w-full max-w-sm">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par nom, e-mail, téléphone..."
            className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-1 focus:ring-amber-700"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-3xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-50 text-stone-500 border-b border-stone-200 font-semibold uppercase text-[10px]">
              <tr>
                <th className="px-6 py-3.5">Client</th>
                <th className="px-6 py-3.5">Contact</th>
                <th className="px-6 py-3.5">Commandes Passées</th>
                <th className="px-6 py-3.5">Statut Compte</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-stone-400">
                    Aucun client enregistré pour le moment.
                  </td>
                </tr>
              ) : (
                filtered.map((cust) => {
                  const custOrders = getCustomerOrders(cust);
                  const totalSpent = custOrders.reduce((acc, o) => acc + o.total, 0);

                  return (
                    <tr key={cust.id} className="hover:bg-stone-50/80 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs">
                            {cust.firstName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-semibold text-stone-900">
                              {cust.firstName} {cust.lastName}
                            </p>
                            <p className="text-[10px] text-stone-400">
                              Inscrit le {new Date(cust.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="px-6 py-4">
                        <p className="text-stone-800">{cust.email}</p>
                        <p className="text-stone-400 text-[10px]">{cust.phone || 'Non renseigné'}</p>
                      </td>

                      <td className="px-6 py-4">
                        <span className="font-semibold text-stone-900">
                          {custOrders.length} commande(s)
                        </span>
                        {custOrders.length > 0 && (
                          <span className="text-[10px] text-stone-400 block font-serif">
                            Total : {formatPrice(totalSpent, totalSpent)}
                          </span>
                        )}
                      </td>

                      <td className="px-6 py-4">
                        <button
                          onClick={() => handleToggleActive(cust)}
                          className={`px-2.5 py-1 rounded-full text-[10px] font-semibold cursor-pointer ${
                            cust.isActive
                              ? 'bg-emerald-100 text-emerald-900 hover:bg-emerald-200'
                              : 'bg-rose-100 text-rose-900 hover:bg-rose-200'
                          }`}
                          title="Cliquer pour activer / désactiver"
                        >
                          {cust.isActive ? 'Actif' : 'Désactivé'}
                        </button>
                      </td>

                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => setSelectedCust(cust)}
                            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg cursor-pointer"
                            title="Historique des commandes"
                          >
                            <Package className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => setEditingCust({ ...cust })}
                            className="p-1.5 text-stone-500 hover:text-amber-800 hover:bg-amber-50 rounded-lg cursor-pointer"
                            title="Modifier les coordonnées"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Customer Orders History Modal */}
      {selectedCust && (
        <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-5 shadow-2xl border border-stone-200">
            <div className="flex items-start justify-between border-b border-stone-200 pb-3">
              <div>
                <h3 className="font-serif text-xl font-medium text-stone-900">
                  Commandes de {selectedCust.firstName} {selectedCust.lastName}
                </h3>
                <p className="text-xs text-stone-500">{selectedCust.email}</p>
              </div>
              <button
                onClick={() => setSelectedCust(null)}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {getCustomerOrders(selectedCust).length === 0 ? (
                <p className="text-xs text-stone-400 text-center py-6">
                  Aucune commande passée par ce client.
                </p>
              ) : (
                getCustomerOrders(selectedCust).map((o) => (
                  <div
                    key={o.id}
                    className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 text-xs flex items-center justify-between"
                  >
                    <div>
                      <span className="font-mono font-bold text-stone-900">#{o.reference}</span>
                      <p className="text-stone-400 text-[10px]">
                        {new Date(o.createdAt).toLocaleDateString()} • {o.items.length} article(s)
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-serif font-bold text-stone-900">
                        {formatPrice(o.total, o.total)}
                      </span>
                      <span className="block text-[10px] text-amber-800 font-semibold uppercase">
                        {o.status}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setSelectedCust(null)}
              className="w-full py-2.5 bg-stone-900 text-white rounded-xl text-xs font-semibold"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {/* Edit Customer Modal */}
      {editingCust && (
        <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveEdit}
            className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-4 shadow-2xl border border-stone-200"
          >
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-serif text-lg font-medium text-stone-900">
                Modifier le Client
              </h3>
              <button
                type="button"
                onClick={() => setEditingCust(null)}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Prénom</label>
                <input
                  type="text"
                  required
                  value={editingCust.firstName}
                  onChange={(e) => setEditingCust({ ...editingCust, firstName: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">Nom</label>
                <input
                  type="text"
                  required
                  value={editingCust.lastName}
                  onChange={(e) => setEditingCust({ ...editingCust, lastName: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">E-mail</label>
              <input
                type="email"
                required
                value={editingCust.email}
                onChange={(e) => setEditingCust({ ...editingCust, email: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">Téléphone</label>
              <input
                type="tel"
                value={editingCust.phone}
                onChange={(e) => setEditingCust({ ...editingCust, phone: e.target.value })}
                className="w-full px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs"
              />
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingCust(null)}
                className="px-4 py-2 border border-stone-300 rounded-xl text-xs font-semibold"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold"
              >
                Enregistrer
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
