import React from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import {
  Package,
  ShoppingBag,
  MessageSquare,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  Clock,
  CheckCircle2,
  Plane,
  Ship,
  FileArchive,
  Download,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const { products, orders, unreadCount, formatPrice, navigateTo } = useStore();

  const totalProducts = products.length;
  const publishedProducts = products.filter((p) => p.status === 'disponible').length;
  const draftProducts = products.filter((p) => p.status === 'brouillon').length;
  const lowStockProducts = products.filter((p) => p.stock <= 5 && p.status === 'disponible');

  const totalOrders = orders.length;
  const newOrders = orders.filter((o) => o.status === 'Nouvelle');

  // Revenue in EUR and USD
  const turnoverEUR = orders.reduce((acc, o) => acc + (o.currency === 'EUR' ? o.total : 0), 0);
  const turnoverUSD = orders.reduce((acc, o) => acc + (o.currency === 'USD' ? o.total : 0), 0);

  const recentOrders = orders.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#D97706]">
            Vue Générale & Logistique
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
            Tableau de Bord
          </h1>
          <p className="text-xs text-[#64748B] mt-1">
            Supervisez votre catalogue Chine-Afrique, les commandes transit, et les échanges clients en temps réel.
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => navigateTo('admin-export')}
            className="px-4 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-[#FBBF24] border border-[#183E66] font-black rounded-xl text-xs uppercase tracking-wider shadow-2xs transition-all flex items-center gap-2 cursor-pointer"
            title="Télécharger l'archive ZIP complète du projet"
          >
            <FileArchive className="w-4 h-4 text-[#F59E0B]" />
            <span>Télécharger Projet (ZIP)</span>
          </button>
          <button
            onClick={() => navigateTo('admin-content')}
            className="px-4 py-2.5 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] font-bold rounded-xl text-xs uppercase tracking-wider shadow-2xs transition-all cursor-pointer"
          >
            Éditer Contenus & Catégories
          </button>
          <button
            onClick={() => navigateTo('admin-products')}
            className="px-5 py-2.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider shadow-sm transition-all cursor-pointer"
          >
            + Nouveau Produit
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {/* Total Products */}
        <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748B]">Total Produits</span>
            <div className="p-2 bg-[#F1F5F9] text-[#0A2540] rounded-xl">
              <Package className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight">
            {totalProducts}
          </p>
          <div className="text-[11px] text-[#64748B] flex gap-2">
            <span className="text-[#16A34A] font-bold">{publishedProducts} en ligne</span>
            <span>•</span>
            <span className="text-[#D97706] font-bold">{draftProducts} brouillons</span>
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748B]">Commandes Transit</span>
            <div className="p-2 bg-[#FFFBEB] text-[#D97706] rounded-xl">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight">
            {totalOrders}
          </p>
          <div className="text-[11px] text-[#64748B]">
            {newOrders.length > 0 ? (
              <span className="text-rose-600 font-bold">{newOrders.length} à traiter</span>
            ) : (
              <span className="text-[#16A34A] font-semibold">Toutes traitées</span>
            )}
          </div>
        </div>

        {/* Chiffre d'Affaires */}
        <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748B]">Volume d'Affaires</span>
            <div className="p-2 bg-[#DCFCE7] text-[#16A34A] rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="space-y-0.5">
            <p className="text-xl sm:text-2xl font-black text-[#0A2540] tracking-tight">
              ${turnoverUSD.toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </p>
            {turnoverEUR > 0 && (
              <p className="text-xs font-semibold text-[#64748B]">
                + {turnoverEUR.toLocaleString('fr-FR', { minimumFractionDigits: 2 })} €
              </p>
            )}
          </div>
          <span className="text-[10px] text-[#94A3B8] block">Transit aérien & maritime</span>
        </div>

        {/* Unread / Pending Discussions */}
        <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#64748B]">Discussions En Attente</span>
            <div className="p-2 bg-[#FFFBEB] text-[#D97706] rounded-xl">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight">
            {unreadCount}
          </p>
          <div className="text-[11px] text-[#64748B]">
            <button
              onClick={() => navigateTo('admin-messages')}
              className="text-[#D97706] hover:underline font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>{unreadCount > 0 ? 'Répondre aux clients' : 'Voir la messagerie'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Important Alerts Strip */}
      <div className="space-y-3">
        <h2 className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
          Alertes & Actions Requises
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Low stock alert */}
          <div className="p-4 bg-white rounded-2xl border border-[#E2E8F0] shadow-sm flex items-start gap-3">
            <div className="p-2 bg-[#FFFBEB] text-[#D97706] rounded-xl shrink-0 mt-0.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-xs font-bold text-[#0F172A]">
                Alerte Stock Dépôt ({lowStockProducts.length} articles)
              </h3>
              <p className="text-xs text-[#64748B] mt-0.5">
                {lowStockProducts.length > 0
                  ? `Les articles : ${lowStockProducts.map((p) => p.name).slice(0, 2).join(', ')}${lowStockProducts.length > 2 ? '...' : ''} ont 5 pièces ou moins.`
                  : 'Tous les stocks des produits publiés sont stables.'}
              </p>
              {lowStockProducts.length > 0 && (
                <button
                  onClick={() => navigateTo('admin-products')}
                  className="mt-2 text-xs font-bold text-[#D97706] hover:underline inline-flex items-center gap-1"
                >
                  Gérer les stocks <ArrowRight className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>

          {/* New Orders Pending */}
          <div className="p-4 bg-white rounded-2xl border border-[#E2E8F0] shadow-sm flex items-start gap-3">
            <div className="p-2 bg-[#EFF6FF] text-[#1D4ED8] rounded-xl shrink-0 mt-0.5">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h3 className="text-xs font-bold text-[#0F172A]">
                Commandes en Attente ({newOrders.length})
              </h3>
              <p className="text-xs text-[#64748B] mt-0.5">
                {newOrders.length > 0
                  ? `${newOrders.length} commande(s) nouvelle(s) sont en attente de vérification logistique.`
                  : 'Aucune commande urgente en attente.'}
              </p>
              <button
                onClick={() => navigateTo('admin-orders')}
                className="mt-2 text-xs font-bold text-[#D97706] hover:underline inline-flex items-center gap-1"
              >
                Traiter les commandes <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white rounded-3xl border border-[#E2E8F0] shadow-sm overflow-hidden">
        <div className="p-6 border-b border-[#E2E8F0] flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
              Dernières Commandes
            </h2>
            <p className="text-xs text-[#64748B] mt-0.5">
              Historique récent des commandes passées sur la plateforme
            </p>
          </div>
          <button
            onClick={() => navigateTo('admin-orders')}
            className="text-xs font-bold text-[#D97706] hover:underline"
          >
            Voir toutes les commandes →
          </button>
        </div>

        {recentOrders.length === 0 ? (
          <div className="p-8 text-center text-xs text-[#64748B]">
            Aucune commande enregistrée pour le moment.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F8FAFC] text-[#64748B] border-b border-[#E2E8F0] font-bold uppercase text-[10px]">
                <tr>
                  <th className="px-6 py-3">Réf.</th>
                  <th className="px-6 py-3">Client</th>
                  <th className="px-6 py-3">Date</th>
                  <th className="px-6 py-3">Montant</th>
                  <th className="px-6 py-3">Statut</th>
                  <th className="px-6 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F1F5F9]">
                {recentOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-[#F8FAFC] transition-colors">
                    <td className="px-6 py-3.5 font-mono font-bold text-[#0A2540]">
                      #{ord.reference}
                    </td>
                    <td className="px-6 py-3.5">
                      <div className="font-semibold text-[#0F172A]">
                        {ord.customer.firstName} {ord.customer.lastName}
                      </div>
                      <div className="text-[10px] text-[#64748B]">{ord.customer.email}</div>
                    </td>
                    <td className="px-6 py-3.5 text-[#64748B]">
                      {new Date(ord.createdAt).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-3.5 font-black text-[#0A2540]">
                      {formatPrice(ord.total, ord.total)}
                    </td>
                    <td className="px-6 py-3.5">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-[#FEF3C7] text-[#92400E]">
                        {ord.status}
                      </span>
                    </td>
                    <td className="px-6 py-3.5 text-right">
                      <button
                        onClick={() => navigateTo('admin-orders')}
                        className="text-[#0A2540] hover:text-[#D97706] font-bold underline"
                      >
                        Gérer
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
