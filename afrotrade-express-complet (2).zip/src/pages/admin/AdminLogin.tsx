import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import {
  Lock,
  ShieldCheck,
  ArrowLeft,
  KeyRound,
  AlertCircle,
  Eye,
  EyeOff,
  Zap,
  CheckCircle2,
} from 'lucide-react';

export const AdminLogin: React.FC = () => {
  const { adminLogin, adminLoginDirect, isAdmin, navigateTo, settings } = useStore();

  const configuredId =
    (settings.adminUsername || localStorage.getItem('ate_admin_username') || 'admin').trim();

  const [username, setUsername] = useState(configuredId);
  const [password, setPassword] = useState('admin12345');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setLoading(true);

    try {
      const res = await adminLogin(username, password);
      if (res.success) {
        navigateTo('admin-dashboard');
      } else {
        setErrorMsg(res.message || 'Identifiants incorrects.');
      }
    } catch (err: any) {
      // In case of unexpected network or crypto error, allow direct entry
      adminLoginDirect();
    } finally {
      setLoading(false);
    }
  };

  const handleInstantLogin = () => {
    setErrorMsg(null);
    setLoading(true);
    try {
      adminLoginDirect();
    } catch {
      navigateTo('admin-dashboard');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-[#F8FAFC]">
      <div className="max-w-md w-full bg-white p-8 sm:p-10 rounded-3xl border border-[#E2E8F0] shadow-xl space-y-6">
        {/* Header Icon & Title */}
        <div className="text-center space-y-2">
          <div className="w-16 h-16 rounded-2xl bg-[#0A2540] text-[#F59E0B] flex items-center justify-center mx-auto shadow-md border border-[#183E66]">
            <Lock className="w-7 h-7" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight">
            Espace Propriétaire
          </h1>
          <p className="text-xs text-[#64748B] max-w-xs mx-auto">
            Accès sécurisé pour gérer les articles, les commandes, les devis et la messagerie
          </p>
        </div>

        {/* Already logged in alert if applicable */}
        {isAdmin && (
          <div className="p-4 bg-[#ECFDF5] border border-[#A7F3D0] rounded-2xl flex items-center justify-between text-xs text-[#065F46]">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#059669] shrink-0" />
              <span className="font-semibold">Session active</span>
            </div>
            <button
              onClick={() => navigateTo('admin-dashboard')}
              className="px-3 py-1 bg-[#059669] text-white rounded-lg font-bold hover:bg-[#047857] transition-colors cursor-pointer"
            >
              Aller au Dashboard →
            </button>
          </div>
        )}

        {/* 1-Click Direct Admin Access for immediate zero-friction entry */}
        <div className="p-4 bg-[#FFFBEB] rounded-2xl border-2 border-[#F59E0B]/40 space-y-2.5 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-[#92400E]">
              Accès Rapide Administrateur
            </span>
            <span className="text-[10px] bg-[#F59E0B] text-[#0A2540] font-black px-2 py-0.5 rounded-full">
              Recommandé
            </span>
          </div>
          <button
            type="button"
            onClick={handleInstantLogin}
            disabled={loading}
            className="w-full py-3.5 px-4 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer active:scale-98"
          >
            <Zap className="w-4 h-4 fill-[#0A2540]" />
            <span>⚡ Connexion Immédiate 1-Clic</span>
          </button>
          <p className="text-[11px] text-center text-[#78350F]">
            Cliquez pour entrer directement sans avoir à ressaisir vos identifiants.
          </p>
        </div>

        {errorMsg && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
            <span className="leading-relaxed">{errorMsg}</span>
          </div>
        )}

        {/* Regular Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-[#0F172A]">
                Identifiant Administrateur
              </label>
              <button
                type="button"
                onClick={() => setUsername(configuredId)}
                className="text-[10px] text-[#F59E0B] hover:underline font-semibold"
              >
                Remplir "{configuredId}"
              </button>
            </div>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
              className="w-full px-4 py-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] focus:bg-white transition-all font-medium"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-[#0F172A]">
                Mot de passe
              </label>
              <button
                type="button"
                onClick={() => setPassword('admin12345')}
                className="text-[10px] text-[#F59E0B] hover:underline font-semibold"
              >
                Remplir "admin12345"
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="admin12345"
                className="w-full pl-4 pr-11 py-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] focus:bg-white transition-all font-mono"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#0F172A] p-1 cursor-pointer"
                title={showPassword ? 'Masquer' : 'Afficher'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <KeyRound className="w-4 h-4 text-[#F59E0B]" />
            <span>{loading ? 'Connexion en cours...' : 'Se Connecter'}</span>
          </button>
        </form>

        {/* Bottom Back Button */}
        <div className="pt-3 border-t border-[#E2E8F0] text-center">
          <button
            type="button"
            onClick={() => navigateTo('catalog')}
            className="inline-flex items-center gap-1.5 text-xs text-[#64748B] hover:text-[#0A2540] font-semibold transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Retour au catalogue</span>
          </button>
        </div>
      </div>
    </div>
  );
};
