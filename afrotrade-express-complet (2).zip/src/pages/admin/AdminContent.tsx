import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { Category, StoreSettings } from '../../types/index.ts';
import {
  Layers,
  Plus,
  Edit,
  Trash2,
  Save,
  CheckCircle,
  AlertTriangle,
  Image as ImageIcon,
  Plane,
  Ship,
  ShieldCheck,
  Megaphone,
  Sparkles,
  ArrowRight,
  Eye,
  RefreshCw,
} from 'lucide-react';

export const AdminContent: React.FC = () => {
  const {
    settings,
    updateSettings,
    categories,
    saveCategoryContext,
    deleteCategoryContext,
    navigateTo,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'categories' | 'hero' | 'logistics' | 'banner'>('categories');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Category Edit / Add Modal
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [categoryError, setCategoryError] = useState<string | null>(null);
  const [categorySaving, setCategorySaving] = useState(false);

  // Category Delete Confirmation
  const [deletingCatId, setDeletingCatId] = useState<string | null>(null);

  // Hero & Content Form
  const [contentForm, setContentForm] = useState<StoreSettings>({ ...settings });
  const [savingContent, setSavingContent] = useState(false);

  const showNotification = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3500);
  };

  // Category Management Handlers
  const handleAddNewCategory = () => {
    setEditingCategory({
      id: `cat-${Date.now()}`,
      name: '',
      slug: '',
    });
    setCategoryError(null);
    setIsCategoryModalOpen(true);
  };

  const handleEditCategory = (cat: Category) => {
    setEditingCategory({ ...cat });
    setCategoryError(null);
    setIsCategoryModalOpen(true);
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory?.name?.trim()) {
      setCategoryError('Le nom de la catégorie est obligatoire.');
      return;
    }

    setCategorySaving(true);
    setCategoryError(null);

    try {
      const generatedSlug =
        editingCategory.slug?.trim() ||
        editingCategory.name
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]/g, '-')
          .replace(/-+/g, '-');

      const toSave: Category = {
        id: editingCategory.id || `cat-${Date.now()}`,
        name: editingCategory.name.trim(),
        slug: generatedSlug,
      };

      await saveCategoryContext(toSave);
      setIsCategoryModalOpen(false);
      setEditingCategory(null);
      showNotification(`Catégorie "${toSave.name}" enregistrée avec succès !`);
    } catch (err) {
      console.error('Error saving category:', err);
      setCategoryError('Erreur lors de l’enregistrement de la catégorie.');
    } finally {
      setCategorySaving(false);
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    try {
      await deleteCategoryContext(catId);
      setDeletingCatId(null);
      showNotification('Catégorie supprimée avec succès.');
    } catch (err) {
      console.error('Error deleting category:', err);
    }
  };

  // Content form submit
  const handleSaveContent = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingContent(true);
    try {
      await updateSettings(contentForm);
      showNotification('Contenus de la page d’accueil mis à jour avec succès !');
    } catch (err) {
      console.error('Error saving homepage content:', err);
    } finally {
      setSavingContent(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl font-sans text-[#0F172A] pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-xs font-black uppercase tracking-wider text-[#F59E0B]">
            Édition des Contenus du Site
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
            Catégories, Textes & Bannières
          </h1>
          <p className="text-xs text-[#64748B] mt-0.5">
            Modifiez, ajoutez ou supprimez n'importe quel texte, catégorie ou élément visuel affiché sur la boutique.
          </p>
        </div>

        <button
          onClick={() => navigateTo('home')}
          className="px-4 py-2 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] rounded-xl text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto cursor-pointer shadow-2xs"
        >
          <Eye className="w-4 h-4 text-[#F59E0B]" />
          <span>Voir la boutique</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-4 bg-[#DCFCE7] border border-[#86EFAC] rounded-2xl flex items-center gap-2 text-[#166534] text-xs font-semibold animate-in fade-in">
          <CheckCircle className="w-4 h-4 text-[#16A34A] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-[#CBD5E1] overflow-x-auto pb-1 text-xs">
        <button
          type="button"
          onClick={() => setActiveTab('categories')}
          className={`px-4 py-2.5 font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
            activeTab === 'categories'
              ? 'bg-white border-t-2 border-x border-t-[#F59E0B] border-x-[#CBD5E1] text-[#0A2540]'
              : 'text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9]'
          }`}
        >
          <Layers className="w-4 h-4 text-[#F59E0B]" />
          <span>Catégories ({categories.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('hero')}
          className={`px-4 py-2.5 font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
            activeTab === 'hero'
              ? 'bg-white border-t-2 border-x border-t-[#F59E0B] border-x-[#CBD5E1] text-[#0A2540]'
              : 'text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9]'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#F59E0B]" />
          <span>Bannière Principale Accueil</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('logistics')}
          className={`px-4 py-2.5 font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
            activeTab === 'logistics'
              ? 'bg-white border-t-2 border-x border-t-[#F59E0B] border-x-[#CBD5E1] text-[#0A2540]'
              : 'text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9]'
          }`}
        >
          <Plane className="w-4 h-4 text-[#F59E0B]" />
          <span>Cartes Logistique Fret</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('banner')}
          className={`px-4 py-2.5 font-bold rounded-t-xl transition-all cursor-pointer flex items-center gap-2 shrink-0 ${
            activeTab === 'banner'
              ? 'bg-white border-t-2 border-x border-t-[#F59E0B] border-x-[#CBD5E1] text-[#0A2540]'
              : 'text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9]'
          }`}
        >
          <Megaphone className="w-4 h-4 text-[#F59E0B]" />
          <span>Bandeaux Annonces & Promo</span>
        </button>
      </div>

      {/* TAB 1: CATEGORIES */}
      {activeTab === 'categories' && (
        <div className="bg-white rounded-3xl border border-[#CBD5E1] p-5 sm:p-7 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#F1F5F9]">
            <div>
              <h2 className="text-lg font-black text-[#0A2540]">Rayons & Catégories</h2>
              <p className="text-xs text-[#64748B]">
                Ajoutez, renommez ou supprimez les catégories de produits affichées dans les filtres et le menu.
              </p>
            </div>

            <button
              type="button"
              onClick={handleAddNewCategory}
              className="px-4 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs self-start sm:self-auto"
            >
              <Plus className="w-4 h-4 text-[#F59E0B]" />
              <span>Ajouter une catégorie</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {categories.map((cat) => {
              const isDefaultProtected = cat.id === 'tous';

              return (
                <div
                  key={cat.id}
                  className="p-4 rounded-2xl border border-[#E2E8F0] bg-[#F8FAFC] flex items-center justify-between gap-3 hover:border-[#CBD5E1] transition-colors"
                >
                  <div className="min-w-0">
                    <h3 className="font-bold text-xs text-[#0F172A] truncate">{cat.name}</h3>
                    <p className="text-[10px] text-[#64748B] font-mono truncate">slug: {cat.slug}</p>
                  </div>

                  {!isDefaultProtected ? (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleEditCategory(cat)}
                        className="p-1.5 text-[#64748B] hover:text-[#0A2540] hover:bg-white rounded-lg transition-colors cursor-pointer"
                        title="Modifier le nom"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => setDeletingCatId(cat.id)}
                        className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                        title="Supprimer la catégorie"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <span className="text-[10px] font-bold text-[#64748B] bg-[#E2E8F0] px-2 py-0.5 rounded">
                      Fixe
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: HERO BANNER */}
      {activeTab === 'hero' && (
        <form onSubmit={handleSaveContent} className="bg-white rounded-3xl border border-[#CBD5E1] p-5 sm:p-7 shadow-xs space-y-6">
          <div className="pb-4 border-b border-[#F1F5F9]">
            <h2 className="text-lg font-black text-[#0A2540]">Bannière d'Accueil Principale</h2>
            <p className="text-xs text-[#64748B]">
              Personnalisez l'accroche, le badge animé, l'image de fond et le sous-titre de la vitrine.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Badge d'en-tête (au-dessus du titre)
              </label>
              <input
                type="text"
                value={contentForm.heroBadge || ''}
                onChange={(e) => setContentForm({ ...contentForm, heroBadge: e.target.value })}
                placeholder="Plateforme d'Importation Chine → Afrique"
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Grand Titre Principal (H1)
              </label>
              <input
                type="text"
                value={contentForm.heroTitle || ''}
                onChange={(e) => setContentForm({ ...contentForm, heroTitle: e.target.value })}
                placeholder="Achetez Directement en Chine aux Prix d'Usine"
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-bold text-[#0A2540] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Sous-titre / Paragraphe de présentation
              </label>
              <textarea
                rows={3}
                value={contentForm.heroSubtitle || ''}
                onChange={(e) => setContentForm({ ...contentForm, heroSubtitle: e.target.value })}
                placeholder="Téléphones, drones, perruques, ordinateurs, électronique et équipements professionnels..."
                className="w-full p-3.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] leading-relaxed"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                URL de l'image de fond Cargo
              </label>
              <input
                type="url"
                value={contentForm.heroImageUrl || ''}
                onChange={(e) => setContentForm({ ...contentForm, heroImageUrl: e.target.value })}
                placeholder="https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=2000&q=80"
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs min-h-[44px]"
              />
            </div>

            {/* Live Preview */}
            <div className="mt-4 p-5 rounded-2xl bg-[#0A2540] text-white relative overflow-hidden">
              <div className="relative z-10 max-w-lg space-y-2">
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#183E66] text-[#FBBF24] text-[10px] font-bold">
                  {contentForm.heroBadge || "Plateforme d'Importation Chine → Afrique"}
                </span>
                <h3 className="text-xl font-black text-white">
                  {contentForm.heroTitle || "Achetez Directement en Chine aux Prix d'Usine"}
                </h3>
                <p className="text-xs text-[#CBD5E1] line-clamp-2">
                  {contentForm.heroSubtitle || "Téléphones, drones, perruques, ordinateurs..."}
                </p>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={savingContent}
            className="w-full sm:w-auto px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <Save className="w-4 h-4 text-[#0A2540]" />
            <span>{savingContent ? 'Enregistrement...' : 'Enregistrer la bannière d’accueil'}</span>
          </button>
        </form>
      )}

      {/* TAB 3: LOGISTICS CARDS */}
      {activeTab === 'logistics' && (
        <form onSubmit={handleSaveContent} className="bg-white rounded-3xl border border-[#CBD5E1] p-5 sm:p-7 shadow-xs space-y-6">
          <div className="pb-4 border-b border-[#F1F5F9]">
            <h2 className="text-lg font-black text-[#0A2540]">Cartes Logistiques de l'Accueil</h2>
            <p className="text-xs text-[#64748B]">
              Personnalisez les 3 blocs d'information fret (Aérien Express, Maritime Économique, Contrôle Qualité).
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Air Freight */}
            <div className="p-4 rounded-2xl border border-[#CBD5E1] bg-[#F8FAFC] space-y-3">
              <div className="flex items-center gap-2 text-[#1D4ED8] font-bold text-xs">
                <Plane className="w-4 h-4" />
                <span>Bloc 1 : Fret Aérien</span>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Titre</label>
                <input
                  type="text"
                  value={contentForm.logisticAirTitle || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticAirTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Description</label>
                <textarea
                  rows={4}
                  value={contentForm.logisticAirDesc || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticAirDesc: e.target.value })}
                  className="w-full p-2.5 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#475569] leading-relaxed"
                />
              </div>
            </div>

            {/* Sea Freight */}
            <div className="p-4 rounded-2xl border border-[#CBD5E1] bg-[#F8FAFC] space-y-3">
              <div className="flex items-center gap-2 text-[#059669] font-bold text-xs">
                <Ship className="w-4 h-4" />
                <span>Bloc 2 : Fret Maritime</span>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Titre</label>
                <input
                  type="text"
                  value={contentForm.logisticSeaTitle || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticSeaTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Description</label>
                <textarea
                  rows={4}
                  value={contentForm.logisticSeaDesc || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticSeaDesc: e.target.value })}
                  className="w-full p-2.5 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#475569] leading-relaxed"
                />
              </div>
            </div>

            {/* Quality Control */}
            <div className="p-4 rounded-2xl border border-[#CBD5E1] bg-[#F8FAFC] space-y-3">
              <div className="flex items-center gap-2 text-[#D97706] font-bold text-xs">
                <ShieldCheck className="w-4 h-4" />
                <span>Bloc 3 : Contrôle Qualité</span>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Titre</label>
                <input
                  type="text"
                  value={contentForm.logisticQualityTitle || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticQualityTitle: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-[#CBD5E1] rounded-xl text-xs font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-[#0F172A] mb-1">Description</label>
                <textarea
                  rows={4}
                  value={contentForm.logisticQualityDesc || ''}
                  onChange={(e) => setContentForm({ ...contentForm, logisticQualityDesc: e.target.value })}
                  className="w-full p-2.5 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#475569] leading-relaxed"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={savingContent}
            className="w-full sm:w-auto px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <Save className="w-4 h-4 text-[#0A2540]" />
            <span>{savingContent ? 'Enregistrement...' : 'Enregistrer les blocs logistiques'}</span>
          </button>
        </form>
      )}

      {/* TAB 4: ANNOUNCEMENTS */}
      {activeTab === 'banner' && (
        <form onSubmit={handleSaveContent} className="bg-white rounded-3xl border border-[#CBD5E1] p-5 sm:p-7 shadow-xs space-y-6">
          <div className="pb-4 border-b border-[#F1F5F9]">
            <h2 className="text-lg font-black text-[#0A2540]">Bandeau Supérieur & Notifications</h2>
            <p className="text-xs text-[#64748B]">
              Gérez les messages informatifs défilants affichés en haut de toutes les pages.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Notice de livraison (Barre supérieure tout en haut)
              </label>
              <input
                type="text"
                value={contentForm.deliveryNotice || ''}
                onChange={(e) => setContentForm({ ...contentForm, deliveryNotice: e.target.value })}
                placeholder="Livraison en Afrique : Cameroun, Congo, Gabon, Côte d’Ivoire, Bénin..."
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Message Promotionnel / Départs de Shenzhen
              </label>
              <input
                type="text"
                value={contentForm.promoBannerText || ''}
                onChange={(e) => setContentForm({ ...contentForm, promoBannerText: e.target.value })}
                placeholder="🚢 Groupage maritime & Fret aérien Chine-Afrique : Départ chaque semaine depuis Shenzhen !"
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px]"
              />
            </div>

            <div className="flex items-center gap-3 pt-2">
              <input
                type="checkbox"
                id="promoBannerToggle"
                checked={contentForm.promoBannerEnabled !== false}
                onChange={(e) => setContentForm({ ...contentForm, promoBannerEnabled: e.target.checked })}
                className="w-4 h-4 text-[#F59E0B] rounded border-[#CBD5E1] cursor-pointer"
              />
              <label htmlFor="promoBannerToggle" className="text-xs font-bold text-[#0F172A] cursor-pointer">
                Afficher le bandeau promotionnel sur les pages
              </label>
            </div>
          </div>

          <button
            type="submit"
            disabled={savingContent}
            className="w-full sm:w-auto px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <Save className="w-4 h-4 text-[#0A2540]" />
            <span>{savingContent ? 'Enregistrement...' : 'Enregistrer les bandeaux'}</span>
          </button>
        </form>
      )}

      {/* CATEGORY ADD/EDIT MODAL */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#CBD5E1] space-y-4 animate-in fade-in zoom-in-95">
            <h3 className="font-black text-lg text-[#0A2540]">
              {editingCategory?.name ? `Modifier la catégorie` : `Ajouter une nouvelle catégorie`}
            </h3>

            {categoryError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{categoryError}</span>
              </div>
            )}

            <form onSubmit={handleSaveCategory} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1">
                  Nom de la catégorie *
                </label>
                <input
                  type="text"
                  required
                  value={editingCategory?.name || ''}
                  onChange={(e) =>
                    setEditingCategory({
                      ...editingCategory,
                      name: e.target.value,
                    })
                  }
                  placeholder="Ex: Électronique & Drones"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-bold text-[#0F172A] min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1">
                  Identifiant technique (Slug facultatif)
                </label>
                <input
                  type="text"
                  value={editingCategory?.slug || ''}
                  onChange={(e) =>
                    setEditingCategory({
                      ...editingCategory,
                      slug: e.target.value,
                    })
                  }
                  placeholder="Ex: electronique-drones (généré automatiquement sinon)"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs font-mono text-[#64748B] min-h-[44px]"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-[#F1F5F9]">
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(false)}
                  className="px-4 py-2.5 text-xs font-bold text-[#64748B] hover:text-[#0F172A] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={categorySaving}
                  className="px-5 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer shadow-xs disabled:opacity-50"
                >
                  <span>{categorySaving ? 'Enregistrement...' : 'Enregistrer la catégorie'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CATEGORY DELETE CONFIRMATION MODAL */}
      {deletingCatId && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-[#CBD5E1] space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="font-black text-base text-[#0A2540]">Supprimer cette catégorie ?</h3>
            <p className="text-xs text-[#64748B]">
              Cette action retirera ce rayon des filtres de la boutique. Les produits associés resteront visibles dans "Tous".
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeletingCatId(null)}
                className="px-4 py-2.5 text-xs font-bold text-[#64748B] hover:text-[#0F172A] cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => handleDeleteCategory(deletingCatId)}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-xs"
              >
                Confirmer la suppression
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
