import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import { StoreSettings } from '../../types/index.ts';
import {
  Save,
  CheckCircle,
  AlertTriangle,
  Upload,
  Lock,
  Globe,
  Truck,
  FileText,
  Store,
  Eye,
  EyeOff,
  KeyRound,
  MessageCircle,
  Bot,
  Sparkles,
  FileArchive,
  Download,
} from 'lucide-react';

async function sha256(message: string): Promise<string> {
  try {
    if (typeof crypto !== 'undefined' && crypto.subtle && typeof crypto.subtle.digest === 'function') {
      const msgBuffer = new TextEncoder().encode(message);
      const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch (e) {
    console.warn('Subtle crypto fallback in AdminSettings', e);
  }
  let hash = 0;
  for (let i = 0; i < message.length; i++) {
    const char = message.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return 'fallback_' + Math.abs(hash).toString(16);
}

export const AdminSettings: React.FC = () => {
  const { settings, updateSettings, restoreDefaultProducts, navigateTo } = useStore();

  const [formData, setFormData] = useState<StoreSettings>({ ...settings });
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [restoringCatalog, setRestoringCatalog] = useState(false);
  const [catalogRestoredMsg, setCatalogRestoredMsg] = useState<string | null>(null);

  // Password & ID change state
  const [newAdminUser, setNewAdminUser] = useState(
    settings.adminUsername || localStorage.getItem('ate_admin_username') || 'admin'
  );
  const [newAdminPass, setNewAdminPass] = useState('');
  const [confirmAdminPass, setConfirmAdminPass] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [passError, setPassError] = useState<string | null>(null);
  const [passSuccess, setPassSuccess] = useState<string | null>(null);
  const [updatingCreds, setUpdatingCreds] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSuccessMsg(null);
    try {
      const cleanWhatsApp = (formData.whatsappPhone || '').replace(/[^0-9]/g, '');
      const toSave: StoreSettings = {
        ...formData,
        whatsappPhone: cleanWhatsApp || '237699452010',
        socialLinks: {
          ...(formData.socialLinks || {}),
          whatsapp: `https://wa.me/${cleanWhatsApp || '237699452010'}`,
        },
      };
      await updateSettings(toSave);
      setFormData(toSave);
      setSuccessMsg('Paramètres généraux et numéro WhatsApp enregistrés avec succès !');
      setTimeout(() => setSuccessMsg(null), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
    } finally {
      setSaving(false);
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const result = uploadEvent.target?.result as string;
      if (result) {
        setFormData({ ...formData, logoUrl: result });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleUpdateCredentials = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError(null);
    setPassSuccess(null);
    setUpdatingCreds(true);

    if (!newAdminUser.trim()) {
      setPassError("L'identifiant administrateur ne peut pas être vide.");
      setUpdatingCreds(false);
      return;
    }

    if (newAdminPass && newAdminPass.length < 4) {
      setPassError('Le mot de passe doit comporter au moins 4 caractères.');
      setUpdatingCreds(false);
      return;
    }

    if (newAdminPass && newAdminPass !== confirmAdminPass) {
      setPassError('Les deux mots de passe saisis ne correspondent pas.');
      setUpdatingCreds(false);
      return;
    }

    try {
      const updated = { ...formData, adminUsername: newAdminUser.trim() };
      try {
        localStorage.setItem('ate_admin_username', newAdminUser.trim());
      } catch {}

      if (newAdminPass) {
        const hash = await sha256(newAdminPass.trim());
        updated.adminPasswordHash = hash;
        try {
          localStorage.setItem('ate_admin_password_hash', hash);
          localStorage.setItem('ate_admin_password_plain', newAdminPass.trim());
        } catch {}
      }

      await updateSettings(updated);
      setFormData(updated);
      setNewAdminPass('');
      setConfirmAdminPass('');
      setPassSuccess(
        `Identifiants administrateur mis à jour avec succès ! Nouvel identifiant : "${newAdminUser.trim()}". Vous pouvez désormais vous connecter avec ces accès.`
      );
      setTimeout(() => setPassSuccess(null), 6000);
    } catch (err) {
      setPassError('Erreur lors de la mise à jour des identifiants.');
    } finally {
      setUpdatingCreds(false);
    }
  };

  const handleRestoreCatalog = async () => {
    setRestoringCatalog(true);
    setCatalogRestoredMsg(null);
    try {
      await restoreDefaultProducts();
      setCatalogRestoredMsg('Le catalogue complet d’origine a été réinitialisé avec succès !');
      setTimeout(() => setCatalogRestoredMsg(null), 4000);
    } catch {
      setCatalogRestoredMsg('Erreur lors de la restauration du catalogue.');
    } finally {
      setRestoringCatalog(false);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl font-sans text-[#0F172A] pb-12">
      {/* Top Header */}
      <div>
        <span className="text-[11px] font-bold uppercase tracking-wider text-[#D97706]">
          Configuration & Sécurité
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight mt-0.5">
          Paramètres de la Boutique
        </h1>
        <p className="text-xs text-[#64748B] mt-0.5">
          Personnalisez le nom, le logo, les devises, les coordonnées, les textes logistiques et les accès administrateur.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 bg-[#DCFCE7] border border-[#86EFAC] rounded-2xl flex items-center gap-2 text-[#166534] text-xs font-semibold">
          <CheckCircle className="w-4 h-4 text-[#16A34A] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Security: Change Admin ID and Password (HIGHLIGHTED FIRST AS REQUESTED) */}
      <div className="bg-white p-5 sm:p-7 rounded-3xl border-2 border-[#F59E0B]/50 shadow-md space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
          <div className="p-2 bg-[#0A2540] text-[#F59E0B] rounded-xl">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
              Identifiants & Accès Administrateur
            </h2>
            <p className="text-xs text-[#64748B]">
              Modifiez l'identifiant et le mot de passe requis pour accéder à ce panneau.
            </p>
          </div>
        </div>

        {passError && (
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{passError}</span>
          </div>
        )}

        {passSuccess && (
          <div className="p-3.5 bg-[#DCFCE7] border border-[#86EFAC] rounded-xl text-xs text-[#166534] font-semibold flex items-center gap-2">
            <CheckCircle className="w-4 h-4 shrink-0 text-[#16A34A]" />
            <span>{passSuccess}</span>
          </div>
        )}

        <form onSubmit={handleUpdateCredentials} className="space-y-4">
          <div className="p-3.5 bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0] text-xs text-[#64748B]">
            Identifiant actuel : <strong className="text-[#0A2540] font-mono">{settings.adminUsername || 'admin'}</strong>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Nouvel Identifiant (Login)
              </label>
              <input
                type="text"
                required
                value={newAdminUser}
                onChange={(e) => setNewAdminUser(e.target.value)}
                placeholder="admin"
                className="w-full px-3.5 py-2.5 bg-white border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Nouveau mot de passe
              </label>
              <div className="relative">
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Laisser vide pour garder"
                  value={newAdminPass}
                  onChange={(e) => setNewAdminPass(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2.5 bg-white border border-[#E2E8F0] rounded-xl text-xs font-mono text-[#0F172A] min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 p-1 min-w-[32px] min-h-[32px] flex items-center justify-center cursor-pointer"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Confirmer mot de passe
              </label>
              <input
                type={showPass ? 'text' : 'password'}
                placeholder="Répéter le mot de passe"
                value={confirmAdminPass}
                onChange={(e) => setConfirmAdminPass(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-white border border-[#E2E8F0] rounded-xl text-xs font-mono text-[#0F172A] min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#F59E0B]"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={updatingCreds}
            className="w-full sm:w-auto px-6 py-3 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer shadow-sm min-h-[44px] flex items-center justify-center gap-2 transition-all active:scale-98"
          >
            <KeyRound className="w-4 h-4 text-[#F59E0B]" />
            <span>{updatingCreds ? 'Mise à jour...' : 'Enregistrer le nouvel identifiant / mot de passe'}</span>
          </button>
        </form>
      </div>

      {/* Main Settings Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Identity & Branding */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
            <Store className="w-5 h-5 text-[#D97706]" />
            <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
              Identité de la Boutique & Logo
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Nom de la boutique
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Slogan / Sous-titre
              </label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] min-h-[44px]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#0F172A] mb-1">
              Description de la plateforme
            </label>
            <textarea
              rows={3}
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full p-3.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] leading-relaxed"
            />
          </div>

          {/* Logo configuration */}
          <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
            <label className="block text-xs font-bold text-[#0F172A]">Logo de la Boutique</label>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              {formData.logoUrl ? (
                <div className="w-32 h-16 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl flex items-center justify-center p-2 shrink-0">
                  <img src={formData.logoUrl} alt="Logo" className="max-h-full max-w-full object-contain" />
                </div>
              ) : (
                <div className="w-32 h-16 bg-[#F8FAFC] border border-dashed border-[#CBD5E1] rounded-xl flex items-center justify-center text-[10px] text-[#94A3B8] shrink-0 font-medium">
                  Aucun logo
                </div>
              )}

              <div className="flex-1 space-y-2 w-full">
                <input
                  type="url"
                  placeholder="URL du logo (ex: https://.../logo.png)"
                  value={formData.logoUrl}
                  onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                  className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                />
                <div className="flex items-center gap-2">
                  <label className="min-h-[44px] px-4 py-2 bg-[#F1F5F9] hover:bg-[#E2E8F0] text-[#0F172A] rounded-xl text-xs font-bold cursor-pointer inline-flex items-center gap-1.5 transition-colors">
                    <Upload className="w-3.5 h-3.5 text-[#F59E0B]" />
                    <span>Téléverser une image</span>
                    <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                  </label>
                  {formData.logoUrl && (
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, logoUrl: '' })}
                      className="text-xs text-rose-600 hover:underline min-h-[44px] px-2 font-semibold"
                    >
                      Supprimer le logo
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Coordonnées & Horaires */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
            <Globe className="w-5 h-5 text-[#D97706]" />
            <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
              Coordonnées Publiques & Horaires
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Adresse e-mail de contact
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Numéro de téléphone standard
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Adresse Dépôt / Hub
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Horaires d'assistance
              </label>
              <input
                type="text"
                value={formData.openingHours}
                onChange={(e) => setFormData({ ...formData, openingHours: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
              />
            </div>
          </div>
        </div>

        {/* Dedicated WhatsApp Link Configuration */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border-2 border-[#22C55E]/40 shadow-sm space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-[#E2E8F0]">
            <div className="p-2 bg-[#22C55E] text-white rounded-xl shadow-xs">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
                Numéro & Lien WhatsApp de la Boutique
              </h2>
              <p className="text-xs text-[#64748B]">
                Modifiez ici le numéro WhatsApp utilisé pour les commandes directes et l'assistance client.
              </p>
            </div>
          </div>

          <div className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Numéro de téléphone WhatsApp (avec indicatif pays, ex: 237699452010 ou 242061234567)
              </label>
              <input
                type="text"
                required
                value={formData.whatsappPhone || ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    whatsappPhone: e.target.value,
                  })
                }
                placeholder="237699452010"
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-mono font-bold text-[#0A2540] min-h-[44px] focus:outline-none focus:ring-2 focus:ring-[#22C55E]"
              />
            </div>

            {/* Live WhatsApp Preview */}
            <div className="p-4 bg-[#F0FDF4] rounded-2xl border border-[#BBF7D0] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-0.5">
                <span className="font-bold text-[#166534] block">Lien WhatsApp actif généré :</span>
                <code className="text-[#15803D] font-mono text-xs font-bold break-all">
                  https://wa.me/{(formData.whatsappPhone || '237699452010').replace(/[^0-9]/g, '')}
                </code>
              </div>
              <a
                href={`https://wa.me/${(formData.whatsappPhone || '237699452010').replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shrink-0 min-h-[40px]"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Tester le lien WhatsApp</span>
              </a>
            </div>

            <p className="text-[11px] text-[#64748B] leading-relaxed">
              💡 <strong>Impact immédiat :</strong> La modification de ce numéro met à jour instantanément le bouton WhatsApp de la barre supérieure, du pied de page, de l’accueil, de la page contact et de chaque fiche produit pour les commandes directes.
            </p>
          </div>
        </div>

        {/* Assistant Virtuel & IA d'Indisponibilité */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border-2 border-[#8B5CF6]/40 shadow-sm space-y-4">
          <div className="flex items-center gap-2.5 pb-3 border-b border-[#E2E8F0]">
            <div className="p-2 bg-[#8B5CF6] text-white rounded-xl shadow-xs">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#0A2540] flex items-center gap-2">
                <span>Assistant IA & Répondeur d'Indisponibilité</span>
                <span className="text-[10px] bg-[#EDE9FE] text-[#7C3AED] px-2 py-0.5 rounded-full font-bold uppercase">
                  Gemini Flash 3.8
                </span>
              </h2>
              <p className="text-xs text-[#64748B]">
                Configurez l'IA pour dialoguer avec les clients en direct ou envoyer un message d'absence personnalisé en attendant le propriétaire.
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Toggle Enable */}
            <div className="flex items-center justify-between p-3.5 bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0]">
              <div>
                <label className="text-xs font-bold text-[#0F172A] block cursor-pointer">
                  Activer l'assistance IA / répondeur automatique
                </label>
                <p className="text-[11px] text-[#64748B]">
                  Prend en charge automatiquement les messages clients dès leur envoi.
                </p>
              </div>
              <input
                type="checkbox"
                checked={formData.aiAssistantEnabled !== false}
                onChange={(e) => setFormData({ ...formData, aiAssistantEnabled: e.target.checked })}
                className="w-5 h-5 text-[#8B5CF6] rounded border-[#CBD5E1] cursor-pointer"
              />
            </div>

            {/* Mode selection */}
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1.5">
                Mode de fonctionnement de l'IA
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, aiMode: 'chat' })}
                  className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all ${
                    formData.aiMode !== 'unavailability_only'
                      ? 'bg-[#EDE9FE] border-[#8B5CF6] text-[#5B21B6]'
                      : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#64748B] hover:border-[#CBD5E1]'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-xs mb-1">
                    <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Assistant Commercial Interactif</span>
                  </div>
                  <p className="text-[11px] opacity-80 leading-relaxed">
                    L'IA converse avec le client, présente les produits du catalogue, les tarifs FCFA et fret, et précise que le propriétaire a été alerté.
                  </p>
                </button>

                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, aiMode: 'unavailability_only' })}
                  className={`p-3.5 rounded-2xl border text-left cursor-pointer transition-all ${
                    formData.aiMode === 'unavailability_only'
                      ? 'bg-[#EDE9FE] border-[#8B5CF6] text-[#5B21B6]'
                      : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#64748B] hover:border-[#CBD5E1]'
                  }`}
                >
                  <div className="flex items-center gap-2 font-bold text-xs mb-1">
                    <Bot className="w-4 h-4 text-[#8B5CF6]" />
                    <span>Message d'Absence Uniquement</span>
                  </div>
                  <p className="text-[11px] opacity-80 leading-relaxed">
                    Envoie immédiatement le message d'indisponibilité pré-enregistré pour rassurer le client en lui indiquant que sa demande est enregistrée.
                  </p>
                </button>
              </div>
            </div>

            {/* Unavailability message text */}
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Message d'indisponibilité de l'administrateur
              </label>
              <textarea
                rows={3}
                value={formData.aiUnavailabilityMessage || ''}
                onChange={(e) => setFormData({ ...formData, aiUnavailabilityMessage: e.target.value })}
                placeholder="Bonjour ! L'équipe commerciale est momentanément en préparation d'expéditions..."
                className="w-full p-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] leading-relaxed"
              />
            </div>

            {/* Delay & Custom prompt */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1">
                  Délai avant réponse de l'IA (en secondes)
                </label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={formData.aiResponseDelaySeconds ?? 2}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      aiResponseDelaySeconds: Math.max(0, Number(e.target.value) || 0),
                    })
                  }
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-bold min-h-[44px]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1">
                  Instructions IA personnalisées (System Prompt facultatif)
                </label>
                <input
                  type="text"
                  value={formData.aiCustomSystemPrompt || ''}
                  onChange={(e) => setFormData({ ...formData, aiCustomSystemPrompt: e.target.value })}
                  placeholder="Laisser vide pour utiliser les instructions par défaut d'AfroTrade Express"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs min-h-[44px]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Tarifs de livraison & Taux FCFA */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center gap-2 pb-3 border-b border-[#E2E8F0]">
            <Truck className="w-5 h-5 text-[#D97706]" />
            <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
              Devises & Logistique Fret
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Taux de change USD → FCFA
              </label>
              <input
                type="number"
                value={formData.exchangeRateUSD_FCFA}
                onChange={(e) => setFormData({ ...formData, exchangeRateUSD_FCFA: Number(e.target.value) || 610 })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-black min-h-[44px]"
              />
              <span className="text-[10px] text-[#64748B] mt-1 block">1 USD = {formData.exchangeRateUSD_FCFA} FCFA</span>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Frais de port par défaut ($ USD)
              </label>
              <input
                type="number"
                value={formData.defaultShippingCostUSD}
                onChange={(e) => setFormData({ ...formData, defaultShippingCostUSD: Number(e.target.value) || 0 })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-bold min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#0F172A] mb-1">
                Livraison gratuite à partir de ($ USD)
              </label>
              <input
                type="number"
                value={formData.freeShippingThresholdUSD}
                onChange={(e) => setFormData({ ...formData, freeShippingThresholdUSD: Number(e.target.value) || 0 })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-bold min-h-[44px]"
              />
            </div>
          </div>
        </div>

        {/* Catalog Maintenance & Reset */}
        <div className="bg-white p-5 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
            <div>
              <h2 className="text-base sm:text-lg font-black text-[#0A2540]">
                Gestion & Restauration du Catalogue
              </h2>
              <p className="text-xs text-[#64748B]">
                Si vous avez supprimé des publications et souhaitez réinitialiser les articles d'origine de la démonstration.
              </p>
            </div>
          </div>

          {catalogRestoredMsg && (
            <div className="p-3.5 bg-[#DCFCE7] border border-[#86EFAC] rounded-xl text-xs text-[#166534] font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-[#16A34A] shrink-0" />
              <span>{catalogRestoredMsg}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 bg-[#F8FAFC] rounded-2xl border border-[#E2E8F0]">
            <div>
              <h4 className="text-xs font-bold text-[#0F172A]">Rétablir les articles initiaux</h4>
              <p className="text-[11px] text-[#64748B]">
                Restaure l'ensemble des 8 produits complets avec fiches détaillées, 5+ photos et spécifications.
              </p>
            </div>
            <button
              type="button"
              onClick={handleRestoreCatalog}
              disabled={restoringCatalog}
              className="px-5 py-2.5 bg-white hover:bg-[#F1F5F9] border border-[#CBD5E1] text-[#0A2540] font-bold rounded-xl text-xs transition-colors cursor-pointer min-h-[44px] flex items-center gap-2 shrink-0 disabled:opacity-50"
            >
              <span>{restoringCatalog ? 'Restauration...' : 'Réinitialiser le catalogue d’origine'}</span>
            </button>
          </div>
        </div>

        {/* Sauvegarde & Téléchargement du projet complet (ZIP) */}
        <div className="bg-gradient-to-br from-[#0A2540] to-[#183E66] text-white p-5 sm:p-7 rounded-3xl border border-[#183E66] shadow-md space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#183E66]/80">
            <div className="flex items-center gap-2">
              <FileArchive className="w-5 h-5 text-[#F59E0B]" />
              <h2 className="text-base sm:text-lg font-black text-white">
                Sauvegarde & Téléchargement du Projet Complet (ZIP)
              </h2>
            </div>
            <span className="text-[10px] bg-[#F59E0B] text-[#0A2540] font-black uppercase px-2 py-0.5 rounded">
              Code Source Inclus
            </span>
          </div>

          <p className="text-xs text-[#CBD5E1] leading-relaxed">
            Téléchargez l'archive complète de votre boutique AfroTrade Express contenant 100% des fichiers :
            l'ensemble du code source React, les composants, tous les écrans du panneau d'administration lui-même,
            le serveur Express (<code className="text-[#FBBF24]">server.ts</code>), les styles Tailwind CSS, la configuration Firebase et la documentation d'installation (<code className="text-[#FBBF24]">README.md</code>).
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
            <a
              href="/afrotrade-express-project.zip"
              download="afrotrade-express-complet.zip"
              className="px-6 py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer min-h-[44px] active:scale-98"
            >
              <Download className="w-4 h-4 text-[#0A2540]" />
              <span>Télécharger l'Archive ZIP (.zip)</span>
            </a>

            <button
              type="button"
              onClick={() => navigateTo('admin-export')}
              className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer min-h-[44px] border border-white/20"
            >
              <span>Voir les détails & Guide de déploiement</span>
            </button>
          </div>
        </div>

        {/* Save button */}
        <button
          type="submit"
          disabled={saving}
          className="w-full sm:w-auto px-8 py-3.5 bg-[#F59E0B] hover:bg-[#D97706] disabled:opacity-50 text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer min-h-[48px] active:scale-98"
        >
          <Save className="w-4 h-4 text-[#0A2540]" />
          <span>{saving ? 'Enregistrement en cours...' : 'Enregistrer tous les paramètres généraux'}</span>
        </button>
      </form>
    </div>
  );
};
