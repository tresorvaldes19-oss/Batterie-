import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext.tsx';
import {
  LayoutDashboard,
  Package,
  Layers,
  ShoppingBag,
  Users,
  MessageSquare,
  Settings,
  LogOut,
  ExternalLink,
  Menu,
  X,
  ShieldCheck,
  FileArchive,
  Download,
} from 'lucide-react';

interface AdminLayoutProps {
  children: React.ReactNode;
  activeSection: string;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({ children, activeSection }) => {
  const { settings, adminLogout, navigateTo, unreadCount, orders } = useStore();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  const pendingOrdersCount = orders.filter((o) => o.status === 'Nouvelle').length;

  const menuItems = [
    {
      id: 'admin-dashboard',
      label: 'Tableau de bord',
      icon: LayoutDashboard,
    },
    {
      id: 'admin-products',
      label: 'Publications & Produits',
      icon: Package,
    },
    {
      id: 'admin-content',
      label: 'Contenus & Catégories',
      icon: Layers,
    },
    {
      id: 'admin-orders',
      label: 'Commandes',
      icon: ShoppingBag,
      badge: pendingOrdersCount > 0 ? pendingOrdersCount : undefined,
    },
    {
      id: 'admin-customers',
      label: 'Clients',
      icon: Users,
    },
    {
      id: 'admin-messages',
      label: 'Messagerie & Devis',
      icon: MessageSquare,
      badge: unreadCount > 0 ? unreadCount : undefined,
    },
    {
      id: 'admin-settings',
      label: 'Paramètres Boutique',
      icon: Settings,
    },
    {
      id: 'admin-export',
      label: 'Télécharger Projet (ZIP)',
      icon: FileArchive,
      badge: 'ZIP',
    },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col lg:flex-row font-sans text-[#0F172A]">
      {/* Mobile Top Header for Admin */}
      <div className="lg:hidden bg-[#0A2540] text-white px-4 py-3 flex items-center justify-between sticky top-0 z-40 border-b border-[#183E66]">
        <div className="flex items-center gap-2">
          <span className="font-black text-base text-white tracking-tight">
            {settings.name || 'AfroTrade Express'}
          </span>
          <span className="text-[10px] bg-[#F59E0B] text-[#0A2540] font-black uppercase px-2 py-0.5 rounded">
            Admin
          </span>
        </div>

        <button
          onClick={() => setMobileNavOpen(!mobileNavOpen)}
          className="p-1.5 text-[#CBD5E1] hover:text-white rounded-lg hover:bg-[#183E66] cursor-pointer"
        >
          {mobileNavOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`${
          mobileNavOpen ? 'block' : 'hidden'
        } lg:block w-full lg:w-64 bg-[#0A2540] text-[#CBD5E1] flex flex-col shrink-0 z-30 lg:min-h-screen border-r border-[#183E66]`}
      >
        {/* Brand header */}
        <div className="p-6 border-b border-[#183E66] hidden lg:block">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#F59E0B]">
              Panneau d'Administration
            </span>
          </div>
          <h2 className="text-lg font-black text-white truncate mt-1">
            {settings.name || 'AfroTrade Express'}
          </h2>
          <p className="text-[11px] text-[#FBBF24] font-medium truncate mt-0.5">
            {settings.tagline || 'Import Chine → Afrique'}
          </p>
        </div>

        {/* Nav Items */}
        <nav className="p-4 space-y-1.5 flex-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;

            return (
              <button
                key={item.id}
                onClick={() => {
                  navigateTo(item.id);
                  setMobileNavOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-[#F59E0B] text-[#0A2540] font-black shadow-sm'
                    : 'text-[#CBD5E1] hover:text-white hover:bg-[#183E66]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                      isActive
                        ? 'bg-[#0A2540] text-white'
                        : 'bg-[#F59E0B] text-[#0A2540]'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer shortcuts */}
        <div className="p-4 border-t border-[#183E66] space-y-2">
          <a
            href="/afrotrade-express-project.zip"
            download="afrotrade-express-complet.zip"
            className="w-full flex items-center justify-between px-3 py-2 text-xs bg-[#F59E0B]/15 hover:bg-[#F59E0B]/25 text-[#FBBF24] border border-[#F59E0B]/30 rounded-lg transition-colors cursor-pointer"
            title="Télécharger l'archive ZIP complète du projet"
          >
            <div className="flex items-center gap-2">
              <Download className="w-4 h-4 text-[#F59E0B]" />
              <span className="font-bold">Télécharger ZIP</span>
            </div>
            <span className="text-[10px] bg-[#F59E0B] text-[#0A2540] font-black px-1.5 py-0.5 rounded">
              ~150 Ko
            </span>
          </a>

          <button
            onClick={() => navigateTo('catalog')}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-[#CBD5E1] hover:text-white rounded-lg hover:bg-[#183E66] transition-colors cursor-pointer"
          >
            <ExternalLink className="w-4 h-4 text-[#38BDF8]" />
            <span>Voir le catalogue public</span>
          </button>

          <button
            onClick={adminLogout}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:text-rose-300 rounded-lg hover:bg-rose-950/40 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>Déconnexion session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
        {children}
      </main>
    </div>
  );
};
