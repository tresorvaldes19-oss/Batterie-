import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import {
  ShoppingCart,
  MessageCircle,
  ShieldCheck,
  Plane,
  Ship,
  Check,
  ChevronRight,
  ArrowLeft,
  MapPin,
  Star,
  Package,
} from 'lucide-react';

export const ProductDetailPage: React.FC = () => {
  const {
    products,
    navState,
    navigateTo,
    formatPrice,
    getFCFAEquivalent,
    addToCart,
    settings,
  } = useStore();

  const product = products.find((p) => p.id === navState.productId);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-[#F1F5F9] text-[#64748B] flex items-center justify-center mx-auto">
          <Package className="w-8 h-8" />
        </div>
        <h2 className="text-xl sm:text-2xl font-black text-[#0A2540]">Publication introuvable</h2>
        <p className="text-xs text-[#64748B] max-w-sm mx-auto">
          Cette publication a peut-être été supprimée ou modifiée.
        </p>
        <button
          onClick={() => navigateTo('catalog')}
          className="px-6 py-3 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer min-h-[44px]"
        >
          Retour au catalogue
        </button>
      </div>
    );
  }

  // Ensure images array has content
  const images = product.images && product.images.length > 0 ? product.images : [product.mainImage];
  const activeImage = images[selectedImageIndex] || product.mainImage;
  const isAvailable = product.status === 'disponible' && product.stock > 0;

  const handleAddToCart = () => {
    if (!isAvailable) return;
    addToCart(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const phone = settings.whatsappPhone || '237699452010';
  const whatsAppMessage = encodeURIComponent(
    `Bonjour AfroTrade Express, je souhaite commander l'article : ${product.name} (Réf: ${product.sku}) au prix de $${product.priceUSD} (${getFCFAEquivalent(product.priceUSD)}). Quantité: ${quantity}. Merci de me donner les instructions d'expédition.`
  );
  const whatsAppUrl = `https://wa.me/${phone}?text=${whatsAppMessage}`;

  // Related products in the same category
  const related = products
    .filter((p) => p.category === product.category && p.id !== product.id && p.status === 'disponible')
    .slice(0, 4);

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-10 font-sans text-[#0F172A]">
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center gap-2 text-xs text-[#64748B] flex-wrap">
        <button
          onClick={() => navigateTo('home')}
          className="hover:text-[#0A2540] font-medium cursor-pointer min-h-[36px] flex items-center"
        >
          Accueil
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-[#94A3B8]" />
        <button
          onClick={() => navigateTo('catalog')}
          className="hover:text-[#0A2540] font-medium cursor-pointer min-h-[36px] flex items-center"
        >
          Catalogue
        </button>
        <ChevronRight className="w-3.5 h-3.5 text-[#94A3B8]" />
        <span className="text-[#0A2540] font-bold truncate max-w-xs">{product.name}</span>
      </nav>

      {/* Main Product Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
        {/* Left: Gallery Showcase with 5+ images */}
        <div className="space-y-4">
          {/* Main Selected Image with object-fit: contain */}
          <div className="relative aspect-square w-full rounded-3xl bg-[#F8FAFC] border border-[#E2E8F0] shadow-sm p-4 sm:p-6 flex items-center justify-center overflow-hidden">
            <img
              src={activeImage}
              alt={product.name}
              className="max-h-full max-w-full object-contain transition-all duration-300"
            />
            {product.badge && (
              <span className="absolute top-4 left-4 px-3 py-1 bg-[#F59E0B] text-[#0A2540] text-xs font-black uppercase tracking-wider rounded-md shadow-xs">
                {product.badge}
              </span>
            )}
          </div>

          {/* Thumbnails (Supports 5+ images) */}
          <div className="flex items-center gap-2.5 overflow-x-auto pb-2 no-scrollbar touch-pan-x">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setSelectedImageIndex(idx)}
                className={`relative w-16 sm:w-20 h-16 sm:h-20 rounded-xl p-1.5 bg-[#F8FAFC] shrink-0 border-2 transition-all cursor-pointer ${
                  selectedImageIndex === idx
                    ? 'border-[#F59E0B] ring-2 ring-[#F59E0B]/20 scale-105'
                    : 'border-[#E2E8F0] opacity-70 hover:opacity-100'
                }`}
                aria-label={`Photo ${idx + 1}`}
              >
                <img src={img} alt={`Vue ${idx + 1}`} className="w-full h-full object-contain" />
              </button>
            ))}
          </div>
          <p className="text-[11px] text-[#64748B] text-center">
            {images.length} photographies disponibles • Cliquez pour agrandir
          </p>

          {/* Logistics Box */}
          <div className="bg-white p-5 rounded-2xl border border-[#E2E8F0] shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#0A2540]">
              <MapPin className="w-4 h-4 text-[#F59E0B]" />
              <span>Expédition directe depuis : {product.origin || 'Shenzhen, Chine'}</span>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0] flex items-center gap-2.5">
                <Plane className="w-4 h-4 text-sky-600 shrink-0" />
                <div>
                  <span className="font-bold block text-[#0A2540]">Fret Aérien</span>
                  <span className="text-[11px] text-[#64748B]">{product.transitAirDays || '7-10 jours'}</span>
                </div>
              </div>
              <div className="p-3 bg-[#F8FAFC] rounded-xl border border-[#E2E8F0] flex items-center gap-2.5">
                <Ship className="w-4 h-4 text-emerald-600 shrink-0" />
                <div>
                  <span className="font-bold block text-[#0A2540]">Groupage Maritime</span>
                  <span className="text-[11px] text-[#64748B]">{product.transitSeaDays || '30-45 jours'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Product Details & Purchase Form */}
        <div className="space-y-6">
          {/* Category & Stock */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="px-3 py-1 bg-[#FEF3C7] text-[#92400E] text-xs font-bold uppercase tracking-wider rounded-full">
              {product.category}
            </span>

            <div className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isAvailable ? 'bg-[#22C55E]' : 'bg-rose-500'
                }`}
              />
              <span className="text-xs font-semibold text-[#0F172A]">
                {isAvailable ? `En stock (${product.stock} exemplaires)` : 'Rupture temporaire'}
              </span>
            </div>
          </div>

          {/* Title & SKU */}
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight leading-snug line-clamp-2">
              {product.name}
            </h1>
            <div className="flex items-center gap-3 mt-2 text-xs text-[#64748B]">
              <span className="font-mono">Réf: <strong className="text-[#0F172A]">{product.sku}</strong></span>
              <span>•</span>
              <div className="flex items-center gap-1 text-[#F59E0B]">
                {Array.from({ length: 5 }, (_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-[#F59E0B]" />
                ))}
                <span className="text-[#64748B] font-medium text-xs ml-1">(4.9/5)</span>
              </div>
            </div>
          </div>

          {/* Pricing Block */}
          <div className="p-5 bg-white rounded-2xl border border-[#E2E8F0] shadow-sm space-y-1">
            <span className="text-xs font-semibold text-[#64748B]">Prix unitaire départ usine :</span>
            <div className="flex items-baseline gap-3 flex-wrap">
              <span className="text-2xl sm:text-3xl font-black text-[#0A2540] tracking-tight">
                {formatPrice(product.priceEUR, product.priceUSD)}
              </span>
              <span className="text-sm font-bold text-[#D97706]">
                ({getFCFAEquivalent(product.priceUSD)})
              </span>
            </div>
            <p className="text-[11px] text-[#64748B] pt-1">
              Tarif en dollars avec conversion instantanée en Franc CFA (XAF/XOF).
            </p>
          </div>

          {/* Quantity & Actions */}
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              {/* Quantity Selector */}
              <div className="flex items-center border border-[#E2E8F0] rounded-xl bg-white overflow-hidden shadow-xs">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="min-w-[44px] min-h-[48px] px-3.5 py-2 hover:bg-[#F1F5F9] text-base font-black text-[#0A2540] flex items-center justify-center cursor-pointer"
                  aria-label="Diminuer la quantité"
                >
                  -
                </button>
                <span className="min-w-[44px] text-center font-black text-sm text-[#0F172A]">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity(quantity + 1)}
                  className="min-w-[44px] min-h-[48px] px-3.5 py-2 hover:bg-[#F1F5F9] text-base font-black text-[#0A2540] flex items-center justify-center cursor-pointer"
                  aria-label="Augmenter la quantité"
                >
                  +
                </button>
              </div>

              {/* Add to Cart Button */}
              <button
                type="button"
                onClick={handleAddToCart}
                disabled={!isAvailable}
                className={`flex-1 min-h-[48px] py-3.5 px-6 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                  added
                    ? 'bg-[#16A34A] text-white'
                    : !isAvailable
                    ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                    : 'bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] active:scale-98'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3]" />
                    <span>Ajouté au chariot !</span>
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4" />
                    <span>Ajouter au chariot</span>
                  </>
                )}
              </button>
            </div>

            {/* Direct WhatsApp Order Link */}
            <a
              href={whatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full min-h-[48px] py-3.5 px-4 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer text-center"
            >
              <MessageCircle className="w-4 h-4 shrink-0" />
              <span>Commander directement via WhatsApp</span>
            </a>
          </div>

          {/* Description */}
          <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#0A2540]">
              Description Détaillée
            </h3>
            <p className="text-xs sm:text-sm text-[#475569] leading-relaxed whitespace-pre-line">
              {product.description}
            </p>
          </div>

          {/* Characteristics */}
          {product.characteristics && product.characteristics.length > 0 && (
            <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0A2540]">
                Points Forts & Équipements
              </h3>
              <ul className="space-y-1.5 text-xs text-[#0F172A]">
                {product.characteristics.map((c, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className="w-3.5 h-3.5 text-[#16A34A] shrink-0 mt-0.5" />
                    <span>{c}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Specifications */}
          {product.specifications && Object.keys(product.specifications).length > 0 && (
            <div className="space-y-2 pt-2 border-t border-[#E2E8F0]">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0A2540]">
                Spécifications Techniques
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {Object.entries(product.specifications).map(([k, v]) => (
                  <div key={k} className="p-2.5 bg-white rounded-xl border border-[#E2E8F0]">
                    <span className="text-[#64748B] block text-[10px] uppercase font-bold">{k}</span>
                    <span className="font-semibold text-[#0F172A]">{v}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products */}
      {related.length > 0 && (
        <section className="pt-10 border-t border-[#E2E8F0] space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg sm:text-xl font-black text-[#0A2540]">
              Articles Similaires dans la Catégorie {product.category}
            </h2>
            <button
              onClick={() => navigateTo('catalog')}
              className="text-xs font-bold text-[#D97706] hover:underline cursor-pointer min-h-[44px] flex items-center"
            >
              Voir tout le catalogue
            </button>
          </div>

          <div className="grid grid-cols-1 min-[380px]:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {related.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
