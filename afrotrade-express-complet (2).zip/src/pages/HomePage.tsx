import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import {
  ArrowRight,
  Plane,
  Ship,
  ShieldCheck,
  CheckCircle2,
  Package,
  MapPin,
  MessageCircle,
  TrendingUp,
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const { settings, products, navigateTo } = useStore();

  const featuredProducts = products
    .filter((p) => p.status === 'disponible')
    .slice(0, 10);

  return (
    <div className="space-y-12 sm:space-y-16 pb-16">
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-[#0A2540] text-white py-16 sm:py-24 border-b border-[#183E66]">
        {/* Abstract overlay */}
        <div className="absolute inset-0 opacity-15">
          <img
            src={
              settings.heroImageUrl ||
              'https://images.unsplash.com/photo-1578575437130-527eed3abbec?auto=format&fit=crop&w=2000&q=80'
            }
            alt="Cargo maritime et aérien"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#0A2540] via-[#0A2540]/90 to-transparent" />

        <div className="relative max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#183E66] border border-[#38BDF8]/30 text-[#FBBF24] text-xs font-bold uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
              <span>{settings.heroBadge || "Plateforme d'Importation Chine → Afrique"}</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black leading-tight tracking-tight text-white">
              {settings.heroTitle || "Achetez Directement en Chine aux Prix d'Usine"}
            </h1>

            <p className="text-sm sm:text-base text-[#CBD5E1] leading-relaxed">
              {settings.heroSubtitle ||
                "Téléphones, drones, perruques, ordinateurs, électronique et équipements professionnels expédiés chaque semaine depuis Shenzhen vers le Cameroun, Congo, Gabon, Côte d'Ivoire, Bénin et toute l'Afrique."}
            </p>

            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
              <button
                onClick={() => navigateTo('catalog')}
                className="w-full sm:w-auto px-7 py-3.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer min-h-[48px] active:scale-95"
              >
                <span>Accéder au catalogue ({products.length} articles)</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => navigateTo('contact')}
                className="w-full sm:w-auto px-6 py-3.5 bg-[#183E66] hover:bg-[#1e4c7d] text-white font-bold rounded-xl text-xs uppercase tracking-wider border border-[#38BDF8]/20 transition-all cursor-pointer min-h-[48px] flex items-center justify-center"
              >
                Demander un devis groupage
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Transit Logistics Highlights */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-[#E2E8F0] card-shadow flex items-start gap-4">
            <div className="p-3 bg-[#EFF6FF] text-[#1D4ED8] rounded-xl shrink-0">
              <Plane className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#0F172A]">
                {settings.logisticAirTitle || 'Fret Aérien Express'}
              </h3>
              <p className="text-xs text-[#64748B] mt-1 leading-relaxed">
                {settings.logisticAirDesc ||
                  'Départ direct de Shenzhen chaque mardi et vendredi. Réception au dépôt sous 7 à 10 jours ouvrés avec dédouanement inclus.'}
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2E8F0] card-shadow flex items-start gap-4">
            <div className="p-3 bg-[#ECFDF5] text-[#059669] rounded-xl shrink-0">
              <Ship className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#0F172A]">
                {settings.logisticSeaTitle || 'Groupage Maritime Économique'}
              </h3>
              <p className="text-xs text-[#64748B] mt-1 leading-relaxed">
                {settings.logisticSeaDesc ||
                  'Conteneurs complets et groupage au mètre cube (CBM) pour gros volumes et marchandises lourdes. Transit 30 à 45 jours.'}
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#E2E8F0] card-shadow flex items-start gap-4">
            <div className="p-3 bg-[#FFFBEB] text-[#D97706] rounded-xl shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-[#0F172A]">
                {settings.logisticQualityTitle || 'Contrôle Qualité à Shenzhen'}
              </h3>
              <p className="text-xs text-[#64748B] mt-1 leading-relaxed">
                {settings.logisticQualityDesc ||
                  'Inspection minutieuse avant embarquement. Photos et vidéos de conformité envoyées avant tout départ pour l’Afrique.'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products Showcase */}
      <section className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
          <div>
            <span className="text-[11px] font-black uppercase tracking-wider text-[#D97706]">
              Sélection Import
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-[#0F172A] mt-0.5">
              Articles Populaires Prêts à l'Expédition
            </h2>
          </div>

          <button
            onClick={() => navigateTo('catalog')}
            className="text-xs font-bold text-[#0A2540] hover:text-[#F59E0B] flex items-center gap-1 cursor-pointer min-h-[44px] px-2"
          >
            <span>Tout voir</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 min-[360px]:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-5">
          {featuredProducts.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
};
