import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { ArrowLeft, Shield, FileText, Truck, RotateCcw } from 'lucide-react';

export const LegalPage: React.FC = () => {
  const { settings, navState, navigateTo } = useStore();

  const section = navState.orderRef || 'cgv';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      <button
        onClick={() => navigateTo('home')}
        className="inline-flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-900 cursor-pointer"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Retour à l’accueil</span>
      </button>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-stone-200 pb-3">
        <button
          onClick={() => navigateTo('legal', { orderRef: 'cgv' })}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
            section === 'cgv' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
          }`}
        >
          <FileText className="w-3.5 h-3.5" />
          <span>Conditions Générales (CGV)</span>
        </button>

        <button
          onClick={() => navigateTo('legal', { orderRef: 'privacy' })}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
            section === 'privacy' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
          }`}
        >
          <Shield className="w-3.5 h-3.5" />
          <span>Politique de Confidentialité</span>
        </button>

        <button
          onClick={() => navigateTo('legal', { orderRef: 'shipping' })}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
            section === 'shipping' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
          }`}
        >
          <Truck className="w-3.5 h-3.5" />
          <span>Livraison</span>
        </button>

        <button
          onClick={() => navigateTo('legal', { orderRef: 'returns' })}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
            section === 'returns' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
          }`}
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Retours</span>
        </button>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-stone-200 shadow-xs space-y-4">
        {section === 'cgv' && (
          <>
            <h1 className="font-serif text-2xl font-normal text-stone-900">
              Conditions Générales de Vente
            </h1>
            <div className="text-xs sm:text-sm text-stone-600 leading-relaxed whitespace-pre-line">
              {settings.termsAndConditions}
            </div>
          </>
        )}

        {section === 'privacy' && (
          <>
            <h1 className="font-serif text-2xl font-normal text-stone-900">
              Politique de Confidentialité
            </h1>
            <div className="text-xs sm:text-sm text-stone-600 leading-relaxed whitespace-pre-line">
              {settings.privacyPolicy}
            </div>
          </>
        )}

        {section === 'shipping' && (
          <>
            <h1 className="font-serif text-2xl font-normal text-stone-900">
              Informations de Livraison
            </h1>
            <div className="text-xs sm:text-sm text-stone-600 leading-relaxed whitespace-pre-line">
              {settings.shippingInfo}
            </div>
          </>
        )}

        {section === 'returns' && (
          <>
            <h1 className="font-serif text-2xl font-normal text-stone-900">
              Politique de Retours et Échanges
            </h1>
            <div className="text-xs sm:text-sm text-stone-600 leading-relaxed whitespace-pre-line">
              {settings.returnsInfo}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
