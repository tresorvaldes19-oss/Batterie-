import React, { useState, useEffect } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Order, OrderItem } from '../types/index.ts';
import { createOrder } from '../services/db.ts';
import confetti from 'canvas-confetti';
import {
  ShieldCheck,
  CheckCircle2,
  Package,
  Printer,
  ArrowRight,
  MessageSquare,
  Clock,
  Truck,
  CreditCard,
  ShoppingBag,
  User,
  Lock,
  Eye,
  EyeOff,
  UserPlus,
  LogIn,
  Check,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  Info,
} from 'lucide-react';

export const CheckoutPage: React.FC = () => {
  const {
    cart,
    cartSubtotal,
    cartShipping,
    cartTotal,
    currency,
    currencyInfo,
    openCurrencyModal,
    formatPrice,
    getFCFAEquivalent,
    getRawPrice,
    clearCart,
    customer,
    loginCustomer,
    registerCustomer,
    transferOrderToChat,
    getWhatsAppOrderUrl,
    navigateTo,
    openChatWithOrder,
    settings,
  } = useStore();

  // Contact & Delivery form states
  const [firstName, setFirstName] = useState(customer ? customer.firstName : '');
  const [lastName, setLastName] = useState(customer ? customer.lastName : '');
  const [email, setEmail] = useState(customer ? customer.email : '');
  const [phone, setPhone] = useState(customer ? customer.phone : '');
  const [address, setAddress] = useState(customer?.address?.street || '');
  const [city, setCity] = useState(customer?.address?.city || 'Douala');
  const [postalCode, setPostalCode] = useState(customer?.address?.postalCode || '');
  const [country, setCountry] = useState(customer?.address?.country || 'Cameroun');
  const [orderComment, setOrderComment] = useState('');

  // Account creation options during checkout
  const [createAccount, setCreateAccount] = useState(!customer);
  const [accountPassword, setAccountPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Returning customer inline login
  const [showInlineLogin, setShowInlineLogin] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Submission state
  const [loading, setLoading] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [chatTransferred, setChatTransferred] = useState(false);

  // Sync if customer logs in or changes
  useEffect(() => {
    if (customer) {
      if (!firstName) setFirstName(customer.firstName);
      if (!lastName) setLastName(customer.lastName);
      if (!email) setEmail(customer.email);
      if (!phone && customer.phone) setPhone(customer.phone);
      if (!address && customer.address?.street) setAddress(customer.address.street);
      if (customer.address?.city) setCity(customer.address.city);
      if (customer.address?.country) setCountry(customer.address.country);
      setCreateAccount(false);
    }
  }, [customer]);

  // Handle inline login
  const handleInlineLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (!loginEmail.trim()) {
      setLoginError('Veuillez entrer votre adresse email.');
      return;
    }
    setLoginLoading(true);
    try {
      const res = await loginCustomer(loginEmail.trim(), loginPass);
      if (res.success && res.customer) {
        setShowInlineLogin(false);
        setFirstName(res.customer.firstName);
        setLastName(res.customer.lastName);
        setEmail(res.customer.email);
        if (res.customer.phone) setPhone(res.customer.phone);
        if (res.customer.address?.street) setAddress(res.customer.address.street);
        if (res.customer.address?.city) setCity(res.customer.address.city);
        if (res.customer.address?.country) setCountry(res.customer.address.country);
        setCreateAccount(false);
      } else {
        setLoginError(res.message || 'Identifiants invalides.');
      }
    } catch {
      setLoginError('Erreur de connexion. Veuillez réessayer.');
    } finally {
      setLoginLoading(false);
    }
  };

  if (cart.length === 0 && !completedOrder) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-5">
        <div className="w-16 h-16 rounded-full bg-[#0A2540]/10 text-[#0A2540] flex items-center justify-center mx-auto">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <h2 className="font-bold text-2xl text-[#0F172A]">Votre panier est vide</h2>
        <p className="text-sm text-[#64748B]">
          Découvrez nos collections importées de Chine et ajoutez des articles à votre panier.
        </p>
        <button
          type="button"
          onClick={() => navigateTo('catalog')}
          className="min-h-[44px] px-6 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
        >
          Parcourir le catalogue
        </button>
      </div>
    );
  }

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Validation
    if (
      !firstName.trim() ||
      !lastName.trim() ||
      !email.trim() ||
      !phone.trim() ||
      !address.trim() ||
      !city.trim()
    ) {
      setFormError('Veuillez renseigner tous les champs obligatoires marqués d’un astérisque (*).');
      return;
    }

    setLoading(true);

    try {
      // 1. Account creation if requested and not yet logged in
      let currentCustomerId = customer?.id;
      if (!customer && createAccount) {
        try {
          const regRes = await registerCustomer({
            email: email.trim(),
            firstName: firstName.trim(),
            lastName: lastName.trim(),
            phone: phone.trim(),
            address: {
              street: address.trim(),
              city: city.trim(),
              postalCode: postalCode.trim(),
              country: country.trim(),
            },
            password: accountPassword.trim() || undefined,
          });
          if (regRes.customer) {
            currentCustomerId = regRes.customer.id;
          }
        } catch (regErr) {
          console.warn('Could not auto-register customer during checkout:', regErr);
        }
      }

      // 2. Prepare Order Object
      const orderRef = `ATE-${new Date().getFullYear().toString().slice(-2)}${Math.floor(10000 + Math.random() * 90000)}`;
      const orderId = `order_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

      const items: OrderItem[] = cart.map((c) => {
        const unitPrice = getRawPrice(c.product.priceEUR, c.product.priceUSD);
        return {
          productId: c.product.id,
          name: c.product.name,
          sku: c.product.sku,
          image: c.product.mainImage || c.product.images?.[0] || '',
          quantity: c.quantity,
          unitPrice,
          totalPrice: unitPrice * c.quantity,
        };
      });

      const newOrder: Order = {
        id: orderId,
        reference: orderRef,
        customerId: currentCustomerId,
        customer: {
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          address: address.trim(),
          city: city.trim(),
          postalCode: postalCode.trim(),
          country: country.trim(),
        },
        items,
        currency,
        subtotal: cartSubtotal,
        shippingCost: cartShipping,
        total: cartTotal,
        status: 'Nouvelle',
        notes: orderComment.trim() || undefined,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      // 3. Persist in database
      await createOrder(newOrder);

      // 4. CRITICAL: Automatically transfer order items (photo, price, description) into the discussion thread!
      try {
        await transferOrderToChat(newOrder);
        setChatTransferred(true);
      } catch (chatErr) {
        console.warn('Error transferring order into discussion chat:', chatErr);
      }

      // 5. Celebration & Clear Cart
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {}

      setCompletedOrder(newOrder);
      clearCart();
    } catch (err: any) {
      console.error('Order creation error:', err);
      setFormError('Une erreur est survenue lors de l’enregistrement de votre commande. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  // SUCCESS CONFIRMATION VIEW
  if (completedOrder) {
    const whatsAppHref = getWhatsAppOrderUrl(completedOrder);

    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10 sm:py-12 space-y-6">
        <div className="bg-white rounded-3xl border border-[#E2E8F0] p-6 sm:p-10 shadow-lg text-center space-y-6">
          <div className="w-16 h-16 rounded-full bg-[#10B981]/15 text-[#10B981] flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-black uppercase tracking-wider text-[#10B981]">
              Commande Transmise avec Succès !
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-[#0F172A] tracking-tight">
              Merci pour votre commande, {completedOrder.customer.firstName} !
            </h1>
            <p className="text-sm text-[#64748B] max-w-lg mx-auto">
              Votre commande <strong className="text-[#0A2540] font-mono font-bold text-base">#{completedOrder.reference}</strong> a été enregistrée dans notre système logistique.
            </p>
          </div>

          {/* CRITICAL NOTICE: Items transferred into the discussion */}
          <div className="bg-[#0A2540]/5 border-2 border-[#0A2540]/20 rounded-2xl p-4 sm:p-5 text-left space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-[#0A2540] text-white flex items-center justify-center shrink-0 mt-0.5">
                <MessageSquare className="w-4 h-4 text-[#F59E0B]" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-[#0A2540]">
                  Articles et informations transférés dans la discussion avec le commerçant !
                </h3>
                <p className="text-xs text-[#334155] leading-relaxed">
                  Toutes les photos, prix unitaires, quantités et descriptions des articles de votre panier ont été automatiquement retransmis dans votre fil de discussion avec l’équipe commerciale d’AfroTrade Express.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => openChatWithOrder(completedOrder.reference)}
                className="w-full min-h-[46px] py-2.5 px-4 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
              >
                <MessageSquare className="w-4 h-4 text-[#F59E0B]" />
                <span>Ouvrir la discussion en direct</span>
              </button>

              {whatsAppHref ? (
                <a
                  href={whatsAppHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full min-h-[46px] py-2.5 px-4 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
                >
                  <span>Discuter aussi sur WhatsApp</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              ) : (
                <div className="w-full min-h-[46px] py-2.5 px-4 bg-[#F1F5F9] text-[#64748B] rounded-xl text-xs font-semibold flex items-center justify-center gap-2 text-center">
                  <span>Numéro WhatsApp non configuré</span>
                </div>
              )}
            </div>
          </div>

          {/* Account status note */}
          {customer ? (
            <div className="bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl p-3 text-xs text-[#475569] flex items-center justify-between">
              <span>
                Compte client associé : <strong>{customer.email}</strong>
              </span>
              <button
                type="button"
                onClick={() => navigateTo('account')}
                className="text-[#0A2540] hover:underline font-bold text-xs cursor-pointer"
              >
                Voir mon espace client →
              </button>
            </div>
          ) : (
            createAccount && (
              <div className="bg-[#ECFDF5] border border-[#A7F3D0] rounded-xl p-3 text-xs text-[#065F46] text-left">
                ✓ Votre compte client a été créé avec succès avec l'adresse <strong>{completedOrder.customer.email}</strong>. Vous pouvez y accéder à tout moment pour suivre vos commandes et retrouver vos discussions.
              </div>
            )
          )}

          {/* Summary of items with photos & descriptions */}
          <div className="border border-[#E2E8F0] rounded-2xl p-4 sm:p-5 text-left text-xs space-y-3 bg-[#F8FAFC]">
            <div className="flex justify-between pb-3 border-b border-[#E2E8F0] font-bold text-[#0F172A]">
              <span>Articles transférés ({completedOrder.items.length})</span>
              <span>Total : {formatPrice(completedOrder.total, completedOrder.total)}</span>
            </div>

            <div className="divide-y divide-[#E2E8F0] max-h-72 overflow-y-auto pr-1">
              {completedOrder.items.map((it, idx) => (
                <div key={idx} className="py-2.5 flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <img
                      src={it.image}
                      alt={it.name}
                      className="w-12 h-12 rounded-lg object-contain bg-white border border-[#E2E8F0] shrink-0"
                    />
                    <div>
                      <p className="font-bold text-[#0F172A]">{it.name}</p>
                      <p className="text-[#64748B] font-mono text-[10px]">
                        Réf: {it.sku} • Qté: {it.quantity}
                      </p>
                      <p className="text-[11px] text-[#475569] mt-0.5">
                        Prix unitaire : {formatPrice(it.unitPrice, it.unitPrice)}
                      </p>
                    </div>
                  </div>
                  <span className="font-bold text-[#0A2540] shrink-0">
                    {formatPrice(it.totalPrice, it.totalPrice)}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-[#E2E8F0] grid grid-cols-1 sm:grid-cols-2 gap-4 text-[#475569]">
              <div>
                <p className="font-bold text-[#0F172A] mb-0.5">Coordonnées de livraison :</p>
                <p>{completedOrder.customer.firstName} {completedOrder.customer.lastName}</p>
                <p>{completedOrder.customer.address}</p>
                <p>{completedOrder.customer.city}, {completedOrder.customer.country}</p>
                <p className="font-mono font-semibold text-[#0A2540]">Tél : {completedOrder.customer.phone}</p>
              </div>

              <div>
                <p className="font-bold text-[#0F172A] mb-0.5">Statut de la commande :</p>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-[#FEF3C7] text-[#92400E] font-bold text-[11px]">
                  {completedOrder.status}
                </span>
                <p className="text-[11px] text-[#64748B] mt-1.5">
                  Équivalent : {getFCFAEquivalent(completedOrder.currency === 'USD' ? completedOrder.total : Math.round(completedOrder.total * 1.08))}
                </p>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="min-h-[44px] px-5 py-2.5 rounded-xl border border-[#CBD5E1] text-[#334155] hover:bg-[#F1F5F9] text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer le bordereau</span>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('account')}
              className="min-h-[44px] px-5 py-2.5 rounded-xl bg-[#0A2540] hover:bg-[#183E66] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <User className="w-4 h-4" />
              <span>Espace Client & Discussions</span>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('catalog')}
              className="min-h-[44px] px-5 py-2.5 rounded-xl border border-[#0A2540] text-[#0A2540] hover:bg-[#0A2540]/5 text-xs font-bold cursor-pointer"
            >
              Continuer mes achats
            </button>
          </div>
        </div>
      </div>
    );
  }

  // CHECKOUT FORM VIEW
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6">
      <div>
        <span className="text-xs font-black uppercase tracking-wider text-[#F59E0B]">
          Validation & Transfert Direct
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-[#0F172A] tracking-tight mt-0.5">
          Finaliser votre Commande
        </h1>
        <p className="text-xs sm:text-sm text-[#64748B] mt-1">
          Vos articles seront automatiquement transférés dans votre fil de discussion avec le commerçant.
        </p>
      </div>

      {formError && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-2xl font-medium flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{formError}</span>
        </div>
      )}

      {/* Customer authentication status card */}
      {customer ? (
        <div className="bg-[#0A2540]/5 border border-[#0A2540]/15 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#0A2540] text-white flex items-center justify-center font-bold text-sm shrink-0">
              {customer.firstName.charAt(0)}
            </div>
            <div>
              <p className="text-xs text-[#64748B]">Connecté en tant que client</p>
              <p className="text-sm font-bold text-[#0F172A]">
                {customer.firstName} {customer.lastName} ({customer.email})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigateTo('account')}
            className="text-xs font-bold text-[#0A2540] hover:underline self-start sm:self-auto cursor-pointer"
          >
            Gérer mon compte client →
          </button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-[#E2E8F0] p-4 shadow-xs space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-[#F59E0B]" />
              <span className="text-xs font-bold text-[#0F172A]">
                Création de votre compte client lors de la commande
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowInlineLogin(!showInlineLogin)}
              className="text-xs font-bold text-[#0A2540] hover:underline cursor-pointer flex items-center gap-1 self-start sm:self-auto"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>{showInlineLogin ? 'Fermer la connexion' : 'Déjà un compte ? Se connecter'}</span>
            </button>
          </div>

          {/* Inline Login Modal if toggled */}
          {showInlineLogin && (
            <form onSubmit={handleInlineLogin} className="p-4 bg-[#F8FAFC] rounded-xl border border-[#CBD5E1] space-y-3 animate-in fade-in duration-200">
              <p className="text-xs font-bold text-[#0F172A]">Connexion rapide à votre compte :</p>
              {loginError && (
                <p className="text-[11px] text-rose-600 font-semibold">{loginError}</p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="email"
                  required
                  placeholder="Votre adresse email"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#0F172A] focus:outline-none focus:ring-1 focus:ring-[#0A2540]"
                />
                <input
                  type="password"
                  placeholder="Mot de passe (facultatif si non défini)"
                  value={loginPass}
                  onChange={(e) => setLoginPass(e.target.value)}
                  className="px-3 py-2 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#0F172A] focus:outline-none focus:ring-1 focus:ring-[#0A2540]"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowInlineLogin(false)}
                  className="px-3 py-1.5 text-xs text-[#64748B] hover:text-[#0F172A] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  disabled={loginLoading}
                  className="px-4 py-1.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-lg text-xs font-bold cursor-pointer"
                >
                  {loginLoading ? 'Connexion...' : 'Se connecter'}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Form: Customer & Delivery details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Customer Contacts */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <h2 className="text-base font-bold text-[#0F172A] border-b border-[#F1F5F9] pb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#0A2540] text-white text-xs font-bold flex items-center justify-center">
                1
              </span>
              <span>Coordonnées du client</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Prénom <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="ex: Jean"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Nom de famille <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="ex: Dupont"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Adresse e-mail <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="jean.dupont@email.com"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
                <span className="text-[10px] text-[#64748B] mt-1 block">
                  Identifiant de votre compte & notification de commande.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Numéro de téléphone / WhatsApp <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+237 6 99 00 00 00"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
                <span className="text-[10px] text-[#64748B] mt-1 block">
                  Utilisé par le transporteur et pour la discussion avec le commerçant.
                </span>
              </div>
            </div>

            {/* Account creation password checkbox if not logged in */}
            {!customer && (
              <div className="pt-2 border-t border-[#F1F5F9] space-y-3">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={createAccount}
                    onChange={(e) => setCreateAccount(e.target.checked)}
                    className="w-4 h-4 rounded text-[#0A2540] accent-[#0A2540] cursor-pointer"
                  />
                  <span className="text-xs font-bold text-[#0F172A]">
                    Créer mon compte client AfroTrade Express avec ces informations
                  </span>
                </label>

                {createAccount && (
                  <div className="bg-[#F8FAFC] p-3.5 rounded-xl border border-[#E2E8F0] space-y-2 animate-in fade-in duration-200">
                    <label className="block text-xs font-bold text-[#334155]">
                      Définir un mot de passe pour votre compte client (recommandé)
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={accountPassword}
                        onChange={(e) => setAccountPassword(e.target.value)}
                        placeholder="Mot de passe sécurisé (min. 6 caractères)"
                        className="w-full px-3.5 py-2.5 pr-10 bg-white border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#0F172A] cursor-pointer"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[11px] text-[#64748B]">
                      Ce compte vous permettra de retrouver vos discussions avec le commerçant et de suivre vos expéditions.
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Delivery Address */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <h2 className="text-base font-bold text-[#0F172A] border-b border-[#F1F5F9] pb-3 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#0A2540] text-white text-xs font-bold flex items-center justify-center">
                2
              </span>
              <span>Adresse de livraison / Dépôt de destination</span>
            </h2>

            <div>
              <label className="block text-xs font-bold text-[#334155] mb-1">
                Quartier, Rue, Repère ou Voie <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="ex: Akwa, Carrefour Idéal, Immeuble..."
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Ville <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Douala, Yaoundé, Abidjan..."
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Code Postal / Boîte
                </label>
                <input
                  type="text"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="Facultatif"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Pays <span className="text-rose-500">*</span>
                </label>
                <select
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                >
                  <option value="Cameroun">Cameroun</option>
                  <option value="Côte d'Ivoire">Côte d'Ivoire</option>
                  <option value="Gabon">Gabon</option>
                  <option value="Congo">Congo</option>
                  <option value="Bénin">Bénin</option>
                  <option value="Sénégal">Sénégal</option>
                  <option value="Togo">Togo</option>
                  <option value="RDC">RDC</option>
                  <option value="France">France</option>
                  <option value="Autre pays">Autre pays</option>
                </select>
              </div>
            </div>
          </div>

          {/* Commentaire pour le commerçant */}
          <div className="bg-white p-6 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-3">
            <h2 className="text-base font-bold text-[#0F172A] border-b border-[#F1F5F9] pb-2 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-[#0A2540] text-white text-xs font-bold flex items-center justify-center">
                3
              </span>
              <span>Instructions & message particulier pour le commerçant</span>
            </h2>
            <textarea
              rows={3}
              value={orderComment}
              onChange={(e) => setOrderComment(e.target.value)}
              placeholder="Précisez ici vos souhaits particuliers (couleur préférée, délai d'urgence, fret aérien vs maritime, questions)..."
              className="w-full p-3 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
            />
          </div>

          {/* Payment & Transfer Explainer */}
          <div className="bg-[#0A2540]/5 border border-[#0A2540]/15 rounded-2xl p-4 sm:p-5 space-y-2">
            <div className="flex items-center gap-2 text-[#0A2540] font-bold text-xs">
              <Truck className="w-4 h-4 text-[#F59E0B]" />
              <span>Modalités de règlement & Prise en charge</span>
            </div>
            <p className="text-xs text-[#475569] leading-relaxed">
              Dès la validation, l'intégralité de vos articles (photos, descriptions, références, prix) est retransmise dans votre espace de discussion avec le commerçant. Vous conviendrez du moyen de règlement (Orange Money, MTN Mobile Money, virement bancaire, ou paiement à l'enlèvement) selon votre pays.
            </p>
          </div>
        </div>

        {/* Right: Order Summary Sidebar */}
        <div className="space-y-6">
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-[#E2E8F0] shadow-md space-y-5 sticky top-28">
            <div className="flex items-center justify-between border-b border-[#F1F5F9] pb-3">
              <div>
                <h2 className="text-lg font-bold text-[#0F172A]">
                  Récapitulatif Panier
                </h2>
                <button
                  type="button"
                  onClick={openCurrencyModal}
                  className="text-[11px] text-[#D97706] font-bold flex items-center gap-1 hover:underline cursor-pointer mt-0.5"
                >
                  <span>{currencyInfo.flag} Devise : {currencyInfo.code} ({currencyInfo.symbol})</span>
                  <span className="text-[10px] text-stone-400">Modifier ↗</span>
                </button>
              </div>
              <span className="text-xs font-bold text-[#0A2540] bg-[#0A2540]/10 px-2 py-0.5 rounded-full">
                {cart.length} {cart.length > 1 ? 'articles' : 'article'}
              </span>
            </div>

            {/* Items list with Photo, Price, and Description preview */}
            <div className="max-h-72 overflow-y-auto space-y-3 divide-y divide-[#F1F5F9] pr-1">
              {cart.map((item) => {
                return (
                  <div key={item.product.id} className="pt-3 first:pt-0 flex items-start gap-3">
                    <img
                      src={item.product.mainImage || item.product.images?.[0]}
                      alt={item.product.name}
                      className="w-12 h-12 rounded-lg object-contain bg-white border border-[#E2E8F0] shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-[#0F172A] truncate">
                        {item.product.name}
                      </p>
                      <p className="text-[10px] text-[#64748B]">
                        Qté: {item.quantity} • Réf: {item.product.sku}
                      </p>
                      <p className="text-[10px] text-[#475569] line-clamp-1 italic mt-0.5">
                        {item.product.description}
                      </p>
                    </div>
                    <span className="text-xs font-bold text-[#0A2540] shrink-0">
                      {formatPrice(
                        item.product.priceEUR * item.quantity,
                        item.product.priceUSD * item.quantity
                      )}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Calculations */}
            <div className="border-t border-[#E2E8F0] pt-4 space-y-2 text-xs text-[#64748B]">
              <div className="flex justify-between">
                <span>Sous-total ({currency})</span>
                <span className="font-bold text-[#0F172A]">
                  {formatPrice(cartSubtotal, cartSubtotal)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Frais d'acheminement</span>
                <span>
                  {cartShipping === 0 ? (
                    <span className="text-[#10B981] font-bold uppercase text-[10px]">
                      Offerts
                    </span>
                  ) : (
                    formatPrice(cartShipping, cartShipping)
                  )}
                </span>
              </div>
              <div className="pt-2 border-t border-[#E2E8F0] flex justify-between text-base font-bold text-[#0F172A]">
                <span>Total</span>
                <div className="text-right">
                  <div className="text-lg font-black text-[#0A2540]">
                    {formatPrice(cartTotal, cartTotal)}
                  </div>
                  <div className="text-[10px] text-[#64748B] font-normal">
                    {getFCFAEquivalent(currency === 'USD' ? cartTotal : Math.round(cartTotal * 1.08))}
                  </div>
                </div>
              </div>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full min-h-[48px] py-3.5 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              {loading ? (
                <span>Transmission de la commande...</span>
              ) : (
                <>
                  <span>Confirmer & Transférer dans la discussion</span>
                  <ArrowRight className="w-4 h-4 text-[#F59E0B]" />
                </>
              )}
            </button>

            <div className="space-y-1 text-center">
              <p className="text-[11px] text-[#64748B] flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#10B981]" />
                <span>Discussion directe sécurisée avec le commerçant</span>
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
