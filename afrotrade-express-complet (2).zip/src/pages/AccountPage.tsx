import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { CustomerProfile, Message, Order } from '../types/index.ts';
import {
  saveCustomerProfile,
  subscribeMessages,
  sendChatMessage,
} from '../services/db.ts';
import {
  User,
  Package,
  MessageSquare,
  LogOut,
  MapPin,
  Clock,
  CheckCircle,
  Truck,
  RotateCcw,
  Shield,
  ChevronRight,
  Eye,
  EyeOff,
  Send,
  ExternalLink,
  Phone,
  Mail,
  ShoppingBag,
  CheckCheck,
  AlertCircle,
  Lock,
  Bot,
} from 'lucide-react';
import { generateAiReply } from '../services/aiService.ts';

export const AccountPage: React.FC = () => {
  const {
    customer,
    setCustomer,
    loginCustomer,
    registerCustomer,
    logoutCustomer,
    orders,
    formatPrice,
    getFCFAEquivalent,
    currentConvoId,
    openChatWithOrder,
    getWhatsAppOrderUrl,
    settings,
    products,
    navigateTo,
  } = useStore();

  // Auth mode for guest
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  // Register fields
  const [regFirstName, setRegFirstName] = useState('');
  const [regLastName, setRegLastName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regStreet, setRegStreet] = useState('');
  const [regCity, setRegCity] = useState('Douala');
  const [regPostal, setRegPostal] = useState('');
  const [regCountry, setRegCountry] = useState('Cameroun');
  const [regPassword, setRegPassword] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  // Dashboard active tab
  const [activeTab, setActiveTab] = useState<'orders' | 'messages' | 'profile'>('orders');
  const [profileSuccess, setProfileSuccess] = useState(false);

  // Embedded discussion messages in account page
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [sendingMsg, setSendingMsg] = useState(false);
  const [aiTyping, setAiTyping] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Handle Login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!loginEmail.trim()) {
      setAuthError('Veuillez saisir votre adresse e-mail.');
      return;
    }
    setAuthLoading(true);
    try {
      const res = await loginCustomer(loginEmail.trim(), loginPassword);
      if (!res.success) {
        setAuthError(res.message || 'Identifiants invalides.');
      }
    } catch {
      setAuthError('Erreur de connexion. Veuillez réessayer.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle Register
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!regEmail.trim() || !regFirstName.trim() || !regLastName.trim()) {
      setAuthError('Veuillez renseigner votre prénom, nom et une adresse email valide.');
      return;
    }

    setAuthLoading(true);
    try {
      const res = await registerCustomer({
        email: regEmail.trim(),
        firstName: regFirstName.trim(),
        lastName: regLastName.trim(),
        phone: regPhone.trim(),
        address: {
          street: regStreet.trim(),
          city: regCity.trim(),
          postalCode: regPostal.trim(),
          country: regCountry.trim(),
        },
        password: regPassword.trim() || undefined,
      });

      if (!res.success) {
        setAuthError(res.message || 'Impossible de créer le compte.');
      }
    } catch {
      setAuthError('Erreur lors de la création de votre compte. Veuillez réessayer.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Handle profile update
  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer) return;
    await saveCustomerProfile(customer);
    setProfileSuccess(true);
    setTimeout(() => setProfileSuccess(false), 2500);
  };

  // Subscribe to customer discussion messages with smart optimistic merging
  useEffect(() => {
    if (!customer || !currentConvoId) return;
    const unsub = subscribeMessages(currentConvoId, (newMsgs) => {
      setMessages((prev) => {
        const map = new Map<string, Message>();
        newMsgs.forEach((m) => map.set(m.id, m));
        // Keep active optimistic messages until remote confirmation
        prev.forEach((m) => {
          if (m.id.startsWith('msg-opt-') || m.id.startsWith('msg-ai-opt-')) {
            const already = newMsgs.some(
              (nm) => nm.content === m.content && nm.sender === m.sender
            );
            if (!already) {
              map.set(m.id, m);
            }
          }
        });
        return Array.from(map.values()).sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
      });
    });
    return () => unsub();
  }, [customer, currentConvoId]);

  useEffect(() => {
    if (activeTab === 'messages') {
      chatScrollRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, aiTyping, activeTab]);

  const handleSendChatMessage = async (e?: React.FormEvent, directText?: string) => {
    if (e) e.preventDefault();
    const textToSend = (directText || chatInput).trim();
    if (!textToSend || !customer) return;

    // 1. INSTANT DIRECT VISIBILITY: Render message immediately in the UI (0ms delay)
    const tempId = `msg-opt-${Date.now()}`;
    const optimisticMsg: Message = {
      id: tempId,
      conversationId: currentConvoId,
      sender: 'customer',
      senderName: `${customer.firstName} ${customer.lastName}`,
      content: textToSend,
      read: false,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, optimisticMsg]);
    setChatInput('');
    setSendingMsg(true);

    try {
      // 2. Persist in database & local storage
      await sendChatMessage({
        conversationId: currentConvoId,
        sender: 'customer',
        senderName: `${customer.firstName} ${customer.lastName}`,
        customerEmail: customer.email,
        customerPhone: customer.phone,
        customerId: customer.id,
        content: textToSend,
      });

      // 3. Autonomous Full-time AI Assistant response (answers all questions directly 24/7)
      if (settings.aiAssistantEnabled !== false) {
        setAiTyping(true);
        setTimeout(async () => {
          try {
            const aiReply = await generateAiReply({
              userMessage: textToSend,
              conversationHistory: [...messages, optimisticMsg],
              settings,
              products,
              selectedCurrency: customerOrders[0]?.currency,
            });

            const aiSenderName =
              settings.aiMode === 'unavailability_only'
                ? `${settings.name} (Répondeur d'Absence)`
                : `Assistant Virtuel IA • ${settings.name}`;

            const aiOptimisticMsg: Message = {
              id: `msg-ai-opt-${Date.now()}`,
              conversationId: currentConvoId,
              sender: 'ai',
              senderName: aiSenderName,
              content: aiReply,
              isAi: true,
              read: false,
              createdAt: new Date().toISOString(),
            };

            // DIRECTLY RENDER AI RESPONSE IN UI IMMEDIATELY
            setMessages((prev) => [...prev, aiOptimisticMsg]);

            await sendChatMessage({
              conversationId: currentConvoId,
              sender: 'ai',
              senderName: aiSenderName,
              content: aiReply,
              isAi: true,
            });
          } catch (aiErr) {
            console.warn('AI response generation note in AccountPage:', aiErr);
          } finally {
            setAiTyping(false);
          }
        }, 700);
      }
    } catch (err) {
      console.error('Failed to send message from account page:', err);
    } finally {
      setSendingMsg(false);
    }
  };

  // Filter orders for logged-in user
  const customerOrders = orders.filter(
    (o) =>
      customer &&
      (o.customerId === customer.id ||
        o.customer.email.toLowerCase() === customer.email.toLowerCase())
  );

  // IF NOT LOGGED IN: SHOW MODERN LOGIN / REGISTER
  if (!customer) {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 sm:py-16">
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#CBD5E1] shadow-lg space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-full bg-[#0A2540] text-[#F59E0B] flex items-center justify-center mx-auto shadow-md">
              <User className="w-7 h-7" />
            </div>
            <h1 className="text-2xl font-black text-[#0F172A] tracking-tight">
              {authMode === 'login' ? 'Espace Client AfroTrade' : 'Créer un Compte Client'}
            </h1>
            <p className="text-xs text-[#64748B]">
              Suivez vos commandes et retrouvez vos discussions avec le commerçant en direct.
            </p>
          </div>

          {authError && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{authError}</span>
            </div>
          )}

          {/* Toggle buttons */}
          <div className="flex bg-[#F1F5F9] p-1 rounded-xl">
            <button
              type="button"
              onClick={() => {
                setAuthMode('login');
                setAuthError(null);
              }}
              className={`flex-1 min-h-[44px] py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authMode === 'login'
                  ? 'bg-white text-[#0A2540] shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              Se Connecter
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode('register');
                setAuthError(null);
              }}
              className={`flex-1 min-h-[44px] py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                authMode === 'register'
                  ? 'bg-white text-[#0A2540] shadow-xs'
                  : 'text-[#64748B] hover:text-[#0F172A]'
              }`}
            >
              Créer un Compte
            </button>
          </div>

          {authMode === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Adresse e-mail
                </label>
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="votre.email@exemple.com"
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Mot de passe
                </label>
                <div className="relative">
                  <input
                    type={showLoginPassword ? 'text' : 'password'}
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Votre mot de passe"
                    className="w-full px-3.5 py-2.5 pr-10 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#0F172A] cursor-pointer"
                  >
                    {showLoginPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full min-h-[46px] py-3 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors shadow-md cursor-pointer"
              >
                {authLoading ? 'Connexion en cours...' : 'Accéder à mon espace client'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Prénom <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regFirstName}
                    onChange={(e) => setRegFirstName(e.target.value)}
                    placeholder="Jean"
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Nom <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regLastName}
                    onChange={(e) => setRegLastName(e.target.value)}
                    placeholder="Dupont"
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Adresse e-mail <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="jean.dupont@email.com"
                  className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Numéro de téléphone / WhatsApp <span className="text-rose-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="+237 6 99 00 00 00"
                  className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Ville <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={regCity}
                    onChange={(e) => setRegCity(e.target.value)}
                    placeholder="Douala, Yaoundé, Abidjan..."
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Pays <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={regCountry}
                    onChange={(e) => setRegCountry(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  >
                    <option value="Cameroun">Cameroun</option>
                    <option value="Côte d'Ivoire">Côte d'Ivoire</option>
                    <option value="Gabon">Gabon</option>
                    <option value="Congo">Congo</option>
                    <option value="Bénin">Bénin</option>
                    <option value="Sénégal">Sénégal</option>
                    <option value="Togo">Togo</option>
                    <option value="RDC">RDC</option>
                    <option value="France">France</option>
                    <option value="Autre pays">Autre pays</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Mot de passe (facultatif ou min. 6 caractères)
                </label>
                <div className="relative">
                  <input
                    type={showRegPassword ? 'text' : 'password'}
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Créer un mot de passe sécurisé"
                    className="w-full px-3 py-2 pr-10 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPassword(!showRegPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#0F172A] cursor-pointer"
                  >
                    {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full min-h-[46px] py-3 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors shadow-md cursor-pointer"
              >
                {authLoading ? 'Création en cours...' : 'Créer mon compte client'}
              </button>
            </form>
          )}

          <div className="pt-2 border-t border-[#F1F5F9] text-center">
            <button
              type="button"
              onClick={() => navigateTo('catalog')}
              className="text-xs text-[#64748B] hover:text-[#0A2540] font-medium cursor-pointer"
            >
              ← Retourner au catalogue sans se connecter
            </button>
          </div>
        </div>
      </div>
    );
  }

  // LOGGED-IN CUSTOMER DASHBOARD
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 space-y-6">
      {/* Top Customer Header Banner */}
      <div className="bg-[#0A2540] text-white p-6 sm:p-8 rounded-3xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6 border border-[#183E66]">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-[#183E66] border border-[#F59E0B]/40 text-[#F59E0B] font-black text-2xl flex items-center justify-center shrink-0 shadow-inner">
            {customer.firstName.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#F59E0B]">
                Espace Client
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
              <span className="text-[10px] text-[#A5B4FC]">Actif</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-0.5">
              Bonjour, {customer.firstName} {customer.lastName}
            </h1>
            <p className="text-xs text-[#94A3B8] mt-0.5">
              {customer.email} • {customer.phone || 'Téléphone non renseigné'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-start md:self-auto">
          <button
            type="button"
            onClick={logoutCustomer}
            className="min-h-[44px] px-4 py-2 bg-[#183E66] hover:bg-rose-900/60 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-2 cursor-pointer border border-white/10"
          >
            <LogOut className="w-4 h-4" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-[#CBD5E1] gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('orders')}
          className={`min-h-[44px] pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'orders'
              ? 'border-[#0A2540] text-[#0A2540]'
              : 'border-transparent text-[#64748B] hover:text-[#0F172A]'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Mes Commandes ({customerOrders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('messages')}
          className={`min-h-[44px] pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'messages'
              ? 'border-[#0A2540] text-[#0A2540]'
              : 'border-transparent text-[#64748B] hover:text-[#0F172A]'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Mes Discussions avec le Commerçant ({messages.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('profile')}
          className={`min-h-[44px] pb-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 cursor-pointer transition-all whitespace-nowrap ${
            activeTab === 'profile'
              ? 'border-[#0A2540] text-[#0A2540]'
              : 'border-transparent text-[#64748B] hover:text-[#0F172A]'
          }`}
        >
          <User className="w-4 h-4" />
          <span>Mon Profil & Coordonnées</span>
        </button>
      </div>

      {/* TAB 1: MES COMMANDES */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {customerOrders.length === 0 ? (
            <div className="bg-white rounded-3xl border border-[#CBD5E1] p-12 text-center space-y-4 shadow-xs">
              <Package className="w-12 h-12 text-[#94A3B8] mx-auto" />
              <h3 className="font-bold text-base text-[#0F172A]">Aucune commande enregistrée</h3>
              <p className="text-xs text-[#64748B] max-w-sm mx-auto">
                Vous n'avez pas encore passé de commande avec ce compte. Explorez nos arrivages directs depuis la Chine.
              </p>
              <button
                type="button"
                onClick={() => navigateTo('catalog')}
                className="min-h-[44px] px-6 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
              >
                Découvrir le catalogue
              </button>
            </div>
          ) : (
            customerOrders.map((order) => {
              const whatsAppHref = getWhatsAppOrderUrl(order);

              return (
                <div
                  key={order.id}
                  className="bg-white rounded-3xl border border-[#CBD5E1] p-5 sm:p-6 shadow-xs space-y-4 hover:shadow-md transition-shadow"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#F1F5F9] gap-2">
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
                        Commande n°
                      </span>
                      <h3 className="font-mono font-black text-base text-[#0A2540]">
                        #{order.reference}
                      </h3>
                      <p className="text-[11px] text-[#94A3B8]">
                        Passée le {new Date(order.createdAt).toLocaleDateString('fr-FR', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-[#FEF3C7] text-[#92400E]">
                        {order.status}
                      </span>
                      <div className="text-right">
                        <div className="text-base font-black text-[#0F172A]">
                          {formatPrice(order.total, order.total)}
                        </div>
                        <div className="text-[10px] text-[#64748B]">
                          {getFCFAEquivalent(order.currency === 'USD' ? order.total : Math.round(order.total * 1.08))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Items list */}
                  <div className="divide-y divide-[#F1F5F9] space-y-2">
                    {order.items.map((it, idx) => (
                      <div key={idx} className="pt-2 first:pt-0 flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <img
                            src={it.image}
                            alt={it.name}
                            className="w-12 h-12 rounded-lg object-contain bg-white border border-[#CBD5E1] shrink-0"
                          />
                          <div>
                            <p className="font-bold text-xs text-[#0F172A]">{it.name}</p>
                            <p className="text-[11px] text-[#64748B]">
                              Réf: {it.sku} • Quantité : <strong>{it.quantity}</strong>
                            </p>
                            <p className="text-[10px] text-[#64748B]">
                              Prix unitaire : {formatPrice(it.unitPrice, it.unitPrice)}
                            </p>
                          </div>
                        </div>
                        <span className="font-bold text-xs text-[#0A2540] shrink-0">
                          {formatPrice(it.totalPrice, it.totalPrice)}
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Actions for this order */}
                  <div className="pt-3 border-t border-[#F1F5F9] flex flex-wrap items-center justify-between gap-3">
                    <div className="text-xs text-[#64748B]">
                      <span>Livraison : </span>
                      <strong className="text-[#0F172A]">
                        {order.customer.city}, {order.customer.country} ({order.customer.address})
                      </strong>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      <button
                        type="button"
                        onClick={() => {
                          openChatWithOrder(order.reference);
                          setActiveTab('messages');
                        }}
                        className="min-h-[44px] px-4 py-2 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <MessageSquare className="w-4 h-4 text-[#F59E0B]" />
                        <span>Discuter de cette commande</span>
                      </button>

                      {whatsAppHref && (
                        <a
                          href={whatsAppHref}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="min-h-[44px] px-4 py-2 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <span>WhatsApp</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* TAB 2: MES DISCUSSIONS AVEC LE COMMERÇANT */}
      {activeTab === 'messages' && (
        <div className="bg-white rounded-3xl border border-[#CBD5E1] shadow-md overflow-hidden flex flex-col h-[640px]">
          {/* Header */}
          <div className="p-4 sm:px-6 bg-[#0A2540] text-white flex items-center justify-between border-b border-[#183E66]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#183E66] border border-[#F59E0B]/40 flex items-center justify-center font-black text-[#F59E0B] text-base shrink-0">
                {settings.name?.charAt(0) || 'A'}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold text-sm text-white">
                    Discussion Officielle • {settings.name}
                  </h3>
                  <span className="px-2 py-0.5 rounded-full bg-[#7C3AED]/40 border border-[#A78BFA]/50 text-[#DDD6FE] text-[10px] font-bold flex items-center gap-1">
                    <Bot className="w-3 h-3 text-[#A78BFA]" />
                    <span>IA Active 24/7 & Propriétaire</span>
                  </span>
                </div>
                <p className="text-[11px] text-[#F59E0B] flex items-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                  <span>Vos questions, articles et commandes sont archivés et synchronisés en direct</span>
                </p>
              </div>
            </div>

            <a
              href={`https://wa.me/${(settings.whatsappPhone || '237699452010').replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-1.5 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-xs shrink-0"
            >
              <span>Ouvrir WhatsApp</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Messages body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-[#F8FAFC]">
            {messages.length === 0 ? (
              <div className="text-center py-16 text-xs text-[#94A3B8] space-y-2">
                <MessageSquare className="w-10 h-10 mx-auto text-[#CBD5E1]" />
                <p className="font-medium text-sm text-[#0F172A]">Aucun message pour le moment.</p>
                <p className="text-xs text-[#64748B]">
                  Posez toutes vos questions sur les articles du catalogue, les prix convertis en devises locales, ou échangez sur vos commandes en cours. L'IA et l'équipe commerciale vous répondent directement ici !
                </p>
              </div>
            ) : (
              messages.map((m) => {
                const isMe = m.sender === 'customer';
                return (
                  <div
                    key={m.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                  >
                    <div
                      className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-2xl text-xs leading-relaxed ${
                        isMe
                          ? 'bg-[#0A2540] text-white rounded-tr-xs shadow-xs'
                          : m.isAi || m.sender === 'ai'
                          ? 'bg-[#FAF5FF] text-[#0F172A] rounded-tl-xs border border-[#E9D5FF] shadow-2xs'
                          : 'bg-white text-[#0F172A] rounded-tl-xs border border-[#CBD5E1] shadow-2xs'
                      }`}
                    >
                      <span
                        className={`block text-[10px] font-black uppercase mb-1 tracking-wider ${
                          isMe
                            ? 'text-[#F59E0B]'
                            : m.isAi || m.sender === 'ai'
                            ? 'text-[#7C3AED] flex items-center gap-1'
                            : 'text-[#D97706]'
                        }`}
                      >
                        {isMe ? (
                          `Vous (${customer.firstName})`
                        ) : m.isAi || m.sender === 'ai' ? (
                          <>
                            <Bot className="w-3 h-3 text-[#7C3AED]" />
                            <span>Assistant IA • {settings.name}</span>
                          </>
                        ) : (
                          `${settings.name} (Service Commercial)`
                        )}
                      </span>

                      {/* Attached order card if present */}
                      {m.attachedOrder ? (
                        <div
                          className={`rounded-xl p-3.5 border mb-2 text-left ${
                            isMe
                              ? 'bg-[#183E66] border-[#2E5B88] text-white'
                              : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0F172A]'
                          }`}
                        >
                          <div className="flex items-center justify-between pb-2 border-b border-current/15 gap-2">
                            <span className="font-bold text-xs">
                              Commande #{m.attachedOrder.orderRef}
                            </span>
                            <span className="text-xs font-black text-[#F59E0B]">
                              {formatPrice(m.attachedOrder.total, m.attachedOrder.total)}
                            </span>
                          </div>

                          <div className="mt-2 space-y-2">
                            {m.attachedOrder.items.map((it, idx) => (
                              <div
                                key={idx}
                                className={`p-2 rounded-lg flex items-start gap-2.5 ${
                                  isMe ? 'bg-[#0A2540]/60' : 'bg-white border border-[#CBD5E1]'
                                }`}
                              >
                                <img
                                  src={it.image}
                                  alt={it.name}
                                  className="w-12 h-12 rounded-lg object-contain bg-white border border-current/15 shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="font-bold text-xs truncate">{it.name}</p>
                                  <p className="text-[10px] opacity-80">
                                    Qté: {it.quantity} • Prix : {formatPrice(it.unitPrice, it.unitPrice)}
                                  </p>
                                  {it.description && (
                                    <p className="text-[10px] mt-0.5 opacity-80 line-clamp-2">
                                      {it.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <p className="whitespace-pre-wrap">{m.content}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-1 text-[10px] text-[#94A3B8] px-1">
                      <span>
                        {new Date(m.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                      {isMe && <CheckCheck className="w-3 h-3 text-[#94A3B8]" />}
                    </div>
                  </div>
                );
              })
            )}

            {aiTyping && (
              <div className="flex items-center gap-2 p-3 bg-white border border-[#CBD5E1] rounded-2xl w-fit text-xs text-[#64748B] shadow-2xs">
                <Bot className="w-4 h-4 text-[#7C3AED] animate-pulse shrink-0" />
                <span className="font-semibold text-[11px] text-[#7C3AED]">
                  L'assistant IA vérifie les stocks et vous répond...
                </span>
                <span className="flex gap-1 items-center">
                  <span className="w-1.5 h-1.5 bg-[#7C3AED] rounded-full animate-bounce [animation-delay:-0.3s]" />
                  <span className="w-1.5 h-1.5 bg-[#7C3AED] rounded-full animate-bounce [animation-delay:-0.15s]" />
                  <span className="w-1.5 h-1.5 bg-[#7C3AED] rounded-full animate-bounce" />
                </span>
              </div>
            )}
            <div ref={chatScrollRef} />
          </div>

          {/* Quick suggestions chips */}
          <div className="px-3.5 py-2 border-t border-[#E2E8F0] bg-[#F8FAFC] flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            <span className="text-[10px] text-[#94A3B8] font-bold uppercase shrink-0 hidden sm:inline">
              Questions rapides :
            </span>
            <button
              type="button"
              onClick={() => handleSendChatMessage(undefined, "L'ordinateur le plus moins cher disponible ?")}
              className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#0A2540] border border-[#CBD5E1] rounded-lg text-[11px] font-semibold shrink-0 cursor-pointer transition-colors shadow-2xs"
            >
              💻 L'ordinateur le moins cher ?
            </button>
            <button
              type="button"
              onClick={() => handleSendChatMessage(undefined, "Quels sont les téléphones disponibles en stock ?")}
              className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#0A2540] border border-[#CBD5E1] rounded-lg text-[11px] font-semibold shrink-0 cursor-pointer transition-colors shadow-2xs"
            >
              📱 Téléphones en stock ?
            </button>
            <button
              type="button"
              onClick={() => handleSendChatMessage(undefined, "Quels sont vos délais et tarifs de fret aérien express ?")}
              className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#0A2540] border border-[#CBD5E1] rounded-lg text-[11px] font-semibold shrink-0 cursor-pointer transition-colors shadow-2xs"
            >
              ✈️ Délais fret aérien ?
            </button>
            <button
              type="button"
              onClick={() => handleSendChatMessage(undefined, "Comment payer par Orange Money ou Wave ?")}
              className="px-2.5 py-1 bg-white hover:bg-[#F1F5F9] text-[#0A2540] border border-[#CBD5E1] rounded-lg text-[11px] font-semibold shrink-0 cursor-pointer transition-colors shadow-2xs"
            >
              💳 Paiement Mobile Money ?
            </button>
          </div>

          {/* Chat input */}
          <form
            onSubmit={handleSendChatMessage}
            className="p-3.5 bg-white border-t border-[#E2E8F0] flex items-center gap-2"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Écrivez votre question au commerçant..."
              disabled={sendingMsg}
              className="flex-1 min-h-[44px] px-4 py-2 bg-[#F1F5F9] rounded-xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white transition-all"
            />
            <button
              type="submit"
              disabled={!chatInput.trim() || sendingMsg}
              className="min-h-[44px] px-5 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-40 text-white rounded-xl text-xs font-bold transition-colors shrink-0 cursor-pointer shadow-xs flex items-center gap-1.5"
            >
              <Send className="w-4 h-4 text-[#F59E0B]" />
              <span>Envoyer</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: MON PROFIL & COORDONNÉES */}
      {activeTab === 'profile' && (
        <div className="bg-white rounded-3xl border border-[#CBD5E1] p-6 sm:p-8 shadow-xs max-w-2xl space-y-6">
          <div className="border-b border-[#F1F5F9] pb-4">
            <h2 className="text-lg font-black text-[#0F172A]">Informations de votre compte</h2>
            <p className="text-xs text-[#64748B]">
              Ces coordonnées sont pré-remplies lors de vos prochaines commandes.
            </p>
          </div>

          {profileSuccess && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl font-bold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>Vos informations personnelles ont été mises à jour avec succès !</span>
            </div>
          )}

          <form onSubmit={handleUpdateProfile} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">Prénom</label>
                <input
                  type="text"
                  value={customer.firstName}
                  onChange={(e) => setCustomer({ ...customer, firstName: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">Nom</label>
                <input
                  type="text"
                  value={customer.lastName}
                  onChange={(e) => setCustomer({ ...customer, lastName: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#334155] mb-1">Adresse e-mail</label>
              <input
                type="email"
                disabled
                value={customer.email}
                className="w-full px-3.5 py-2.5 bg-[#F1F5F9] border border-[#CBD5E1] rounded-xl text-xs text-[#64748B] cursor-not-allowed"
              />
              <span className="text-[10px] text-[#94A3B8] mt-1 block">
                L'adresse e-mail sert d'identifiant unique.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#334155] mb-1">Numéro de téléphone / WhatsApp</label>
              <input
                type="tel"
                value={customer.phone}
                onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#334155] mb-1">Adresse habituelle de livraison</label>
              <input
                type="text"
                value={customer.address?.street || ''}
                onChange={(e) =>
                  setCustomer({
                    ...customer,
                    address: {
                      ...(customer.address || { city: '', postalCode: '', country: 'Cameroun' }),
                      street: e.target.value,
                    },
                  })
                }
                placeholder="Rue, Quartier, Carrefour..."
                className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">Ville</label>
                <input
                  type="text"
                  value={customer.address?.city || ''}
                  onChange={(e) =>
                    setCustomer({
                      ...customer,
                      address: {
                        ...(customer.address || { street: '', postalCode: '', country: 'Cameroun' }),
                        city: e.target.value,
                      },
                    })
                  }
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">Pays</label>
                <input
                  type="text"
                  value={customer.address?.country || 'Cameroun'}
                  onChange={(e) =>
                    setCustomer({
                      ...customer,
                      address: {
                        ...(customer.address || { street: '', postalCode: '', city: '' }),
                        country: e.target.value,
                      },
                    })
                  }
                  className="w-full px-3.5 py-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="min-h-[46px] px-6 py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer shadow-xs"
            >
              Enregistrer les modifications
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
