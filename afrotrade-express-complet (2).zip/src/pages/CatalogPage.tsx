import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { CategoryTabs } from '../components/CategoryTabs.tsx';
import { SearchAndFilters } from '../components/SearchAndFilters.tsx';
import { ProductCard } from '../components/ProductCard.tsx';
import { Product } from '../types/index.ts';
import { Package, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

export const CatalogPage: React.FC = () => {
  const { products, currency } = useStore();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(1000);
  const [appliedMinPrice, setAppliedMinPrice] = useState<number>(0);
  const [appliedMaxPrice, setAppliedMaxPrice] = useState<number>(1000);
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'popular'>(
    'newest'
  );
  const [currentPage, setCurrentPage] = useState<number>(1);
  const ITEMS_PER_PAGE = 20;

  const handleApplyFilter = () => {
    setAppliedMinPrice(minPrice);
    setAppliedMaxPrice(maxPrice);
    setCurrentPage(1);
  };

  const handleResetFilter = () => {
    setSearchTerm('');
    setSelectedCategory('all');
    setMinPrice(0);
    setMaxPrice(1000);
    setAppliedMinPrice(0);
    setAppliedMaxPrice(1000);
    setSortBy('newest');
    setCurrentPage(1);
  };

  // Filter & sort
  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (p.status === 'brouillon' || p.status === 'archive') return false;

        // Search text
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchSku = p.sku.toLowerCase().includes(q);
          const matchCat = p.category.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          if (!matchName && !matchSku && !matchCat && !matchDesc) return false;
        }

        // Category filter
        if (selectedCategory !== 'all' && selectedCategory !== 'Tous') {
          if (p.category.toLowerCase() !== selectedCategory.toLowerCase()) {
            return false;
          }
        }

        // Price filter
        const price = currency === 'USD' ? p.priceUSD : p.priceEUR;
        if (appliedMinPrice > 0 && price < appliedMinPrice) return false;
        if (appliedMaxPrice < 1000 && price > appliedMaxPrice) return false;

        return true;
      })
      .sort((a, b) => {
        const priceA = currency === 'USD' ? a.priceUSD : a.priceEUR;
        const priceB = currency === 'USD' ? b.priceUSD : b.priceEUR;

        if (sortBy === 'price-asc') return priceA - priceB;
        if (sortBy === 'price-desc') return priceB - priceA;
        if (sortBy === 'popular') return (b.reviewsCount || 0) - (a.reviewsCount || 0);
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }, [products, searchTerm, selectedCategory, appliedMinPrice, appliedMaxPrice, sortBy, currency]);

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / ITEMS_PER_PAGE) || 1;
  const paginated = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredProducts.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredProducts, currentPage]);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
      window.scrollTo({ top: 120, behavior: 'smooth' });
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
      {/* Category Tabs */}
      <section>
        <CategoryTabs
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            setCurrentPage(1);
          }}
        />
      </section>

      {/* Search and Filters Bar */}
      <section>
        <SearchAndFilters
          searchTerm={searchTerm}
          setSearchTerm={(s) => {
            setSearchTerm(s);
            setCurrentPage(1);
          }}
          minPrice={minPrice}
          setMinPrice={setMinPrice}
          maxPrice={maxPrice}
          setMaxPrice={setMaxPrice}
          sortBy={sortBy}
          setSortBy={setSortBy}
          onApplyFilter={handleApplyFilter}
          onResetFilter={handleResetFilter}
          totalFound={filteredProducts.length}
        />
      </section>

      {/* Product Grid: 5 cols 2xl, 4 cols desktop, 3 cols tablet, 2 cols mobile */}
      <section>
        {paginated.length === 0 ? (
          <div className="bg-white rounded-3xl border border-[#E2E8F0] p-12 text-center space-y-4 my-8 card-shadow">
            <div className="w-16 h-16 rounded-full bg-[#F1F5F9] text-[#64748B] flex items-center justify-center mx-auto">
              <Package className="w-8 h-8" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Aucun produit ne correspond à votre recherche
            </h3>
            <p className="text-xs text-[#64748B] max-w-sm mx-auto">
              Essayez de réinitialiser vos filtres ou explorez une autre catégorie d'importation Chine-Afrique.
            </p>
            <button
              onClick={handleResetFilter}
              className="px-6 py-2.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase cursor-pointer"
            >
              Réinitialiser les filtres
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 min-[360px]:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5 gap-3 sm:gap-5">
            {paginated.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <section className="pt-6 border-t border-[#E2E8F0] flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap">
          <button
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
            className="min-w-[44px] min-h-[44px] p-2.5 rounded-xl border border-[#E2E8F0] bg-white text-[#0A2540] disabled:opacity-40 hover:bg-[#F8FAFC] transition-colors cursor-pointer flex items-center justify-center"
            aria-label="Précédent"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
            <button
              key={pageNum}
              onClick={() => handlePageChange(pageNum)}
              className={`min-w-[44px] min-h-[44px] w-11 h-11 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center ${
                currentPage === pageNum
                  ? 'bg-[#0A2540] text-white shadow-sm'
                  : 'bg-white border border-[#E2E8F0] text-[#0F172A] hover:bg-[#F8FAFC]'
              }`}
            >
              {pageNum}
            </button>
          ))}

          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
            className="min-w-[44px] min-h-[44px] p-2.5 rounded-xl border border-[#E2E8F0] bg-white text-[#0A2540] disabled:opacity-40 hover:bg-[#F8FAFC] transition-colors cursor-pointer flex items-center justify-center"
            aria-label="Suivant"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </section>
      )}
    </div>
  );
};
