import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  ShieldCheck,
  Truck,
} from 'lucide-react';

export const CartPage: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    cartSubtotal,
    cartShipping,
    cartTotal,
    freeShippingRemaining,
    currency,
    currencyInfo,
    setCurrency,
    openCurrencyModal,
    formatPrice,
    navigateTo,
  } = useStore();

  const [orderNote, setOrderNote] = useState('');

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <div className="w-20 h-20 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mx-auto">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h1 className="font-serif text-3xl font-medium text-stone-900">Votre panier est vide</h1>
        <p className="text-sm text-stone-500 max-w-sm mx-auto">
          Vous n'avez pas encore sélectionné de pièce dans notre boutique en ligne.
        </p>
        <div className="pt-4">
          <button
            onClick={() => navigateTo('catalog')}
            className="px-8 py-3.5 bg-stone-900 hover:bg-stone-800 text-white rounded-full text-xs font-semibold tracking-wider transition-all shadow-md cursor-pointer"
          >
            Découvrir le catalogue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-stone-200 gap-4">
        <div>
          <button
            onClick={() => navigateTo('catalog')}
            className="inline-flex items-center gap-1.5 text-xs text-stone-500 hover:text-stone-900 mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Poursuivre mes achats</span>
          </button>
          <h1 className="font-serif text-3xl font-normal text-stone-900">
            Mon Panier d'Achats
          </h1>
        </div>

        {/* Currency Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-stone-500 font-medium">Devise de facturation :</span>
          <button
            type="button"
            onClick={openCurrencyModal}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white hover:bg-stone-50 text-stone-900 border border-stone-300 shadow-2xs font-bold text-xs cursor-pointer transition-all"
            title="Changer de devise parmi les 54 pays africains"
          >
            <span className="text-base">{currencyInfo.flag}</span>
            <span className="text-[#0A2540] font-black">{currencyInfo.code}</span>
            <span className="text-[#D97706]">({currencyInfo.symbol})</span>
            <span className="text-[11px] text-stone-400 font-normal">Changer ↗</span>
          </button>
        </div>
      </div>

      {/* Free Shipping Alert */}
      <div className="bg-amber-50/80 border border-amber-200/70 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-100 text-amber-800 rounded-xl">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-semibold text-amber-950">
              {freeShippingRemaining > 0
                ? `Plus que ${formatPrice(freeShippingRemaining, freeShippingRemaining)} pour la livraison offerte !`
                : 'Félicitations, vous bénéficiez de la livraison offerte !'}
            </h4>
            <p className="text-xs text-amber-800/80 mt-0.5">
              Seuil de gratuité automatique dès {formatPrice(120, 130)} d'achats.
            </p>
          </div>
        </div>
        <div className="w-full sm:w-48 bg-amber-200/80 rounded-full h-2 overflow-hidden shrink-0">
          <div
            className="bg-amber-700 h-full rounded-full transition-all duration-500"
            style={{
              width: `${Math.min(100, Math.max(10, ((120 - freeShippingRemaining) / 120) * 100))}%`,
            }}
          />
        </div>
      </div>

      {/* Main Grid: Item List & Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Items List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-stone-200 divide-y divide-stone-100 overflow-hidden shadow-xs">
            {cart.map((item) => {
              const unitPrice =
                currency === 'USD' ? item.product.priceUSD : item.product.priceEUR;
              const totalPrice = unitPrice * item.quantity;

              return (
                <div key={item.product.id} className="p-5 sm:p-6 flex flex-col sm:flex-row gap-5">
                  <img
                    src={item.product.mainImage || item.product.images?.[0]}
                    alt={item.product.name}
                    className="w-24 h-24 rounded-xl object-cover bg-stone-100 border border-stone-200 shrink-0 cursor-pointer"
                    onClick={() =>
                      navigateTo('product-detail', { productId: item.product.id })
                    }
                  />

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <span className="text-[11px] font-semibold uppercase tracking-wider text-amber-800">
                            {item.product.category}
                          </span>
                          <h3
                            onClick={() =>
                              navigateTo('product-detail', { productId: item.product.id })
                            }
                            className="font-medium text-stone-900 text-base hover:text-amber-800 transition-colors cursor-pointer"
                          >
                            {item.product.name}
                          </h3>
                          <span className="text-xs font-mono text-stone-400">
                            Réf: {item.product.sku}
                          </span>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-stone-400 hover:text-rose-600 p-1.5 transition-colors cursor-pointer"
                          title="Supprimer du panier"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="pt-4 flex items-center justify-between">
                      {/* Quantity Controls */}
                      <div className="flex items-center border border-stone-300 rounded-xl overflow-hidden bg-white shadow-2xs">
                        <button
                          onClick={() =>
                            updateCartQuantity(item.product.id, item.quantity - 1)
                          }
                          className="p-2 hover:bg-stone-100 text-stone-600 transition-colors"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-3.5 text-xs font-semibold text-stone-900">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateCartQuantity(item.product.id, item.quantity + 1)
                          }
                          className="p-2 hover:bg-stone-100 text-stone-600 transition-colors"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Total for this line */}
                      <div className="text-right">
                        <span className="font-serif text-lg font-bold text-stone-900">
                          {formatPrice(totalPrice, totalPrice)}
                        </span>
                        {item.quantity > 1 && (
                          <span className="block text-[11px] text-stone-400">
                            {formatPrice(unitPrice, unitPrice)} par unité
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Optional Order Note */}
          <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-stone-700">
              Commentaire ou instruction particulière pour la commande (facultatif)
            </label>
            <textarea
              rows={2}
              value={orderNote}
              onChange={(e) => setOrderNote(e.target.value)}
              placeholder="Ex: Demande d'emballage cadeau, précisions pour le transporteur..."
              className="w-full p-3 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-amber-700"
            />
          </div>
        </div>

        {/* Order Summary & Checkout Card */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-md space-y-5">
            <h2 className="font-serif text-xl font-medium text-stone-900">
              Récapitulatif
            </h2>

            <div className="space-y-3 text-xs text-stone-600">
              <div className="flex justify-between">
                <span>Articles ({cart.reduce((a, b) => a + b.quantity, 0)})</span>
                <span className="font-medium text-stone-900 font-serif">
                  {formatPrice(cartSubtotal, cartSubtotal)}
                </span>
              </div>

              <div className="flex justify-between">
                <span>Frais de livraison estimés</span>
                <span>
                  {cartShipping === 0 ? (
                    <span className="text-emerald-700 font-bold uppercase text-[11px]">
                      Offerts
                    </span>
                  ) : (
                    formatPrice(cartShipping, cartShipping)
                  )}
                </span>
              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-between items-baseline">
                <span className="text-base font-semibold text-stone-900">Total TTC</span>
                <span className="font-serif text-2xl font-bold text-stone-900">
                  {formatPrice(cartTotal, cartTotal)}
                </span>
              </div>
            </div>

            <button
              onClick={() => navigateTo('checkout')}
              className="w-full py-4 bg-stone-900 hover:bg-amber-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
            >
              <span>Passer la commande</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="pt-2 text-[11px] text-stone-500 space-y-2 border-t border-stone-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Validation immédiate sans paiement prélevé</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-stone-400 shrink-0" />
                <span>Expédition protégée sous 48 à 72 heures</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
