import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { sendChatMessage } from '../services/db.ts';
import {
  Mail,
  Phone,
  MapPin,
  Clock,
  MessageSquare,
  Send,
  CheckCircle2,
  Sparkles,
  MessageCircle,
} from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { settings, setIsChatOpen, customer } = useStore();

  const [name, setName] = useState(
    customer ? `${customer.firstName} ${customer.lastName}` : ''
  );
  const [email, setEmail] = useState(customer ? customer.email : '');
  const [subject, setSubject] = useState('');
  const [orderRef, setOrderRef] = useState('');
  const [content, setContent] = useState('');
  const [sending, setSending] = useState(false);
  const [sentSuccess, setSentSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !content.trim()) return;

    setSending(true);
    try {
      const convoId = `ticket_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      await sendChatMessage({
        conversationId: convoId,
        sender: 'customer',
        senderName: name.trim(),
        customerEmail: email.trim(),
        subject: subject.trim() || 'Message via le formulaire de contact',
        orderReference: orderRef.trim() || undefined,
        content: content.trim(),
      });

      setSentSuccess(true);
      setContent('');
      setSubject('');
      setOrderRef('');
    } catch (err) {
      console.error('Error sending contact message:', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Top Banner */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <span className="text-xs font-bold uppercase tracking-widest text-amber-800">
          À votre écoute
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-normal text-stone-900">
          Contact & Messagerie
        </h1>
        <p className="text-xs sm:text-sm text-stone-500 leading-relaxed">
          Deux modes d’échange selon votre convenance : une discussion instantanée en direct ou une boîte de messages persistante conservée dans nos dossiers.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Left: Contact Info & Instant Chat CTA */}
        <div className="space-y-6">
          {/* Instant Chat Card */}
          <div className="bg-stone-900 text-white p-6 sm:p-7 rounded-3xl space-y-4 shadow-md">
            <div className="w-10 h-10 rounded-full bg-amber-600/80 flex items-center justify-center text-stone-950 font-bold">
              <MessageSquare className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-serif text-lg font-medium">Discussion Instantanée</h2>
              <p className="text-xs text-stone-300 mt-1 leading-relaxed">
                Posez vos questions en direct à notre équipe. Idéal pour une réponse rapide sur les stocks ou une aide à la commande.
              </p>
            </div>
            <button
              onClick={() => setIsChatOpen(true)}
              className="w-full py-3 bg-amber-600 hover:bg-amber-500 text-stone-950 font-semibold text-xs tracking-wider rounded-xl transition-colors cursor-pointer shadow-xs min-h-[44px]"
            >
              Lancer le chat en direct
            </button>
          </div>

          {/* WhatsApp Direct Assistance Card */}
          <div className="bg-[#051322] text-white p-6 sm:p-7 rounded-3xl space-y-4 shadow-md border border-[#183E66]">
            <div className="w-10 h-10 rounded-full bg-[#22C55E] flex items-center justify-center text-white font-bold">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">Assistance WhatsApp Directe</h2>
              <p className="text-xs text-[#CBD5E1] mt-1 leading-relaxed">
                Discutez directement avec nos conseillers pour vos devis de groupage aérien ou maritime.
              </p>
            </div>
            <a
              href={`https://wa.me/${(settings.whatsappPhone || '237699452010').replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-[#22C55E] hover:bg-[#16A34A] text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer shadow-xs flex items-center justify-center gap-2 min-h-[44px]"
            >
              <MessageCircle className="w-4 h-4 shrink-0" />
              <span>Ouvrir WhatsApp</span>
            </a>
          </div>

          {/* Contact Details */}
          <div className="bg-white p-6 sm:p-7 rounded-3xl border border-stone-200 space-y-5 shadow-xs">
            <h2 className="font-serif text-lg font-medium text-stone-900">Coordonnées</h2>

            <div className="space-y-4 text-xs text-stone-600">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-900 block">Adresse de la boutique :</strong>
                  <span>{settings.address}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-900 block">Horaires d'ouverture :</strong>
                  <span>{settings.openingHours}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-900 block">Téléphone :</strong>
                  <span>{settings.phone}</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-amber-800 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-stone-900 block">Adresse e-mail :</strong>
                  <span>{settings.email}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Persistent Message Box Form */}
        <div className="lg:col-span-2">
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200 shadow-xs space-y-6">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800">
                Mode B : Boîte de messages persistante
              </span>
              <h2 className="font-serif text-2xl font-medium text-stone-900 mt-1">
                Laisser un Message au Propriétaire
              </h2>
              <p className="text-xs text-stone-500 mt-1">
                Votre demande sera enregistrée et conservée dans notre historique. Une réponse vous sera apportée directement sur votre adresse e-mail.
              </p>
            </div>

            {sentSuccess && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-3 text-emerald-900 text-xs">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <strong>Message bien envoyé !</strong>
                  <p>Nous avons bien reçu votre demande et vous répondrons dans les plus brefs délais.</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Votre nom complet <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Marie Bernard"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Votre adresse e-mail <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="marie.bernard@email.fr"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Sujet de votre message
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="Ex: Renseignement sur une pièce d’art"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-700"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Numéro de commande (si applicable)
                  </label>
                  <input
                    type="text"
                    value={orderRef}
                    onChange={(e) => setOrderRef(e.target.value)}
                    placeholder="Ex: CMD-2026-4892"
                    className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-700"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Votre message détaillé <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={5}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Décrivez votre besoin ou votre question..."
                  className="w-full p-3.5 bg-stone-50 border border-stone-300 rounded-xl text-xs text-stone-900 focus:outline-none focus:ring-2 focus:ring-amber-700"
                />
              </div>

              <button
                type="submit"
                disabled={sending}
                className="w-full sm:w-auto px-8 py-3.5 bg-stone-900 hover:bg-stone-800 disabled:opacity-50 text-white rounded-xl text-xs font-semibold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Send className="w-4 h-4" />
                <span>{sending ? 'Envoi en cours...' : 'Envoyer mon message'}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
