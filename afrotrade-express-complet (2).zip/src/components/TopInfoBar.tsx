import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Truck, MessageCircle, Lock, ShieldCheck } from 'lucide-react';

export const TopInfoBar: React.FC = () => {
  const { settings, navigateTo } = useStore();

  const cleanWhatsApp = (settings.whatsappPhone || '237699452010').replace(/[^0-9]/g, '');
  const whatsappUrl = `https://wa.me/${cleanWhatsApp}`;

  return (
    <div className="bg-[#051322] text-[#94A3B8] text-[11px] sm:text-xs py-2 px-3 sm:px-6 border-b border-[#1E293B]">
      <div className="max-w-[1280px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-4">
        {/* Left: Delivery notice */}
        <div className="flex items-center gap-2 text-center sm:text-left min-w-0">
          <Truck className="w-3.5 h-3.5 text-[#F59E0B] shrink-0" />
          <span className="text-[#E2E8F0] font-medium truncate sm:whitespace-normal">
            {settings.deliveryNotice ||
              'Livraison en Afrique : Cameroun, Congo, Gabon, Côte d’Ivoire, Bénin...'}
          </span>
        </div>

        {/* Right: Social, WhatsApp & Discreet Admin Link */}
        <div className="flex items-center justify-center sm:justify-end gap-3 text-[11px] shrink-0">
          {/* WhatsApp Direct */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-[#38BDF8] hover:text-[#7DD3FC] transition-colors font-medium min-h-[32px]"
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#22C55E]" />
            <span>Assistance WhatsApp</span>
          </a>

          <span className="text-[#334155]">•</span>

          {/* Discreet Admin Link */}
          <button
            onClick={() => navigateTo('admin-login')}
            className="flex items-center gap-1 text-[#64748B] hover:text-[#F59E0B] transition-colors cursor-pointer min-h-[32px]"
            title="Espace Propriétaire / Administrateur"
          >
            <Lock className="w-3 h-3 text-[#64748B]" />
            <span>Admin</span>
          </button>
        </div>
      </div>
    </div>
  );
};
