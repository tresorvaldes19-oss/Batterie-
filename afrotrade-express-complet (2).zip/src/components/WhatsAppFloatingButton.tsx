import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { MessageCircle } from 'lucide-react';

export const WhatsAppFloatingButton: React.FC = () => {
  const { settings } = useStore();

  const phone = settings.whatsappPhone || '237699452010';
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(
    'Bonjour AfroTrade Express, je souhaite me renseigner sur vos produits en provenance de Chine et vos tarifs de livraison vers mon pays.'
  )}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 lg:bottom-6 left-4 sm:left-6 z-40 bg-[#22C55E] hover:bg-[#16A34A] text-white p-3.5 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 flex items-center gap-2 group cursor-pointer border-2 border-white"
      aria-label="Contacter sur WhatsApp"
      title="Discuter sur WhatsApp"
    >
      <MessageCircle className="w-6 h-6 text-white fill-white" />
      <span className="hidden sm:inline font-bold text-xs tracking-wide pr-1">
        WhatsApp Chine-Afrique
      </span>
    </a>
  );
};
