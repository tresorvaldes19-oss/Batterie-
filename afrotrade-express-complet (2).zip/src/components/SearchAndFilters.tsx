import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Currency } from '../types/index.ts';
import {
  Search,
  SlidersHorizontal,
  RotateCcw,
  X,
  Check,
  ChevronDown,
} from 'lucide-react';

interface SearchAndFiltersProps {
  searchTerm: string;
  setSearchTerm: (s: string) => void;
  minPrice: number;
  setMinPrice: (n: number) => void;
  maxPrice: number;
  setMaxPrice: (n: number) => void;
  sortBy: 'newest' | 'price-asc' | 'price-desc' | 'popular';
  setSortBy: (s: 'newest' | 'price-asc' | 'price-desc' | 'popular') => void;
  onApplyFilter: () => void;
  onResetFilter: () => void;
  totalFound: number;
}

export const SearchAndFilters: React.FC<SearchAndFiltersProps> = ({
  searchTerm,
  setSearchTerm,
  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice,
  sortBy,
  setSortBy,
  onApplyFilter,
  onResetFilter,
  totalFound,
}) => {
  const { currency, currencyInfo, setCurrency, openCurrencyModal } = useStore();
  const [mobileModalOpen, setMobileModalOpen] = useState(false);

  return (
    <div className="space-y-3.5">
      {/* Desktop Bar (Single Line, >= 1024px) */}
      <div className="hidden lg:flex items-center justify-between gap-4 bg-white p-3 rounded-2xl border border-[#E2E8F0] shadow-sm">
        {/* Large search input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par nom, référence produit, mot-clé..."
            className="w-full pl-10 pr-9 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] focus:bg-white transition-all min-h-[44px]"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 min-w-[24px] min-h-[24px] flex items-center justify-center cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filters and controls on the right */}
        <div className="flex items-center gap-3">
          {/* Min & Max Price */}
          <div className="flex items-center gap-1.5 text-xs text-[#64748B]">
            <span className="font-semibold">Prix :</span>
            <input
              type="number"
              placeholder="Min"
              value={minPrice || ''}
              onChange={(e) => setMinPrice(Number(e.target.value) || 0)}
              className="w-16 px-2.5 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] text-center min-h-[44px]"
            />
            <span>-</span>
            <input
              type="number"
              placeholder="Max"
              value={maxPrice || ''}
              onChange={(e) => setMaxPrice(Number(e.target.value) || 0)}
              className="w-16 px-2.5 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] text-center min-h-[44px]"
            />
          </div>

          {/* Currency selector button */}
          <button
            type="button"
            onClick={openCurrencyModal}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#F8FAFC] hover:bg-[#F1F5F9] border border-[#CBD5E1] rounded-xl text-xs font-bold text-[#0A2540] cursor-pointer min-h-[44px] transition-colors"
            title="Choisir la devise parmi les 54 pays africains"
          >
            <span>{currencyInfo.flag}</span>
            <span>{currencyInfo.code}</span>
            <span className="text-[#D97706] text-[11px]">({currencyInfo.symbol})</span>
            <ChevronDown className="w-3 h-3 text-[#94A3B8]" />
          </button>

          {/* Sort dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3.5 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] cursor-pointer min-h-[44px]"
          >
            <option value="newest">Nouveautés</option>
            <option value="price-asc">Prix croissant</option>
            <option value="price-desc">Prix décroissant</option>
            <option value="popular">Popularité</option>
          </select>

          {/* Filter Action Button */}
          <button
            type="button"
            onClick={onApplyFilter}
            className="px-5 py-2.5 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs transition-colors shadow-sm cursor-pointer min-h-[44px] flex items-center justify-center"
          >
            Filtrer
          </button>

          {/* Reset Secondary Button */}
          <button
            type="button"
            onClick={onResetFilter}
            className="p-2.5 text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9] rounded-xl transition-colors cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
            title="Réinitialiser"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tablet Controls (768px - 1023px, 2 lines) */}
      <div className="hidden md:flex lg:hidden flex-col gap-2.5 bg-white p-3.5 rounded-2xl border border-[#E2E8F0] shadow-sm">
        {/* Line 1: Full-width Search */}
        <div className="relative w-full">
          <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par nom, référence produit, mot-clé..."
            className="w-full pl-10 pr-9 py-2.5 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] focus:bg-white transition-all min-h-[44px]"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 min-w-[28px] min-h-[28px] flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Line 2: Filters on one horizontal row */}
        <div className="flex items-center justify-between gap-2.5 flex-wrap">
          <div className="flex items-center gap-1.5 text-xs text-[#64748B]">
            <span className="font-bold">Prix :</span>
            <input
              type="number"
              placeholder="Min"
              value={minPrice || ''}
              onChange={(e) => setMinPrice(Number(e.target.value) || 0)}
              className="w-16 px-2 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] text-center min-h-[44px]"
            />
            <span>-</span>
            <input
              type="number"
              placeholder="Max"
              value={maxPrice || ''}
              onChange={(e) => setMaxPrice(Number(e.target.value) || 0)}
              className="w-16 px-2 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] text-center min-h-[44px]"
            />
          </div>

          <div className="flex items-center gap-2 flex-1 justify-end">
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as Currency)}
              className="px-2.5 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0A2540] cursor-pointer min-h-[44px]"
            >
              <option value="USD">$ USD</option>
              <option value="EUR">€ EUR</option>
              <option value="FCFA">FCFA</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold text-[#0F172A] cursor-pointer min-h-[44px]"
            >
              <option value="newest">Nouveautés</option>
              <option value="price-asc">Prix croissant</option>
              <option value="price-desc">Prix décroissant</option>
              <option value="popular">Popularité</option>
            </select>

            <button
              type="button"
              onClick={onApplyFilter}
              className="px-4 py-2 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs transition-colors shadow-sm cursor-pointer min-h-[44px] flex items-center justify-center"
            >
              Filtrer
            </button>

            <button
              type="button"
              onClick={onResetFilter}
              className="p-2 text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9] rounded-xl transition-colors cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
              title="Réinitialiser"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Controls (< 768px, < md) */}
      <div className="md:hidden space-y-2.5">
        {/* Full-width Search Input with min 44px height */}
        <div className="relative w-full">
          <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par nom ou référence..."
            className="w-full pl-10 pr-10 py-3 bg-white border border-[#E2E8F0] rounded-2xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#F59E0B] min-h-[44px] shadow-xs"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 min-w-[32px] min-h-[32px] flex items-center justify-center cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Action Buttons Row */}
        <div className="flex items-center gap-2">
          {/* Sliding Modal Filter Trigger Button */}
          <button
            type="button"
            onClick={() => setMobileModalOpen(true)}
            className="flex-1 min-h-[44px] flex items-center justify-center gap-2 px-3 py-2.5 bg-white border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0A2540] shadow-xs cursor-pointer active:scale-98"
          >
            <SlidersHorizontal className="w-4 h-4 text-[#F59E0B]" />
            <span>Filtres & Prix</span>
            {(minPrice > 0 || maxPrice < 1000) && (
              <span className="w-2 h-2 rounded-full bg-[#F59E0B]" />
            )}
          </button>

          {/* Sort Selector */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="flex-1 min-h-[44px] py-2.5 px-3 bg-white border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] shadow-xs cursor-pointer"
          >
            <option value="newest">Nouveautés</option>
            <option value="price-asc">Prix croissant</option>
            <option value="price-desc">Prix décroissant</option>
            <option value="popular">Popularité</option>
          </select>
        </div>
      </div>

      {/* Dynamic Products Counter */}
      <div className="flex items-center justify-between text-xs text-[#64748B] px-1 pt-1">
        <span className="font-semibold text-[#0F172A]">
          <strong className="text-[#D97706] font-bold text-sm">{totalFound}</strong> produit(s) disponible(s)
        </span>
        <span className="text-[11px] text-[#94A3B8] hidden sm:inline">
          Shenzhen & Guangzhou → Afrique
        </span>
      </div>

      {/* Mobile Sliding Bottom Sheet / Drawer for Filters */}
      {mobileModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#0A2540]/60 backdrop-blur-xs flex items-end justify-center p-0 animate-in fade-in duration-200">
          <div className="bg-white w-full max-h-[85vh] overflow-y-auto rounded-t-3xl p-6 space-y-5 animate-in slide-in-from-bottom duration-250 shadow-2xl border-t border-[#E2E8F0]">
            {/* Sheet Handle & Header */}
            <div className="space-y-2">
              <div className="w-12 h-1.5 rounded-full bg-[#CBD5E1] mx-auto mb-2" />
              <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
                <h3 className="font-bold text-base text-[#0A2540] flex items-center gap-2">
                  <SlidersHorizontal className="w-4 h-4 text-[#F59E0B]" />
                  <span>Filtres du catalogue</span>
                </h3>
                <button
                  type="button"
                  onClick={() => setMobileModalOpen(false)}
                  className="min-w-[44px] min-h-[44px] flex items-center justify-center text-[#64748B] hover:text-[#0F172A] rounded-full cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Filter Stack */}
            <div className="space-y-4">
              {/* Price Range */}
              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1.5">
                  Fourchette de prix ({currency})
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 relative">
                    <input
                      type="number"
                      placeholder="Min (0)"
                      value={minPrice || ''}
                      onChange={(e) => setMinPrice(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px]"
                    />
                  </div>
                  <span className="text-[#94A3B8] font-bold">—</span>
                  <div className="flex-1 relative">
                    <input
                      type="number"
                      placeholder="Max (1000)"
                      value={maxPrice || ''}
                      onChange={(e) => setMaxPrice(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-3 bg-[#F8FAFC] border border-[#E2E8F0] rounded-xl text-xs font-semibold min-h-[44px]"
                    />
                  </div>
                </div>
              </div>

              {/* Currency Options */}
              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1.5 flex items-center justify-between">
                  <span>Devise d'affichage</span>
                  <span className="text-[#D97706] text-[10px] font-bold">54 Pays Africains</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    openCurrencyModal();
                    setMobileModalOpen(false);
                  }}
                  className="w-full min-h-[46px] p-2.5 rounded-xl bg-[#F8FAFC] border border-[#CBD5E1] flex items-center justify-between cursor-pointer hover:bg-[#F1F5F9] transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{currencyInfo.flag}</span>
                    <span className="text-xs font-black text-[#0A2540]">{currencyInfo.code}</span>
                    <span className="text-xs font-bold text-[#D97706]">({currencyInfo.symbol})</span>
                    <span className="text-[11px] text-[#64748B] truncate max-w-[140px]">{currencyInfo.name}</span>
                  </div>
                  <span className="text-[11px] font-bold text-[#0A2540] bg-white px-2 py-1 rounded-lg border border-[#E2E8F0]">
                    Changer 🌍
                  </span>
                </button>
              </div>

              {/* Sort Options */}
              <div>
                <label className="block text-xs font-bold text-[#0F172A] mb-1.5">
                  Ordre d'affichage
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'newest', label: 'Nouveautés' },
                    { id: 'popular', label: 'Popularité' },
                    { id: 'price-asc', label: 'Prix croissant' },
                    { id: 'price-desc', label: 'Prix décroissant' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setSortBy(s.id as any)}
                      className={`min-h-[44px] py-2.5 px-3 rounded-xl text-xs font-bold transition-all text-left flex items-center justify-between cursor-pointer ${
                        sortBy === s.id
                          ? 'bg-[#F59E0B] text-[#0A2540] shadow-sm'
                          : 'bg-[#F8FAFC] text-[#0F172A] border border-[#E2E8F0]'
                      }`}
                    >
                      <span>{s.label}</span>
                      {sortBy === s.id && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center gap-3 pt-3 pb-2 border-t border-[#E2E8F0]">
              <button
                type="button"
                onClick={() => {
                  onResetFilter();
                  setMobileModalOpen(false);
                }}
                className="flex-1 min-h-[48px] py-3 border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#64748B] hover:bg-[#F8FAFC] transition-colors cursor-pointer"
              >
                Réinitialiser
              </button>
              <button
                type="button"
                onClick={() => {
                  onApplyFilter();
                  setMobileModalOpen(false);
                }}
                className="flex-1 min-h-[48px] py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider shadow-md transition-colors cursor-pointer"
              >
                Appliquer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
