import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  Home,
  LayoutGrid,
  ShoppingCart,
  MessageCircle,
  User,
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { navState, navigateTo, cartCount, setIsCartOpen, customer } = useStore();

  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-[#E2E8F0] shadow-lg transition-all pb-[env(safe-area-inset-bottom,0px)]">
      <div className="flex items-center justify-around max-w-lg mx-auto px-2 py-1">
        {/* Accueil */}
        <button
          onClick={() => navigateTo('home')}
          className={`flex-1 min-h-[48px] py-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-colors cursor-pointer ${
            navState.page === 'home' ? 'text-[#F59E0B]' : 'text-[#64748B] hover:text-[#0A2540]'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Accueil</span>
        </button>

        {/* Catalogue */}
        <button
          onClick={() => navigateTo('catalog')}
          className={`flex-1 min-h-[48px] py-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-colors cursor-pointer ${
            navState.page === 'catalog' ? 'text-[#F59E0B]' : 'text-[#64748B] hover:text-[#0A2540]'
          }`}
        >
          <LayoutGrid className="w-5 h-5" />
          <span>Catalogue</span>
        </button>

        {/* Panier */}
        <button
          onClick={() => setIsCartOpen(true)}
          className={`flex-1 min-h-[48px] py-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-colors cursor-pointer ${
            navState.page === 'cart' ? 'text-[#F59E0B]' : 'text-[#64748B] hover:text-[#0A2540]'
          }`}
        >
          <div className="relative">
            <ShoppingCart className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2.5 bg-[#F59E0B] text-[#0A2540] text-[9px] font-black h-4 min-w-[16px] px-1 rounded-full flex items-center justify-center border border-white">
                {cartCount}
              </span>
            )}
          </div>
          <span>Chariot</span>
        </button>

        {/* WhatsApp / Contact */}
        <button
          onClick={() => navigateTo('contact')}
          className={`flex-1 min-h-[48px] py-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-colors cursor-pointer ${
            navState.page === 'contact' ? 'text-[#F59E0B]' : 'text-[#64748B] hover:text-[#0A2540]'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          <span>Contact</span>
        </button>

        {/* Compte */}
        <button
          onClick={() => navigateTo('account')}
          className={`flex-1 min-h-[48px] py-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-bold transition-colors cursor-pointer ${
            navState.page === 'account' ? 'text-[#F59E0B]' : 'text-[#64748B] hover:text-[#0A2540]'
          }`}
        >
          <User className="w-5 h-5" />
          <span>{customer ? customer.firstName.slice(0, 7) : 'Compte'}</span>
        </button>
      </div>
    </nav>
  );
};
