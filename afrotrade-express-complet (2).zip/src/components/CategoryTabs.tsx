import React, { useRef } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CategoryTabsProps {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
}

const CATEGORY_NAMES = [
  'Tous',
  'Vêtements',
  'Chaussures',
  'Sacs et accessoires',
  'Perruques',
  'Téléphones',
  'Ordinateurs',
  'Électroménager',
  'Motos',
  'Voitures',
  'Caméras',
  'Drones',
  'Gaming',
  'Pour enfants',
  'Tablettes',
  'Autres',
];

export const CategoryTabs: React.FC<CategoryTabsProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const offset = direction === 'left' ? -250 : 250;
      scrollContainerRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative flex items-center group">
      {/* Left Scroll arrow for desktop */}
      <button
        type="button"
        onClick={() => scroll('left')}
        className="hidden md:flex items-center justify-center absolute -left-3 z-10 w-9 h-9 rounded-full bg-white shadow-md border border-[#E2E8F0] text-[#0A2540] hover:bg-[#F8FAFC] transition-all cursor-pointer min-w-[36px] min-h-[36px]"
        aria-label="Défiler vers la gauche"
      >
        <ChevronLeft className="w-4 h-4" />
      </button>

      {/* Horizontal Scrollable Tabs */}
      <div
        ref={scrollContainerRef}
        className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth py-1.5 w-full touch-pan-x"
      >
        {CATEGORY_NAMES.map((catName) => {
          const isActive =
            selectedCategory.toLowerCase() === catName.toLowerCase() ||
            (catName === 'Tous' && (selectedCategory === 'all' || selectedCategory === 'Tous'));

          return (
            <button
              key={catName}
              type="button"
              onClick={() => onSelectCategory(catName === 'Tous' ? 'all' : catName)}
              className={`shrink-0 px-4 py-2.5 min-h-[44px] flex items-center justify-center rounded-full text-xs font-bold tracking-wide transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-[#0A2540] text-white shadow-sm ring-1 ring-[#0A2540]'
                  : 'bg-white text-[#64748B] hover:text-[#0A2540] hover:bg-[#F1F5F9] border border-[#E2E8F0]'
              }`}
            >
              {catName}
            </button>
          );
        })}
      </div>

      {/* Right Scroll arrow for desktop */}
      <button
        type="button"
        onClick={() => scroll('right')}
        className="hidden md:flex items-center justify-center absolute -right-3 z-10 w-9 h-9 rounded-full bg-white shadow-md border border-[#E2E8F0] text-[#0A2540] hover:bg-[#F8FAFC] transition-all cursor-pointer min-w-[36px] min-h-[36px]"
        aria-label="Défiler vers la droite"
      >
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
};
