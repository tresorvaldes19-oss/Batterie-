import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  X,
  ShoppingCart,
  Check,
  Star,
  Plane,
  Ship,
  ShieldCheck,
  MapPin,
  MessageCircle,
  Sparkles,
} from 'lucide-react';

export const ProductDetailsModal: React.FC = () => {
  const {
    modalProduct,
    setModalProduct,
    formatPrice,
    getFCFAEquivalent,
    addToCart,
    settings,
  } = useStore();

  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  if (!modalProduct) return null;

  const images =
    modalProduct.images && modalProduct.images.length > 0
      ? modalProduct.images
      : [modalProduct.mainImage];

  const currentImage = images[selectedImageIdx] || modalProduct.mainImage;

  const isAvailable = modalProduct.status === 'disponible' && modalProduct.stock > 0;

  const handleAdd = () => {
    if (!isAvailable) return;
    addToCart(modalProduct, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const phone = settings.whatsappPhone || '237699452010';
  const whatsAppMessage = encodeURIComponent(
    `Bonjour AfroTrade Express, je souhaite commander l'article : ${modalProduct.name} (Réf: ${modalProduct.sku}) au prix de $${modalProduct.priceUSD} (${getFCFAEquivalent(modalProduct.priceUSD)}). Quantité: ${quantity}. Merci de me donner les instructions d'expédition.`
  );
  const whatsAppUrl = `https://wa.me/${phone}?text=${whatsAppMessage}`;

  return (
    <div className="fixed inset-0 z-50 bg-[#0A2540]/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-[#E2E8F0] overflow-hidden my-6 animate-in zoom-in-95 duration-200 flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="p-4 px-6 border-b border-[#E2E8F0] flex items-center justify-between bg-[#F8FAFC]">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-[#D97706] bg-[#FEF3C7] px-2.5 py-0.5 rounded-full">
              {modalProduct.category}
            </span>
            <span className="text-xs font-mono text-[#64748B]">Réf : {modalProduct.sku}</span>
          </div>

          <button
            onClick={() => setModalProduct(null)}
            className="min-w-[44px] min-h-[44px] flex items-center justify-center p-2 text-[#64748B] hover:text-[#0F172A] hover:bg-[#E2E8F0] rounded-full transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scroll Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {/* Left: Gallery Showcase with 5+ images */}
          <div className="space-y-4">
            <div className="relative aspect-square w-full rounded-2xl bg-[#F8FAFC] border border-[#E2E8F0] p-4 flex items-center justify-center overflow-hidden">
              <img
                src={currentImage}
                alt={modalProduct.name}
                className="max-h-full max-w-full object-contain"
              />
              {modalProduct.badge && (
                <span className="absolute top-3 left-3 px-2.5 py-1 bg-[#F59E0B] text-[#0A2540] text-xs font-black uppercase rounded shadow-xs">
                  {modalProduct.badge}
                </span>
              )}
            </div>

            {/* Thumbnails */}
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImageIdx(idx)}
                  className={`w-16 h-16 rounded-xl border-2 p-1 bg-[#F8FAFC] shrink-0 transition-all cursor-pointer ${
                    selectedImageIdx === idx
                      ? 'border-[#F59E0B] ring-2 ring-[#F59E0B]/20 scale-105'
                      : 'border-[#E2E8F0] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`Vue ${idx + 1}`} className="w-full h-full object-contain" />
                </button>
              ))}
            </div>

            {/* Logistics Info (Air & Sea Cargo) */}
            <div className="bg-[#F8FAFC] p-4 rounded-2xl border border-[#E2E8F0] space-y-2.5 text-xs text-[#0F172A]">
              <div className="flex items-center gap-2 font-bold text-[#0A2540]">
                <MapPin className="w-4 h-4 text-[#F59E0B]" />
                <span>Expédition depuis : {modalProduct.origin || 'Shenzhen, Chine'}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                <div className="p-2 bg-white rounded-xl border border-[#E2E8F0] flex items-center gap-2">
                  <Plane className="w-4 h-4 text-sky-600 shrink-0" />
                  <div>
                    <span className="font-bold block">Fret Aérien</span>
                    <span className="text-[#64748B]">{modalProduct.transitAirDays || '7-10 jours'}</span>
                  </div>
                </div>
                <div className="p-2 bg-white rounded-xl border border-[#E2E8F0] flex items-center gap-2">
                  <Ship className="w-4 h-4 text-emerald-600 shrink-0" />
                  <div>
                    <span className="font-bold block">Fret Maritime</span>
                    <span className="text-[#64748B]">{modalProduct.transitSeaDays || '30-45 jours'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Details & Purchase */}
          <div className="space-y-5 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Product Title */}
              <h2 className="font-black text-xl sm:text-2xl text-[#0F172A] leading-snug">
                {modalProduct.name}
              </h2>

              {/* Rating */}
              <div className="flex items-center gap-2">
                <div className="flex text-[#F59E0B]">
                  {Array.from({ length: 5 }, (_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < Math.floor(modalProduct.rating || 5)
                          ? 'fill-[#F59E0B]'
                          : 'text-stone-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-semibold text-[#0F172A]">
                  {modalProduct.rating || 4.9} / 5
                </span>
                <span className="text-xs text-[#64748B]">
                  ({modalProduct.reviewsCount || 34} avis clients)
                </span>
              </div>

              {/* Prominent Price & FCFA equivalent */}
              <div className="p-4 bg-[#F1F5F9] rounded-2xl border border-[#E2E8F0]">
                <span className="text-xs text-[#64748B] font-medium">Prix d'import unitaire :</span>
                <div className="flex items-baseline gap-3 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-black text-[#0A2540]">
                    {formatPrice(modalProduct.priceEUR, modalProduct.priceUSD)}
                  </span>
                  <span className="text-sm font-bold text-[#D97706]">
                    ({getFCFAEquivalent(modalProduct.priceUSD)})
                  </span>
                </div>
                <span className="text-[11px] text-[#64748B] mt-1 block">
                  Tarif direct usine. Dédouanement et transport inclus au dépôt de destination.
                </span>
              </div>

              {/* Description */}
              <div className="space-y-1.5 text-xs text-[#334155] leading-relaxed">
                <strong className="text-[#0F172A] block uppercase font-bold text-[11px]">
                  Description :
                </strong>
                <p className="whitespace-pre-line">{modalProduct.description}</p>
              </div>

              {/* Key Features */}
              {modalProduct.characteristics && modalProduct.characteristics.length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-[#E2E8F0]">
                  <strong className="text-[#0F172A] block uppercase font-bold text-[11px]">
                    Points Forts :
                  </strong>
                  <ul className="space-y-1 text-xs text-[#334155]">
                    {modalProduct.characteristics.map((c, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-[#16A34A] shrink-0 mt-0.5" />
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Specifications */}
              {modalProduct.specifications && Object.keys(modalProduct.specifications).length > 0 && (
                <div className="space-y-1.5 pt-2 border-t border-[#E2E8F0]">
                  <strong className="text-[#0F172A] block uppercase font-bold text-[11px]">
                    Fiche Technique :
                  </strong>
                  <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#F8FAFC] p-3 rounded-xl border border-[#E2E8F0]">
                    {Object.entries(modalProduct.specifications).map(([k, v]) => (
                      <div key={k}>
                        <span className="text-[#64748B]">{k}: </span>
                        <span className="font-semibold text-[#0F172A]">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Actions: Quantity + Add To Cart + WhatsApp Button */}
            <div className="pt-4 border-t border-[#E2E8F0] space-y-3">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                {/* Quantity */}
                <div className="flex items-center justify-between sm:justify-start border border-[#E2E8F0] rounded-xl overflow-hidden bg-[#F8FAFC] min-h-[48px]">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="min-w-[44px] min-h-[48px] px-4 py-3 hover:bg-[#E2E8F0] text-sm font-black text-[#0F172A] flex items-center justify-center cursor-pointer"
                    aria-label="Diminuer la quantité"
                  >
                    -
                  </button>
                  <span className="px-5 py-3 text-sm font-black text-[#0F172A] min-w-[40px] text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="min-w-[44px] min-h-[48px] px-4 py-3 hover:bg-[#E2E8F0] text-sm font-black text-[#0F172A] flex items-center justify-center cursor-pointer"
                    aria-label="Augmenter la quantité"
                  >
                    +
                  </button>
                </div>

                {/* Add to Cart */}
                <button
                  type="button"
                  onClick={handleAdd}
                  disabled={!isAvailable}
                  className={`flex-1 min-h-[48px] py-3.5 px-6 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md ${
                    added
                      ? 'bg-[#16A34A] text-white'
                      : !isAvailable
                      ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                      : 'bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] active:scale-98'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Ajouté au chariot !</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4" />
                      <span>Ajouter au chariot</span>
                    </>
                  )}
                </button>
              </div>

              {/* Direct WhatsApp Order CTA */}
              <a
                href={whatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[48px] py-3 px-4 bg-[#22C55E] hover:bg-[#16A34A] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer text-center"
              >
                <MessageCircle className="w-4 h-4 shrink-0" />
                <span>Commander directement par WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
