import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  MessageSquare,
  X,
  Send,
  CheckCheck,
  Package,
  ShoppingBag,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  User,
  Bot,
  Sparkles,
} from 'lucide-react';
import { Message } from '../types/index.ts';
import { subscribeMessages, sendChatMessage } from '../services/db.ts';
import { generateAiReply } from '../services/aiService.ts';

export const ChatWidget: React.FC = () => {
  const {
    isChatOpen,
    setIsChatOpen,
    currentConvoId,
    customer,
    activeChatProduct,
    activeChatOrderRef,
    settings,
    products,
    formatPrice,
    getFCFAEquivalent,
  } = useStore();

  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [clientName, setClientName] = useState(
    customer ? `${customer.firstName} ${customer.lastName}` : ''
  );
  const [clientEmail, setClientEmail] = useState(customer ? customer.email : '');
  const [clientPhone, setClientPhone] = useState(customer ? customer.phone : '');
  const [sending, setSending] = useState(false);
  const [aiTyping, setAiTyping] = useState(false);
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync customer details
  useEffect(() => {
    if (customer) {
      if (!clientName) setClientName(`${customer.firstName} ${customer.lastName}`);
      if (!clientEmail) setClientEmail(customer.email);
      if (!clientPhone && customer.phone) setClientPhone(customer.phone);
    }
  }, [customer]);

  // Subscribe to real-time messages for this conversation ID
  useEffect(() => {
    if (!currentConvoId) return;
    const unsub = subscribeMessages(currentConvoId, (newMsgs) => {
      setMessages((prev) => {
        const map = new Map<string, Message>();
        newMsgs.forEach((m) => map.set(m.id, m));
        // Keep any active optimistic messages that haven't been replaced yet
        prev.forEach((m) => {
          if (m.id.startsWith('msg-opt-') || m.id.startsWith('msg-ai-opt-')) {
            const alreadyStored = newMsgs.some(
              (nm) => nm.content === m.content && nm.sender === m.sender
            );
            if (!alreadyStored) {
              map.set(m.id, m);
            }
          }
        });
        return Array.from(map.values()).sort(
          (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
        );
      });
    });
    return () => unsub();
  }, [currentConvoId]);

  // Auto scroll to bottom
  useEffect(() => {
    if (isChatOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, aiTyping, isChatOpen]);

  const toggleExpandOrder = (msgId: string) => {
    setExpandedOrders((prev) => ({
      ...prev,
      [msgId]: !prev[msgId],
    }));
  };

  const handleSendMessage = async (e?: React.FormEvent, directText?: string) => {
    if (e) e.preventDefault();
    const textToSend = (directText || inputText).trim();
    if (!textToSend) return;

    const senderDisplayName =
      clientName.trim() ||
      (customer ? `${customer.firstName} ${customer.lastName}` : 'Client Visiteur');
    const senderEmail =
      clientEmail.trim() || (customer ? customer.email : 'client@afrotrade.com');

    // 1. INSTANT DIRECT VISIBILITY: Render message immediately in the UI (0ms delay)
    const tempId = `msg-opt-${Date.now()}`;
    const optimisticMsg: Message = {
      id: tempId,
      conversationId: currentConvoId,
      sender: 'customer',
      senderName: senderDisplayName,
      content: textToSend,
      attachedOrderRef: activeChatOrderRef,
      attachedProductId: activeChatProduct?.id,
      attachedProductName: activeChatProduct?.name,
      read: false,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, optimisticMsg]);
    setInputText('');
    setSending(true);

    try {
      // 2. Persist in database & local bus
      await sendChatMessage({
        conversationId: currentConvoId,
        sender: 'customer',
        senderName: senderDisplayName,
        customerEmail: senderEmail,
        customerPhone: clientPhone.trim() || customer?.phone,
        customerId: customer?.id,
        content: textToSend,
        orderReference: activeChatOrderRef,
        productId: activeChatProduct?.id,
        productName: activeChatProduct?.name,
      });

      // 3. Automated Commercial AI Assistant full-time response (answers directly to ALL questions)
      if (settings.aiAssistantEnabled !== false) {
        setAiTyping(true);
        setTimeout(async () => {
          try {
            const aiReply = await generateAiReply({
              userMessage: textToSend,
              conversationHistory: [...messages, optimisticMsg],
              settings,
              products,
              orderRef: activeChatOrderRef,
            });

            const aiSenderName =
              settings.aiMode === 'unavailability_only'
                ? `${settings.name} (Répondeur d'Absence)`
                : `Assistant Virtuel IA • ${settings.name}`;

            const aiOptimisticMsg: Message = {
              id: `msg-ai-opt-${Date.now()}`,
              conversationId: currentConvoId,
              sender: 'ai',
              senderName: aiSenderName,
              content: aiReply,
              isAi: true,
              attachedOrderRef: activeChatOrderRef,
              read: false,
              createdAt: new Date().toISOString(),
            };

            // DIRECTLY RENDER AI RESPONSE IN CHAT UI IMMEDIATELY
            setMessages((prev) => [...prev, aiOptimisticMsg]);

            await sendChatMessage({
              conversationId: currentConvoId,
              sender: 'ai',
              senderName: aiSenderName,
              content: aiReply,
              isAi: true,
              orderReference: activeChatOrderRef,
            });
          } catch (aiErr) {
            console.warn('AI response generation note:', aiErr);
          } finally {
            setAiTyping(false);
          }
        }, 700);
      }
    } catch (err) {
      console.error('Failed to send chat message:', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      {/* Floating launcher trigger */}
      {!isChatOpen && (
        <button
          type="button"
          onClick={() => setIsChatOpen(true)}
          className="fixed bottom-20 lg:bottom-6 right-4 sm:right-6 z-40 bg-[#0A2540] hover:bg-[#183E66] text-white p-3.5 sm:p-4 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 flex items-center gap-2.5 group cursor-pointer border border-[#183E66]"
          aria-label="Discuter avec le commerçant"
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5 sm:w-6 sm:h-6 text-[#F59E0B]" />
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#22C55E] rounded-full border-2 border-[#0A2540] animate-pulse" />
          </div>
          <span className="hidden sm:inline font-bold text-xs tracking-wide pr-1">
            Discuter avec nous
          </span>
        </button>
      )}

      {/* Floating Chat Modal */}
      {isChatOpen && (
        <div className="fixed bottom-0 right-0 sm:bottom-6 sm:right-6 z-50 w-full sm:w-[420px] h-[85vh] sm:h-[580px] max-h-[640px] bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-[#CBD5E1] flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-[#0A2540] text-white px-4 py-3.5 sm:px-5 sm:py-4 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-[#183E66] border border-[#F59E0B]/40 flex items-center justify-center font-black text-white text-base">
                  {settings.name?.charAt(0) || 'A'}
                </div>
                <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#22C55E] rounded-full border-2 border-[#0A2540]" />
              </div>
              <div>
                <h3 className="font-bold text-sm text-white">
                  {settings.name || 'AfroTrade Express'}
                </h3>
                <p className="text-[11px] text-[#F59E0B] flex items-center gap-1 font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#22C55E]" />
                  <span>Conseiller en direct</span> • <span>Chine & Afrique</span>
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsChatOpen(false)}
              className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg hover:bg-[#183E66] transition-colors cursor-pointer"
              aria-label="Fermer la discussion"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Attached context badge */}
          {(activeChatProduct || activeChatOrderRef) && (
            <div className="bg-[#FEF3C7] border-b border-[#FDE68A] px-4 py-2 flex items-center justify-between text-xs text-[#92400E] shrink-0">
              <div className="flex items-center gap-2 truncate">
                {activeChatOrderRef ? (
                  <>
                    <Package className="w-4 h-4 text-[#B45309] shrink-0" />
                    <span className="truncate font-bold">Commande liée : #{activeChatOrderRef}</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4 text-[#B45309] shrink-0" />
                    <span className="truncate font-bold">Article : {activeChatProduct?.name}</span>
                  </>
                )}
              </div>
            </div>
          )}

          {/* User info mini bar if guest */}
          {!customer && (
            <div className="bg-[#F8FAFC] border-b border-[#E2E8F0] px-4 py-2 flex items-center gap-2 text-xs shrink-0">
              <input
                type="text"
                placeholder="Votre prénom"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-1/2 px-2.5 py-1.5 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-1 focus:ring-[#0A2540]"
              />
              <input
                type="email"
                placeholder="Email de contact"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                className="w-1/2 px-2.5 py-1.5 bg-white border border-[#CBD5E1] rounded-lg text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-1 focus:ring-[#0A2540]"
              />
            </div>
          )}

          {/* Messages Body */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#F8FAFC]">
            {/* Welcome banner */}
            <div className="bg-white p-3.5 rounded-2xl border border-[#E2E8F0] shadow-2xs text-xs text-[#334155] space-y-1">
              <div className="flex items-center justify-between">
                <p className="font-bold text-[#0F172A]">Bienvenue chez {settings.name} !</p>
                <span className="text-[9px] font-black uppercase bg-[#DCFCE7] text-[#166534] px-1.5 py-0.5 rounded-full">
                  24/7 En direct
                </span>
              </div>
              <p className="leading-relaxed">
                Posez vos questions sur nos articles, vos commandes en cours ou le fret aérien & groupage maritime depuis Shenzhen. L'IA et l'administrateur vous répondent ici en temps réel.
              </p>
            </div>

            {/* Quick Interactive Prompt Chips */}
            {messages.length <= 1 && (
              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-black uppercase tracking-wider text-[#64748B]">
                  Questions fréquentes (cliquez pour poser) :
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    "✈️ Quels sont les délais d'expédition vers mon pays ?",
                    "💳 Comment payer par Mobile Money ou Wave ?",
                    "🌍 Comment voir les prix dans ma devise locale ?",
                    "📱 Quels téléphones & perruques sont en stock ?",
                  ].map((chip, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSendMessage(undefined, chip)}
                      className="px-2.5 py-1.5 bg-white hover:bg-[#F1F5F9] text-[#1E293B] border border-[#CBD5E1] rounded-xl text-[11px] font-medium text-left transition-all cursor-pointer shadow-2xs hover:scale-[1.01]"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Conversation messages */}
            {messages.map((msg) => {
              const isMe = msg.sender === 'customer';
              const isSystem = msg.sender === 'system';
              const isExpanded = !!expandedOrders[msg.id];

              if (isSystem && !msg.isAi) {
                return (
                  <div key={msg.id} className="text-center py-1">
                    <span className="text-[11px] bg-[#E2E8F0] text-[#475569] px-3 py-1 rounded-full inline-block">
                      {msg.content}
                    </span>
                  </div>
                );
              }

              if (msg.sender === 'ai' || msg.isAi) {
                return (
                  <div key={msg.id} className="flex flex-col items-start space-y-1 my-1">
                    <div className="max-w-[92%] p-3.5 rounded-2xl text-xs leading-relaxed bg-[#EDE9FE] text-[#3B0764] rounded-tl-xs border border-[#C4B5FD] shadow-2xs">
                      <div className="flex items-center gap-1.5 text-[10px] font-black uppercase mb-1 tracking-wider text-[#6D28D9]">
                        <Bot className="w-3.5 h-3.5 text-[#7C3AED]" />
                        <span>Assistant Virtuel IA • En attente de l'administrateur</span>
                      </div>
                      <p className="whitespace-pre-line">{msg.content}</p>
                      <span className="block text-[9px] text-[#7C3AED]/70 mt-1 text-right font-mono">
                        {new Date(msg.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </span>
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} space-y-1`}
                >
                  <div
                    className={`max-w-[92%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                      isMe
                        ? 'bg-[#0A2540] text-white rounded-tr-xs shadow-xs'
                        : 'bg-white text-[#0F172A] rounded-tl-xs border border-[#CBD5E1] shadow-2xs'
                    }`}
                  >
                    {!isMe && (
                      <span className="block text-[10px] font-black text-[#D97706] mb-1 uppercase tracking-wider">
                        {settings.name} (Service Commercial)
                      </span>
                    )}

                    {/* Rich Attached Order Card with Photos, Prices & Descriptions */}
                    {msg.attachedOrder ? (
                      <div
                        className={`rounded-xl p-3 border mb-2 text-left ${
                          isMe
                            ? 'bg-[#183E66] border-[#2E5B88] text-white'
                            : 'bg-[#F8FAFC] border-[#E2E8F0] text-[#0F172A]'
                        }`}
                      >
                        <div className="flex items-center justify-between pb-2 border-b border-current/15 gap-2">
                          <div className="flex items-center gap-1.5 font-bold text-xs">
                            <Package className="w-4 h-4 text-[#F59E0B] shrink-0" />
                            <span>Commande #{msg.attachedOrder.orderRef}</span>
                          </div>
                          <span className="text-[11px] font-bold text-[#F59E0B]">
                            {formatPrice(msg.attachedOrder.total, msg.attachedOrder.total)}
                          </span>
                        </div>

                        <p className="text-[11px] opacity-80 mt-1.5">
                          Destinataire : <strong>{msg.attachedOrder.customerName}</strong> ({msg.attachedOrder.customerPhone})
                        </p>
                        <p className="text-[11px] opacity-80">
                          Livraison : {msg.attachedOrder.customerAddress}
                        </p>

                        {/* List of items with photos & descriptions */}
                        <div className="mt-2.5 space-y-2 border-t border-current/15 pt-2">
                          <div className="flex items-center justify-between text-[11px] font-semibold opacity-90">
                            <span>Articles transférés ({msg.attachedOrder.items.length})</span>
                            <button
                              type="button"
                              onClick={() => toggleExpandOrder(msg.id)}
                              className="text-[10px] underline flex items-center gap-0.5 cursor-pointer"
                            >
                              <span>{isExpanded ? 'Réduire' : 'Détails & descriptions'}</span>
                              {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                            </button>
                          </div>

                          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                            {msg.attachedOrder.items.map((it, idx) => (
                              <div
                                key={idx}
                                className={`p-2 rounded-lg flex items-start gap-2.5 ${
                                  isMe ? 'bg-[#0A2540]/60' : 'bg-white border border-[#E2E8F0]'
                                }`}
                              >
                                <img
                                  src={it.image}
                                  alt={it.name}
                                  className="w-11 h-11 rounded-md object-contain bg-white border border-current/10 shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <p className="font-bold text-[11px] truncate">{it.name}</p>
                                  <div className="flex items-center justify-between text-[10px] opacity-85 mt-0.5">
                                    <span>Réf: {it.sku} • Qté: {it.quantity}</span>
                                    <span className="font-bold text-[#F59E0B]">
                                      {formatPrice(it.totalPrice, it.totalPrice)}
                                    </span>
                                  </div>
                                  {isExpanded && it.description && (
                                    <p className="text-[10px] mt-1 opacity-80 leading-normal border-t border-current/10 pt-1">
                                      {it.description}
                                    </p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {msg.attachedOrder.notes && (
                          <div className="mt-2 text-[10px] opacity-80 italic border-t border-current/10 pt-1.5">
                            Note : « {msg.attachedOrder.notes} »
                          </div>
                        )}
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    )}

                    {/* Simple badge if ref attached without full object */}
                    {!msg.attachedOrder && msg.attachedOrderRef && (
                      <div className="mt-2 pt-2 border-t border-current/15 text-[10px] flex items-center gap-1 opacity-90">
                        <Package className="w-3 h-3 text-[#F59E0B]" />
                        <span>Réf: #{msg.attachedOrderRef}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1 text-[10px] text-[#94A3B8] px-1">
                    <span>
                      {new Date(msg.createdAt).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    {isMe && <CheckCheck className="w-3 h-3 text-[#94A3B8]" />}
                  </div>
                </div>
              );
            })}

            {/* Real-time AI Typing Indicator */}
            {aiTyping && (
              <div className="flex items-center gap-2 p-3 bg-[#EDE9FE] text-[#6D28D9] rounded-2xl rounded-tl-xs w-fit text-xs font-semibold animate-pulse border border-[#DDD6FE] shadow-2xs">
                <Bot className="w-4 h-4 text-[#7C3AED] animate-bounce shrink-0" />
                <span>Assistant IA AfroTrade est en train d'écrire...</span>
                <span className="flex gap-1 ml-1">
                  <span className="w-1.5 h-1.5 bg-[#7C3AED] rounded-full animate-ping"></span>
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Footer */}
          <form
            onSubmit={handleSendMessage}
            className="p-3 bg-white border-t border-[#E2E8F0] flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Écrivez votre message..."
              disabled={sending}
              className="flex-1 min-h-[44px] px-4 py-2 bg-[#F1F5F9] rounded-xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#0A2540] focus:bg-white transition-all"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || sending}
              className="min-h-[44px] min-w-[44px] p-2.5 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-40 text-white rounded-xl transition-colors shrink-0 cursor-pointer shadow-xs flex items-center justify-center"
              aria-label="Envoyer"
            >
              <Send className="w-4 h-4 text-[#F59E0B]" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
