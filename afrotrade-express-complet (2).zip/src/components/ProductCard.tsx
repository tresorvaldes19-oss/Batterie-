import React from 'react';
import { Product } from '../types/index.ts';
import { useStore } from '../context/StoreContext.tsx';
import { ShoppingCart, Star, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { formatPrice, getFCFAEquivalent, addToCart, setModalProduct } = useStore();
  const [added, setAdded] = React.useState(false);

  const isAvailable = product.status === 'disponible' && product.stock > 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAvailable) return;
    addToCart(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const handleClickCard = () => {
    setModalProduct(product);
  };

  return (
    <div
      onClick={handleClickCard}
      className="group relative flex flex-col bg-white rounded-2xl border border-[#E2E8F0] shadow-xs hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 cursor-pointer overflow-hidden h-full"
    >
      {/* Square Image Area with #F8FAFC and object-fit: contain */}
      <div className="relative aspect-square w-full bg-[#F8FAFC] overflow-hidden p-3 sm:p-4 flex items-center justify-center">
        <img
          src={product.mainImage || product.images?.[0]}
          alt={product.name}
          className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-300 ease-out"
          loading="lazy"
        />

        {/* Badge in top-left */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {product.badge ? (
            <span
              className={`px-2 py-0.5 text-[9px] sm:text-[10px] font-black uppercase tracking-wider rounded-md shadow-xs ${
                product.badge === 'Promotion'
                  ? 'bg-rose-500 text-white'
                  : product.badge === 'Nouveau'
                  ? 'bg-[#0A2540] text-white'
                  : product.badge === 'Stock limité'
                  ? 'bg-amber-500 text-[#0A2540]'
                  : 'bg-[#F59E0B] text-[#0A2540]'
              }`}
            >
              {product.badge}
            </span>
          ) : product.featured ? (
            <span className="px-2 py-0.5 bg-[#F59E0B] text-[#0A2540] text-[9px] sm:text-[10px] font-black uppercase tracking-wider rounded-md">
              Top Vente
            </span>
          ) : null}
        </div>

        {/* Circular Cart Action Button in top-right with 44px touch target on mobile */}
        <button
          type="button"
          onClick={handleAddToCart}
          disabled={!isAvailable}
          className={`absolute top-2 right-2 min-w-[44px] min-h-[44px] w-11 h-11 rounded-full shadow-md flex items-center justify-center transition-all duration-200 z-10 cursor-pointer active:scale-90 ${
            added
              ? 'bg-[#22C55E] text-white scale-105'
              : !isAvailable
              ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
              : 'bg-white text-[#0A2540] hover:bg-[#F59E0B] hover:text-[#0A2540] border border-[#E2E8F0]'
          }`}
          title={isAvailable ? 'Ajouter au panier' : 'Indisponible'}
          aria-label="Ajouter au panier"
        >
          {added ? <Check className="w-5 h-5 stroke-[3]" /> : <ShoppingCart className="w-5 h-5" />}
        </button>
      </div>

      {/* Product Content Information */}
      <div className="flex flex-1 flex-col p-3.5 sm:p-4 justify-between gap-2">
        <div className="space-y-1">
          {/* Category */}
          <div className="flex items-center justify-between gap-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#D97706] truncate">
              {product.category}
            </span>
            <span className="shrink-0 text-[9px] font-semibold text-[#16A34A] bg-[#DCFCE7] px-1.5 py-0.2 rounded">
              En stock
            </span>
          </div>

          {/* Product Name (capped at 2 lines) */}
          <h3 className="text-xs sm:text-sm font-bold text-[#0F172A] group-hover:text-[#183E66] transition-colors line-clamp-2 leading-snug min-h-[2.4rem]">
            {product.name}
          </h3>

          {/* Rating stars if available */}
          <div className="flex items-center gap-1 pt-0.5">
            <div className="flex text-[#F59E0B]">
              {Array.from({ length: 5 }, (_, i) => (
                <Star
                  key={i}
                  className={`w-3 h-3 ${
                    i < Math.floor(product.rating || 5)
                      ? 'fill-[#F59E0B]'
                      : 'text-stone-300'
                  }`}
                />
              ))}
            </div>
            <span className="text-[10px] text-[#64748B] font-medium">
              ({product.reviewsCount || 25})
            </span>
          </div>
        </div>

        {/* Prices at Bottom */}
        <div className="pt-2.5 border-t border-[#F1F5F9] mt-1">
          <div className="flex items-baseline justify-between gap-1">
            <div className="min-w-0">
              {/* Main Price */}
              <span className="text-sm sm:text-base font-black text-[#0A2540] tracking-tight block truncate">
                {formatPrice(product.priceEUR, product.priceUSD)}
              </span>

              {/* FCFA Conversion underneath */}
              <span className="block text-[10px] sm:text-[11px] font-bold text-[#D97706] truncate">
                {getFCFAEquivalent(product.priceUSD)}
              </span>
            </div>

            {product.oldPriceUSD && (
              <span className="text-[10px] text-[#94A3B8] line-through font-medium shrink-0">
                ${product.oldPriceUSD}
              </span>
            )}
          </div>
        </div>

        {/* Explicit B2B "Ajouter au chariot" button */}
        <button
          type="button"
          onClick={handleAddToCart}
          disabled={!isAvailable}
          className={`w-full min-h-[44px] py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all duration-200 cursor-pointer active:scale-98 mt-1.5 ${
            added
              ? 'bg-[#22C55E] text-white shadow-sm'
              : !isAvailable
              ? 'bg-stone-100 text-stone-400 cursor-not-allowed border border-stone-200'
              : 'bg-[#0A2540] hover:bg-[#183E66] text-white shadow-sm hover:shadow'
          }`}
          aria-label="Ajouter au chariot"
        >
          {added ? (
            <>
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Ajouté au chariot</span>
            </>
          ) : (
            <>
              <ShoppingCart className="w-4 h-4 text-[#F59E0B]" />
              <span>{isAvailable ? 'Ajouter au chariot' : 'Indisponible'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
