import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  X,
  MessageCircle,
  MessageSquare,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
  ArrowRight,
  User,
  Phone,
  CheckCircle2,
  Package,
} from 'lucide-react';

interface OrderModeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OrderModeModal: React.FC<OrderModeModalProps> = ({ isOpen, onClose }) => {
  const {
    cart,
    cartCount,
    cartTotal,
    formatPrice,
    getFCFAEquivalent,
    settings,
    customer,
    createOrderDemand,
    isWhatsAppConfigured,
    navigateTo,
    openChatWithOrder,
  } = useStore();

  const [step, setStep] = useState<'choice' | 'guest_form'>('choice');
  const [guestName, setGuestName] = useState(
    customer ? `${customer.firstName} ${customer.lastName}` : ''
  );
  const [guestPhone, setGuestPhone] = useState(customer ? customer.phone : '');
  const [guestCity, setGuestCity] = useState(customer?.address?.city || 'Douala');
  const [guestEmail, setGuestEmail] = useState(customer ? customer.email : '');
  const [guestNotes, setGuestNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const whatsAppReady = isWhatsAppConfigured();

  // Handler for Option 1: WhatsApp
  const handleWhatsAppOrder = async () => {
    if (!whatsAppReady) return;
    setLoading(true);
    setErrorMessage(null);
    try {
      const result = await createOrderDemand({
        channel: 'whatsapp',
        customerInfo: {
          firstName: customer ? customer.firstName : guestName.trim() || 'Client',
          lastName: customer ? customer.lastName : 'WhatsApp',
          phone: customer ? customer.phone : guestPhone.trim() || 'Non renseigné',
          email: customer ? customer.email : guestEmail.trim() || 'client-whatsapp@afrotrade.com',
          city: guestCity.trim() || 'Afrique',
          address: 'Commande passée via WhatsApp',
          postalCode: '',
          country: customer?.address?.country || 'Cameroun',
        },
        notes: guestNotes.trim(),
      });

      if (result.whatsAppUrl) {
        // Safe navigation to WhatsApp
        const link = document.createElement('a');
        link.href = result.whatsAppUrl;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }

      onClose();
    } catch (err: any) {
      console.error('Error creating WhatsApp order:', err);
      setErrorMessage(
        err?.message || 'Erreur lors de la préparation de la commande WhatsApp.'
      );
    } finally {
      setLoading(false);
    }
  };

  // Handler for Option 2: Continuer sur le site
  const handleSiteOrderClick = () => {
    if (!customer) {
      setStep('guest_form');
    } else {
      executeSiteOrder();
    }
  };

  const executeSiteOrder = async () => {
    setLoading(true);
    setErrorMessage(null);
    try {
      const result = await createOrderDemand({
        channel: 'site',
        customerInfo: {
          firstName: customer ? customer.firstName : guestName.trim() || 'Client',
          lastName: customer ? customer.lastName : 'Boutique',
          phone: customer ? customer.phone : guestPhone.trim() || 'Non renseigné',
          email: customer ? customer.email : guestEmail.trim() || 'client@afrotrade.com',
          city: guestCity.trim() || 'Douala',
          address: 'Commande validée sur le site',
          postalCode: '',
          country: customer?.address?.country || 'Cameroun',
        },
        notes: guestNotes.trim(),
      });

      onClose();

      // Open discussion space with this demand
      if (result.order) {
        openChatWithOrder(result.order.reference);
        // Also if user is logged in, navigate to account discussions tab or catalog
        if (customer) {
          navigateTo('account');
        }
      }
    } catch (err: any) {
      console.error('Error creating site order:', err);
      setErrorMessage(
        err?.message || 'Erreur lors de la création de la demande sur le site.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-[#CBD5E1] overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="bg-[#0A2540] text-white p-5 sm:p-6 flex items-center justify-between border-b border-[#183E66]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#183E66] border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B] shrink-0 font-black">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#F59E0B]">
                Place de marché & Import B2B
              </span>
              <h2 className="text-base sm:text-lg font-black text-white tracking-tight">
                Comment souhaitez-vous passer commande ?
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#94A3B8] hover:text-white rounded-xl hover:bg-[#183E66] transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Chariot summary bar */}
        <div className="bg-[#F8FAFC] border-b border-[#E2E8F0] px-5 py-3 flex flex-wrap items-center justify-between text-xs gap-2">
          <div className="flex items-center gap-2">
            <span className="font-bold text-[#0F172A]">Chariot sélectionné :</span>
            <span className="bg-[#0A2540] text-white px-2 py-0.5 rounded-full font-bold text-[11px]">
              {cartCount} article{cartCount > 1 ? 's' : ''}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[#64748B]">Total estimé : </span>
            <span className="font-black text-[#0A2540] text-sm">
              {formatPrice(cartTotal, cartTotal)}
            </span>
            <span className="text-[10px] text-[#D97706] font-bold block sm:inline sm:ml-1">
              ({getFCFAEquivalent(cartTotal)})
            </span>
          </div>
        </div>

        {errorMessage && (
          <div className="m-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl font-medium">
            {errorMessage}
          </div>
        )}

        {/* Step 1: Choice of Order Mode */}
        {step === 'choice' && (
          <div className="p-5 sm:p-7 space-y-6">
            <p className="text-xs sm:text-sm text-[#475569] leading-relaxed">
              Choisissez votre méthode préférée pour transmettre vos articles sélectionnés au propriétaire d'AfroTrade Express :
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Option 1: Commander via WhatsApp */}
              <div
                className={`flex flex-col justify-between p-5 rounded-2xl border-2 transition-all ${
                  whatsAppReady
                    ? 'border-[#22C55E]/40 bg-[#F0FDF4]/50 hover:border-[#22C55E] hover:shadow-md'
                    : 'border-stone-200 bg-stone-50 opacity-90'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-[#22C55E] text-white flex items-center justify-center shadow-xs">
                      <MessageCircle className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#16A34A] bg-[#DCFCE7] px-2 py-0.5 rounded-full">
                      Direct WhatsApp
                    </span>
                  </div>

                  <div>
                    <h3 className="font-black text-sm text-[#0F172A]">
                      1. Commander via WhatsApp
                    </h3>
                    <p className="text-xs text-[#475569] mt-1 leading-relaxed">
                      Ouvre une conversation WhatsApp préremplie avec chaque article, son nom, sa quantité, son prix et le total estimé.
                    </p>
                  </div>

                  <ul className="text-[11px] text-[#16A34A] space-y-1 font-medium">
                    <li>✓ Message généré et prérempli</li>
                    <li>✓ Vous vérifiez avant d'appuyer sur Envoyer</li>
                    <li>✓ Échanges rapides et directs</li>
                  </ul>

                  {!whatsAppReady && (
                    <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>Numéro WhatsApp non configuré</span>
                      </div>
                      <p className="text-[10px] leading-relaxed text-amber-800">
                        Le numéro WhatsApp du propriétaire n'a pas encore été renseigné dans le panneau d'administration. Veuillez choisir "Continuer sur le site" ci-contre.
                      </p>
                    </div>
                  )}
                </div>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={handleWhatsAppOrder}
                    disabled={!whatsAppReady || loading}
                    className={`w-full min-h-[46px] py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs ${
                      whatsAppReady
                        ? 'bg-[#22C55E] hover:bg-[#16A34A] text-white active:scale-98'
                        : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                    }`}
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>
                      {loading ? 'Préparation...' : 'Commander via WhatsApp'}
                    </span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Option 2: Continuer sur le site */}
              <div className="flex flex-col justify-between p-5 rounded-2xl border-2 border-[#0A2540]/30 bg-[#F8FAFC] hover:border-[#0A2540] hover:shadow-md transition-all">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-[#0A2540] text-[#F59E0B] flex items-center justify-center shadow-xs">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-wider text-[#0A2540] bg-[#0A2540]/10 px-2 py-0.5 rounded-full">
                      Espace de Discussion
                    </span>
                  </div>

                  <div>
                    <h3 className="font-black text-sm text-[#0F172A]">
                      2. Continuer sur le site
                    </h3>
                    <p className="text-xs text-[#475569] mt-1 leading-relaxed">
                      Crée une demande officielle et ouvre un espace de discussion interactif sur le site avec le récapitulatif complet de vos articles.
                    </p>
                  </div>

                  <ul className="text-[11px] text-[#0A2540] space-y-1 font-medium">
                    <li>✓ Récapitulatif avec photos, prix et quantités</li>
                    <li>✓ Discussion en direct avec le propriétaire</li>
                    <li>✓ Suivi des statuts (Nouvelle, En discussion...)</li>
                  </ul>

                  {customer && (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-[11px] text-emerald-800 flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>
                        Identifié : <strong>{customer.firstName} {customer.lastName}</strong>
                      </span>
                    </div>
                  )}
                </div>

                <div className="pt-4">
                  <button
                    type="button"
                    onClick={handleSiteOrderClick}
                    disabled={loading}
                    className="w-full min-h-[46px] py-2.5 px-4 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs active:scale-98"
                  >
                    <MessageSquare className="w-4 h-4 text-[#F59E0B]" />
                    <span>
                      {loading ? 'Création de la demande...' : 'Continuer sur le site'}
                    </span>
                    <ArrowRight className="w-4 h-4 text-[#F59E0B]" />
                  </button>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-[#E2E8F0] flex items-center justify-center gap-2 text-[11px] text-[#64748B]">
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
              <span>Commande sans paiement bancaire préalable • Négociation B2B directe</span>
            </div>
          </div>
        )}

        {/* Step 2: Simple identification for Guest before Site Order */}
        {step === 'guest_form' && (
          <div className="p-5 sm:p-7 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#E2E8F0]">
              <div>
                <h3 className="font-bold text-sm text-[#0F172A]">
                  Identification pour votre espace de discussion
                </h3>
                <p className="text-xs text-[#64748B]">
                  Renseignez vos coordonnées pour associer vos échanges à votre demande.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setStep('choice')}
                className="text-xs text-[#0A2540] hover:underline font-bold"
              >
                ← Retour au choix
              </button>
            </div>

            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Votre nom / prénom <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="ex: Paul Biya"
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Téléphone / WhatsApp <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder="+237 6 99 00 00 00"
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Ville / Pays de livraison
                  </label>
                  <input
                    type="text"
                    value={guestCity}
                    onChange={(e) => setGuestCity(e.target.value)}
                    placeholder="Douala, Cameroun..."
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#334155] mb-1">
                    Adresse e-mail (facultative)
                  </label>
                  <input
                    type="email"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    placeholder="votre.email@exemple.com"
                    className="w-full px-3 py-2 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#334155] mb-1">
                  Message ou précision pour le propriétaire (facultatif)
                </label>
                <textarea
                  rows={2}
                  value={guestNotes}
                  onChange={(e) => setGuestNotes(e.target.value)}
                  placeholder="Ex: Demande de tarif de gros, délais souhaités, fret aérien..."
                  className="w-full p-2.5 bg-[#F8FAFC] border border-[#CBD5E1] rounded-xl text-xs text-[#0F172A] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
                />
              </div>
            </div>

            <div className="pt-3 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  navigateTo('account');
                }}
                className="text-xs text-[#0A2540] hover:underline font-bold"
              >
                Déjà un compte ? Se connecter
              </button>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => setStep('choice')}
                  className="px-4 py-2.5 rounded-xl border border-[#CBD5E1] text-xs font-bold text-[#64748B] hover:bg-[#F1F5F9] cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={executeSiteOrder}
                  disabled={!guestName.trim() || !guestPhone.trim() || loading}
                  className="flex-1 sm:flex-none min-h-[44px] px-6 py-2.5 bg-[#0A2540] hover:bg-[#183E66] disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <span>{loading ? 'Création...' : 'Créer la demande & Discuter'}</span>
                  <ArrowRight className="w-4 h-4 text-[#F59E0B]" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
