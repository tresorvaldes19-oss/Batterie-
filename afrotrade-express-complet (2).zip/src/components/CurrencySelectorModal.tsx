import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { AFRICAN_CURRENCIES, CurrencyInfo } from '../constants/currencies.ts';
import { X, Search, Coins, Check, Globe2 } from 'lucide-react';
import { Currency } from '../types/index.ts';

interface CurrencySelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CurrencySelectorModal: React.FC<CurrencySelectorModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { currency, setCurrency } = useStore();
  const [search, setSearch] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('Tous');

  const regions = [
    'Tous',
    'Afrique Centrale',
    'Afrique de l\'Ouest',
    'Afrique de l\'Est',
    'Afrique du Nord',
    'Afrique Australe',
    'International',
  ];

  const filteredCurrencies = useMemo(() => {
    return AFRICAN_CURRENCIES.filter((c) => {
      // Region filter
      if (selectedRegion !== 'Tous' && c.region !== selectedRegion) {
        return false;
      }
      // Search filter
      if (!search.trim()) return true;
      const q = search.toLowerCase().trim();
      const matchCode = c.code.toLowerCase().includes(q);
      const matchName = c.name.toLowerCase().includes(q);
      const matchSymbol = c.symbol.toLowerCase().includes(q);
      const matchCountry = c.countries.some((cnt) => cnt.toLowerCase().includes(q));
      return matchCode || matchName || matchSymbol || matchCountry;
    });
  }, [search, selectedRegion]);

  if (!isOpen) return null;

  const handleSelect = (code: string) => {
    setCurrency(code as Currency);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] shadow-2xl flex flex-col overflow-hidden border border-[#E2E8F0]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-[#0A2540] to-[#183E66] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#F59E0B] text-[#0A2540] flex items-center justify-center shrink-0 shadow-md">
              <Coins className="w-5 h-5 font-bold" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>Devises Africaines & Internationales</span>
                <span className="text-[10px] bg-[#F59E0B] text-[#0A2540] px-2 py-0.5 rounded-full font-bold uppercase">
                  54 Pays
                </span>
              </h2>
              <p className="text-[11px] text-[#CBD5E1]">
                Choisissez la monnaie de votre pays pour afficher les prix en temps réel
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-[#CBD5E1] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search bar & Popular shortcuts */}
        <div className="p-4 border-b border-[#E2E8F0] space-y-3 bg-[#F8FAFC] shrink-0">
          <div className="relative">
            <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher par pays ou devise (ex: Cameroun, RDC, Naira, Sénégal, Côte d'Ivoire, FCFA...)"
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-[#CBD5E1] rounded-2xl text-xs text-[#0F172A] placeholder-[#94A3B8] focus:outline-none focus:ring-2 focus:ring-[#0A2540]"
              autoFocus
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[#94A3B8] hover:text-[#0F172A]"
              >
                Effacer
              </button>
            )}
          </div>

          {/* Quick Popular Currency Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            <span className="text-[10px] font-bold text-[#64748B] uppercase tracking-wider shrink-0 mr-1">
              Populaires :
            </span>
            {AFRICAN_CURRENCIES.filter((c) => c.popular).slice(0, 8).map((c) => {
              const isSelected = currency === c.code || (currency === 'FCFA' && c.code === 'XAF');
              return (
                <button
                  key={c.code}
                  type="button"
                  onClick={() => handleSelect(c.code)}
                  className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                    isSelected
                      ? 'bg-[#0A2540] text-[#F59E0B] border-[#0A2540] shadow-xs'
                      : 'bg-white hover:bg-[#F1F5F9] text-[#334155] border-[#CBD5E1]'
                  }`}
                >
                  <span>{c.flag}</span>
                  <span>{c.code}</span>
                  <span className="opacity-70 text-[10px] font-normal">({c.symbol})</span>
                </button>
              );
            })}
          </div>

          {/* Regions tab filter */}
          <div className="flex items-center gap-1 overflow-x-auto text-[11px] no-scrollbar">
            {regions.map((reg) => (
              <button
                key={reg}
                type="button"
                onClick={() => setSelectedRegion(reg)}
                className={`px-2.5 py-1 rounded-lg font-bold transition-colors shrink-0 cursor-pointer ${
                  selectedRegion === reg
                    ? 'bg-[#0A2540] text-white'
                    : 'text-[#64748B] hover:text-[#0F172A] hover:bg-white'
                }`}
              >
                {reg}
              </button>
            ))}
          </div>
        </div>

        {/* Currency Grid / List */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-[#F1F5F9] max-h-[50vh]">
          {filteredCurrencies.length === 0 ? (
            <div className="text-center py-12 text-[#94A3B8] space-y-2">
              <Globe2 className="w-8 h-8 mx-auto opacity-50" />
              <p className="text-xs font-bold text-[#0F172A]">Aucune devise trouvée</p>
              <p className="text-[11px]">
                Essayez avec un autre nom de pays (ex: Cameroun, RDC, Ghana, Gabon...)
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {filteredCurrencies.map((c) => {
                const isSelected =
                  currency === c.code ||
                  (currency === 'FCFA' && c.code === 'XAF');

                return (
                  <button
                    key={c.code}
                    type="button"
                    onClick={() => handleSelect(c.code)}
                    className={`p-3 rounded-2xl text-left transition-all flex items-start gap-3 cursor-pointer border ${
                      isSelected
                        ? 'bg-[#FEF3C7] border-[#F59E0B] shadow-xs'
                        : 'bg-white hover:bg-[#F8FAFC] border-[#E2E8F0]'
                    }`}
                  >
                    <span className="text-2xl shrink-0 mt-0.5">{c.flag}</span>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <div className="flex items-center gap-1.5 truncate">
                          <span className="font-black text-xs text-[#0A2540]">{c.code}</span>
                          <span className="text-[11px] font-bold text-[#D97706] bg-[#FFFBEB] px-1.5 py-0.2 rounded border border-[#FDE68A]">
                            {c.symbol}
                          </span>
                        </div>
                        {isSelected && (
                          <span className="w-5 h-5 rounded-full bg-[#16A34A] text-white flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        )}
                      </div>

                      <p className="text-xs font-semibold text-[#0F172A] truncate mt-0.5">
                        {c.name}
                      </p>

                      <p className="text-[10px] text-[#64748B] truncate mt-0.5" title={c.countries.join(', ')}>
                        {c.countries.slice(0, 3).join(', ')}
                        {c.countries.length > 3 ? ` +${c.countries.length - 3}` : ''}
                      </p>

                      <div className="mt-1 flex items-center justify-between text-[10px] text-[#94A3B8] font-mono">
                        <span>1$ USD ≈ {c.rateToUSD.toLocaleString('fr-FR')} {c.symbol}</span>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3.5 bg-[#F8FAFC] border-t border-[#E2E8F0] text-center text-[11px] text-[#64748B] shrink-0">
          <span>
            Les conversions de prix sont calculées automatiquement sur la base des prix usine en dollars ($).
          </span>
        </div>
      </div>
    </div>
  );
};
