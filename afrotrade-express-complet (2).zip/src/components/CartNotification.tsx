import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Check, ShoppingCart, X, ArrowRight } from 'lucide-react';

export const CartNotification: React.FC = () => {
  const { cartToast, dismissCartToast, setIsCartOpen, formatPrice } = useStore();

  if (!cartToast.visible || !cartToast.product) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 max-w-sm w-[calc(100vw-2rem)] sm:w-96 bg-white rounded-2xl border-2 border-[#F59E0B]/40 shadow-2xl p-4 animate-in slide-in-from-bottom duration-300">
      <div className="flex items-start gap-3">
        {/* Check icon in green / orange pill */}
        <div className="w-8 h-8 rounded-full bg-[#DCFCE7] text-[#16A34A] flex items-center justify-center shrink-0 mt-0.5">
          <Check className="w-4 h-4 stroke-[3]" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-[#0F172A]">
              Produit ajouté au panier
            </h4>
            <button
              onClick={dismissCartToast}
              className="text-[#94A3B8] hover:text-[#0F172A] p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-2.5 mt-2">
            <img
              src={cartToast.product.mainImage || cartToast.product.images?.[0]}
              alt={cartToast.product.name}
              className="w-10 h-10 rounded-lg object-contain bg-[#F8FAFC] border border-[#E2E8F0] shrink-0 p-1"
            />
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-[#0F172A] truncate">
                {cartToast.product.name}
              </p>
              <p className="text-[11px] font-bold text-[#D97706]">
                {formatPrice(cartToast.product.priceEUR, cartToast.product.priceUSD)}
              </p>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-2">
            <button
              onClick={() => {
                dismissCartToast();
                setIsCartOpen(true);
              }}
              className="w-full min-h-[44px] py-2.5 bg-[#0A2540] hover:bg-[#183E66] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <ShoppingCart className="w-4 h-4 text-[#F59E0B]" />
              <span>Voir mon panier</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
