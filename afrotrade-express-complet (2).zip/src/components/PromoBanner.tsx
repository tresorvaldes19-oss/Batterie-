import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Sparkles, ArrowRight } from 'lucide-react';

export const PromoBanner: React.FC = () => {
  const { settings, navigateTo } = useStore();

  if (!settings.promoBannerEnabled || !settings.promoBannerText) {
    return null;
  }

  return (
    <div className="bg-stone-900 text-stone-100 text-xs sm:text-sm py-2 px-4 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-center text-center gap-2 font-medium">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
        <span>{settings.promoBannerText}</span>
        <button
          onClick={() => navigateTo('catalog')}
          className="underline hover:text-amber-300 ml-2 inline-flex items-center gap-1 font-semibold cursor-pointer"
        >
          Découvrir <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
