import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  MessageCircle,
  Mail,
  Clock,
  MapPin,
  Lock,
  Plane,
  Ship,
  ShieldCheck,
  Facebook,
  Instagram,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, navigateTo } = useStore();

  const cleanWhatsApp = (settings.whatsappPhone || '237699452010').replace(/[^0-9]/g, '');
  const whatsappUrl = `https://wa.me/${cleanWhatsApp}`;
  const displayWhatsApp = settings.whatsappPhone
    ? `+${cleanWhatsApp.slice(0, 3)} ${cleanWhatsApp.slice(3, 4)} ${cleanWhatsApp.slice(4, 6)} ${cleanWhatsApp.slice(6, 8)} ${cleanWhatsApp.slice(8)}`.trim()
    : '+237 6 99 45 20 10';

  return (
    <footer className="bg-[#051322] text-[#94A3B8] pt-16 pb-12 border-t border-[#183E66]/40">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Main 4 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 text-xs">
          {/* Colonne 1 : Présentation */}
          <div className="space-y-4">
            <div>
              <span className="font-black text-xl text-white tracking-tight">
                {settings.name || 'AfroTrade Express'}
              </span>
              <p className="text-[#FBBF24] text-[11px] font-semibold mt-0.5">
                {settings.tagline || 'Import Chine → Afrique'}
              </p>
            </div>
            <p className="text-[#94A3B8] leading-relaxed">
              Votre partenaire de confiance pour l’importation de produits directement depuis la Chine vers l’Afrique. Groupage aérien et maritime sécurisé au départ de Shenzhen.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href={settings.socialLinks?.facebook || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#0A2540] hover:bg-[#F59E0B] hover:text-[#0A2540] text-white flex items-center justify-center transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href={settings.socialLinks?.instagram || '#'}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#0A2540] hover:bg-[#F59E0B] hover:text-[#0A2540] text-white flex items-center justify-center transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-full bg-[#22C55E] text-white flex items-center justify-center transition-colors"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Colonne 2 : Zones desservies */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase text-[11px] tracking-wider">
              Zones Desservies
            </h4>
            <ul className="space-y-2 text-[#CBD5E1]">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Cameroun (Douala & Yaoundé)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Congo (Brazzaville & Pointe-Noire)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Gabon (Libreville & Port-Gentil)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Côte d’Ivoire (Abidjan)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Bénin (Cotonou)</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B]" />
                <span>Autres pays africains</span>
              </li>
              <li className="flex items-center gap-2 text-[#38BDF8] pt-1">
                <MapPin className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Hub Chine : Shenzhen & Guangzhou</span>
              </li>
            </ul>
          </div>

          {/* Colonne 3 : Navigation */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase text-[11px] tracking-wider">
              Navigation
            </h4>
            <ul className="space-y-2 text-[#CBD5E1]">
              <li>
                <button
                  onClick={() => navigateTo('home')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Accueil
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('catalog')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Catalogue général
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('cart')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Mon Panier d'achats
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('account')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Connexion & Suivi
                </button>
              </li>
              <li>
                <button
                  onClick={() => navigateTo('contact')}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Contact & Devis
                </button>
              </li>
            </ul>
          </div>

          {/* Colonne 4 : Assistance */}
          <div className="space-y-3">
            <h4 className="text-white font-bold uppercase text-[11px] tracking-wider">
              Assistance & Support
            </h4>
            <div className="space-y-2.5 text-[#CBD5E1]">
              <div className="flex items-start gap-2.5">
                <MessageCircle className="w-4 h-4 text-[#22C55E] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">WhatsApp Direct :</strong>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#38BDF8] hover:underline"
                  >
                    {displayWhatsApp}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">Email :</strong>
                  <span>{settings.email || 'contact@afrotrade-express.com'}</span>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white block font-semibold">Horaires d'assistance :</strong>
                  <span>{settings.openingHours || 'Lun - Sam : 08h00 - 19h00 (GMT+1)'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Line */}
        <div className="pt-8 border-t border-[#183E66]/60 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#64748B] gap-4">
          <p>© {new Date().getFullYear()} {settings.name || 'AfroTrade Express'}. Tous droits réservés.</p>

          <div className="flex items-center gap-2 sm:gap-4 flex-wrap justify-center">
            <button
              onClick={() => navigateTo('legal', { orderRef: 'cgv' })}
              className="hover:text-white transition-colors cursor-pointer min-h-[44px] flex items-center px-1"
            >
              Conditions générales
            </button>
            <span>•</span>
            <button
              onClick={() => navigateTo('legal', { orderRef: 'privacy' })}
              className="hover:text-white transition-colors cursor-pointer min-h-[44px] flex items-center px-1"
            >
              Confidentialité
            </button>
            <span>•</span>
            <button
              onClick={() => navigateTo('legal', { orderRef: 'returns' })}
              className="hover:text-white transition-colors cursor-pointer min-h-[44px] flex items-center px-1"
            >
              Retours
            </button>
            <span>•</span>
            <span className="text-[#94A3B8] font-bold">Shenzhen • Afrique</span>
            <span>•</span>

            {/* Discreet Admin Link */}
            <button
              onClick={() => navigateTo('admin-login')}
              className="text-[#64748B] hover:text-[#F59E0B] flex items-center gap-1 cursor-pointer min-h-[44px] px-2 font-semibold"
              title="Panneau Administrateur"
            >
              <Lock className="w-3.5 h-3.5 text-[#64748B]" />
              <span>Administration</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
