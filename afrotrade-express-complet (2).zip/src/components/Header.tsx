import React, { useState } from 'react';
import { useStore } from '../context/StoreContext.tsx';
import { Currency, Language } from '../types/index.ts';
import {
  ShoppingCart,
  Menu,
  X,
  Globe,
  DollarSign,
  User,
  SlidersHorizontal,
  ChevronDown,
  ShieldCheck,
  Package,
  Coins,
  MessageSquare,
} from 'lucide-react';

export const Header: React.FC = () => {
  const {
    settings,
    currency,
    currencyInfo,
    setCurrency,
    openCurrencyModal,
    language,
    setLanguage,
    cartCount,
    setIsCartOpen,
    setIsChatOpen,
    customer,
    isAdmin,
    adminLogout,
    navigateTo,
    navState,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdown, setLangDropdown] = useState(false);
  const [currencyDropdown, setCurrencyDropdown] = useState(false);

  return (
    <>
      {/* Top Admin Bar if Logged in */}
      {isAdmin && (
        <div className="bg-[#051322] text-[#F59E0B] text-xs px-4 py-2 border-b border-[#183E66] z-50">
          <div className="max-w-[1280px] mx-auto w-full flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
              <span className="font-bold text-white text-[11px] sm:text-xs">Mode Administrateur Actif</span>
            </div>
            <div className="flex items-center gap-3 sm:gap-4">
              <button
                onClick={() => navigateTo('admin-dashboard')}
                className="underline hover:text-white font-bold flex items-center gap-1.5 cursor-pointer min-h-[36px] py-1 text-[11px] sm:text-xs"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Panneau de Gestion</span>
              </button>
              <button
                onClick={adminLogout}
                className="text-[#94A3B8] hover:text-rose-400 transition-colors cursor-pointer min-h-[36px] py-1 text-[11px] sm:text-xs font-semibold"
              >
                Déconnexion
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Sticky Header */}
      <header className="sticky top-0 z-40 bg-[#0A2540] text-white shadow-lg transition-all border-b border-[#183E66]">
        <div className="max-w-[1280px] mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Left: Logo & Baseline */}
            <div className="flex items-center gap-3 sm:gap-6 min-w-0">
              <button
                onClick={() => navigateTo('catalog')}
                className="flex flex-col text-left group cursor-pointer min-w-0"
              >
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <span className="font-black text-lg sm:text-2xl tracking-tight text-white group-hover:text-[#FBBF24] transition-colors truncate">
                    {settings.name || 'AfroTrade Express'}
                  </span>
                  <span className="shrink-0 bg-[#F59E0B] text-[#0A2540] text-[9px] font-black uppercase px-1.5 py-0.5 rounded tracking-wider">
                    B2B & B2C
                  </span>
                </div>
                <span className="text-[10px] sm:text-[11px] font-medium text-[#FBBF24] tracking-wide mt-0.5 truncate">
                  {settings.tagline || 'Import Chine → Afrique'}
                </span>
              </button>
            </div>

            {/* Center: Desktop Navigation Links (hidden on mobile/tablet) */}
            <nav className="hidden lg:flex items-center gap-8 text-sm font-semibold text-[#CBD5E1]">
              <button
                onClick={() => navigateTo('catalog')}
                className={`transition-colors hover:text-white cursor-pointer min-h-[44px] flex items-center ${
                  navState.page === 'catalog'
                    ? 'text-white font-bold border-b-2 border-[#F59E0B]'
                    : ''
                }`}
              >
                Catalogue
              </button>
              <button
                onClick={() => navigateTo('home')}
                className={`transition-colors hover:text-white cursor-pointer min-h-[44px] flex items-center ${
                  navState.page === 'home'
                    ? 'text-white font-bold border-b-2 border-[#F59E0B]'
                    : ''
                }`}
              >
                Accueil
              </button>
              <button
                onClick={() => navigateTo('cart')}
                className={`transition-colors hover:text-white cursor-pointer min-h-[44px] flex items-center ${
                  navState.page === 'cart'
                    ? 'text-white font-bold border-b-2 border-[#F59E0B]'
                    : ''
                }`}
              >
                Panier
              </button>
              <button
                onClick={() => navigateTo('contact')}
                className={`transition-colors hover:text-white cursor-pointer min-h-[44px] flex items-center ${
                  navState.page === 'contact'
                    ? 'text-white font-bold border-b-2 border-[#F59E0B]'
                    : ''
                }`}
              >
                Contact
              </button>
            </nav>

            {/* Right: Actions */}
            <div className="flex items-center gap-1.5 sm:gap-3">
              {/* Language Selector Dropdown (Desktop only) */}
              <div className="relative hidden lg:block">
                <button
                  type="button"
                  onClick={() => {
                    setLangDropdown(!langDropdown);
                    setCurrencyDropdown(false);
                  }}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-[#183E66] hover:bg-[#1e4c7d] text-xs font-semibold text-white transition-colors cursor-pointer min-h-[44px]"
                >
                  <Globe className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span>{language}</span>
                  <ChevronDown className="w-3 h-3 text-[#94A3B8]" />
                </button>

                {langDropdown && (
                  <div className="absolute right-0 mt-1.5 w-28 bg-white rounded-xl shadow-xl py-1 text-xs text-[#0F172A] font-medium border border-[#E2E8F0] z-50 animate-in fade-in duration-150">
                    {(['FR', 'EN', 'AR'] as Language[]).map((lang) => (
                      <button
                        key={lang}
                        onClick={() => {
                          setLanguage(lang);
                          setLangDropdown(false);
                        }}
                        className={`w-full text-left px-3 py-2 hover:bg-[#F1F5F9] cursor-pointer min-h-[36px] ${
                          language === lang ? 'font-bold text-[#D97706] bg-[#FFFBEB]' : ''
                        }`}
                      >
                        {lang === 'FR' ? 'Français' : lang === 'EN' ? 'English' : 'العربية'}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Currency Selector (All African Currencies Modal Trigger) */}
              <button
                type="button"
                onClick={openCurrencyModal}
                className="hidden lg:flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#183E66] hover:bg-[#1e4c7d] text-xs font-bold text-white transition-all cursor-pointer min-h-[44px] border border-[#183E66] shadow-2xs hover:scale-[1.02]"
                title="Sélectionner la devise d'un pays africain"
              >
                <span className="text-base leading-none">{currencyInfo.flag}</span>
                <span className="text-[#F59E0B] font-black">{currencyInfo.code}</span>
                <span className="text-stone-300 text-[11px] font-medium">({currencyInfo.symbol})</span>
                <ChevronDown className="w-3 h-3 text-[#94A3B8]" />
              </button>

              {/* Live Chat & Service Client Trigger */}
              <button
                type="button"
                onClick={() => setIsChatOpen(true)}
                className="hidden xl:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#0A2540] hover:bg-[#183E66] text-xs font-bold text-white border border-[#F59E0B]/30 transition-all cursor-pointer min-h-[44px] shadow-2xs"
                title="Discuter avec le service client & IA à temps plein"
              >
                <div className="relative">
                  <MessageSquare className="w-3.5 h-3.5 text-[#F59E0B]" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
                </div>
                <span>Discussion en direct</span>
              </button>

              {/* Desktop Auth Buttons */}
              <div className="hidden lg:flex items-center gap-2">
                <button
                  onClick={() => navigateTo('account')}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-white hover:bg-[#183E66] transition-colors cursor-pointer min-h-[44px]"
                >
                  {customer ? `Compte (${customer.firstName})` : 'Connexion'}
                </button>
                {!customer && (
                  <button
                    onClick={() => navigateTo('account')}
                    className="px-4 py-2 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs tracking-wide transition-all shadow-sm cursor-pointer min-h-[44px]"
                  >
                    Inscription
                  </button>
                )}
              </div>

              {/* Cart Icon (Always visible, min 44x44px touch target) */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative min-w-[44px] min-h-[44px] w-11 h-11 bg-[#183E66] hover:bg-[#1e4c7d] text-white rounded-xl transition-all cursor-pointer flex items-center justify-center"
                aria-label="Mon chariot"
                title="Mon chariot"
              >
                <ShoppingCart className="w-5 h-5 text-[#FBBF24]" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#F59E0B] text-[#0A2540] text-[10px] font-black h-5 min-w-[20px] px-1 rounded-full flex items-center justify-center border-2 border-[#0A2540] shadow-sm">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile Hamburger Menu Button (Min 44x44px touch target) */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden min-w-[44px] min-h-[44px] w-11 h-11 flex items-center justify-center text-white hover:bg-[#183E66] rounded-xl transition-colors cursor-pointer"
                aria-label="Menu"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Slide-Down Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#051322] border-t border-[#183E66] px-5 py-6 space-y-5 animate-in slide-in-from-top duration-200 shadow-2xl">
            {/* Primary Navigation */}
            <nav className="space-y-1">
              <button
                onClick={() => {
                  navigateTo('catalog');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-bold min-h-[44px] ${
                  navState.page === 'catalog'
                    ? 'bg-[#183E66] text-[#F59E0B]'
                    : 'text-white hover:bg-[#183E66]/60'
                }`}
              >
                <span>Catalogue Général</span>
                <span className="text-xs text-[#94A3B8]">Tous nos produits</span>
              </button>
              <button
                onClick={() => {
                  navigateTo('home');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-bold min-h-[44px] ${
                  navState.page === 'home'
                    ? 'bg-[#183E66] text-[#F59E0B]'
                    : 'text-[#CBD5E1] hover:bg-[#183E66]/60'
                }`}
              >
                <span>Accueil & Fret Transit</span>
                <span className="text-xs text-[#94A3B8]">Shenzhen Hub</span>
              </button>
              <button
                onClick={() => {
                  navigateTo('cart');
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-bold min-h-[44px] ${
                  navState.page === 'cart'
                    ? 'bg-[#183E66] text-[#F59E0B]'
                    : 'text-[#CBD5E1] hover:bg-[#183E66]/60'
                }`}
              >
                <span>Mon Panier</span>
                <span className="bg-[#F59E0B] text-[#0A2540] text-xs font-black px-2 py-0.5 rounded-full">
                  {cartCount}
                </span>
              </button>
              <a
                href={`https://wa.me/${(settings.whatsappPhone || '237699452010').replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full flex items-center justify-between px-3 py-3 rounded-xl text-sm font-bold min-h-[44px] text-[#CBD5E1] hover:bg-[#183E66]/60 cursor-pointer"
              >
                <span>Assistance WhatsApp & Devis</span>
                <span className="text-xs text-[#22C55E] font-bold">En ligne ↗</span>
              </a>
            </nav>

            {/* Currency & Language Mobile Pickers */}
            <div className="pt-3 border-t border-[#183E66] space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-[#94A3B8] uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span>Devise d'affichage</span>
                  <span className="text-[#F59E0B] text-[10px] font-bold">54 Pays Africains</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    openCurrencyModal();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full min-h-[46px] p-2.5 rounded-xl bg-[#183E66] hover:bg-[#1e4c7d] text-white flex items-center justify-between cursor-pointer border border-[#183E66]"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-xl">{currencyInfo.flag}</span>
                    <div className="text-left">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[#F59E0B] font-black text-xs">{currencyInfo.code}</span>
                        <span className="text-stone-300 text-[11px]">({currencyInfo.symbol})</span>
                      </div>
                      <span className="text-[10px] text-[#94A3B8] block truncate max-w-[180px]">
                        {currencyInfo.name}
                      </span>
                    </div>
                  </div>
                  <span className="text-[11px] text-[#F59E0B] underline font-bold px-2 py-1 rounded bg-[#0A2540]">
                    Changer 🌍
                  </span>
                </button>
              </div>

              {/* Discussion en direct button in mobile menu */}
              <div>
                <button
                  type="button"
                  onClick={() => {
                    setIsChatOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full min-h-[44px] py-2.5 px-3 rounded-xl bg-[#0A2540] hover:bg-[#183E66] text-white flex items-center justify-center gap-2 text-xs font-bold border border-[#F59E0B]/30"
                >
                  <div className="relative">
                    <MessageSquare className="w-4 h-4 text-[#F59E0B]" />
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#22C55E] animate-pulse" />
                  </div>
                  <span>Discussion Service Client & IA 24/7</span>
                </button>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-[#94A3B8] uppercase tracking-wider mb-1.5">
                  Langue
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['FR', 'EN', 'AR'] as Language[]).map((l) => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => setLanguage(l)}
                      className={`min-h-[44px] py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        language === l
                          ? 'bg-white text-[#0A2540] shadow-sm font-black'
                          : 'bg-[#183E66] text-[#CBD5E1] hover:text-white'
                      }`}
                    >
                      {l === 'FR' ? 'Français' : l === 'EN' ? 'English' : 'العربية'}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Customer & Admin Access */}
            <div className="pt-3 border-t border-[#183E66] space-y-2.5">
              <button
                onClick={() => {
                  navigateTo('account');
                  setMobileMenuOpen(false);
                }}
                className="w-full min-h-[44px] py-3 bg-[#F59E0B] hover:bg-[#D97706] text-[#0A2540] font-black rounded-xl text-xs uppercase tracking-wider text-center transition-colors cursor-pointer"
              >
                {customer ? `Mon Espace Client (${customer.firstName})` : 'Espace Client / Connexion'}
              </button>

              <button
                onClick={() => {
                  navigateTo('admin-login');
                  setMobileMenuOpen(false);
                }}
                className="w-full min-h-[44px] py-2.5 bg-[#183E66]/60 hover:bg-[#183E66] text-stone-300 hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <ShieldCheck className="w-4 h-4 text-[#F59E0B]" />
                <span>Administration de la Boutique</span>
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
