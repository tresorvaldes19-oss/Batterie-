import React from 'react';
import { useStore } from '../context/StoreContext.tsx';
import {
  X,
  Plus,
  Minus,
  Trash2,
  ArrowRight,
  ShoppingBag,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    updateCartQuantity,
    removeFromCart,
    cartSubtotal,
    cartShipping,
    cartTotal,
    freeShippingRemaining,
    currency,
    currencyInfo,
    setCurrency,
    openCurrencyModal,
    formatPrice,
    navigateTo,
  } = useStore();

  if (!isCartOpen) return null;

  const handleCheckoutClick = () => {
    setIsCartOpen(false);
    navigateTo('checkout');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-stone-900/50 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Header */}
          <div className="px-6 py-5 border-b border-stone-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-amber-800" />
              <h2 className="text-lg font-medium text-stone-900 font-serif">
                Mon Panier ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-2 text-stone-400 hover:text-stone-700 rounded-full hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Alert Bar */}
          <div className="bg-amber-50/70 border-b border-amber-100 px-6 py-3">
            {freeShippingRemaining > 0 ? (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs text-amber-900 font-medium">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Livraison offerte à partir de {formatPrice(120, 130)}
                  </span>
                  <span className="font-bold">
                    Plus que {formatPrice(freeShippingRemaining, freeShippingRemaining)}
                  </span>
                </div>
                <div className="w-full bg-amber-200/80 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-amber-700 h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(100, Math.max(10, ((120 - freeShippingRemaining) / 120) * 100))}%`,
                    }}
                  />
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                <span>Félicitations ! Vous bénéficiez de la livraison offerte !</span>
              </div>
            )}
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto px-6 py-4 divide-y divide-stone-100">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mb-4">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-medium text-stone-900">Votre panier est vide</h3>
                <p className="text-xs text-stone-500 mt-1 max-w-xs">
                  Explorez nos collections artisanales et ajoutez vos coups de cœur.
                </p>
                <button
                  onClick={() => {
                    setIsCartOpen(false);
                    navigateTo('catalog');
                  }}
                  className="mt-6 px-5 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-full text-xs font-semibold tracking-wide transition-all shadow-xs"
                >
                  Voir les produits
                </button>
              </div>
            ) : (
              cart.map((item) => {
                const itemUnitPrice =
                  currency === 'USD' ? item.product.priceUSD : item.product.priceEUR;
                const itemTotalPrice = itemUnitPrice * item.quantity;

                return (
                  <div key={item.product.id} className="py-4 flex gap-4">
                    <img
                      src={item.product.mainImage || item.product.images?.[0]}
                      alt={item.product.name}
                      className="w-20 h-20 rounded-xl object-cover bg-stone-100 shrink-0 border border-stone-200"
                    />

                    <div className="flex-1 flex flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <h4 className="text-sm font-medium text-stone-900 line-clamp-1">
                            {item.product.name}
                          </h4>
                          <span className="text-[11px] font-mono text-stone-400">
                            {item.product.sku}
                          </span>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-stone-400 hover:text-rose-600 p-1 transition-colors"
                          title="Supprimer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="mt-auto pt-2 flex items-center justify-between">
                        {/* Quantity controls */}
                        <div className="flex items-center border border-stone-200 rounded-lg overflow-hidden bg-stone-50">
                          <button
                            onClick={() =>
                              updateCartQuantity(item.product.id, item.quantity - 1)
                            }
                            className="p-1.5 hover:bg-stone-200 text-stone-600 transition-colors"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-3 text-xs font-semibold text-stone-800">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() =>
                              updateCartQuantity(item.product.id, item.quantity + 1)
                            }
                            className="p-1.5 hover:bg-stone-200 text-stone-600 transition-colors"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Price */}
                        <div className="text-right">
                          <span className="text-sm font-serif font-semibold text-stone-900">
                            {formatPrice(itemTotalPrice, itemTotalPrice)}
                          </span>
                          {item.quantity > 1 && (
                            <span className="block text-[10px] text-stone-400">
                              {formatPrice(itemUnitPrice, itemUnitPrice)} / u.
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Summary & Checkout */}
          {cart.length > 0 && (
            <div className="border-t border-stone-200 px-6 py-5 bg-stone-50 space-y-4">
              {/* Currency switcher inside cart */}
              <div className="flex items-center justify-between text-xs pb-2 border-b border-stone-200">
                <span className="text-stone-500 font-medium">Devise de facturation :</span>
                <button
                  type="button"
                  onClick={openCurrencyModal}
                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-white text-[#0A2540] border border-stone-300 hover:border-[#0A2540] transition-colors cursor-pointer"
                  title="Changer parmi les 54 pays africains"
                >
                  <span className="text-sm">{currencyInfo.flag}</span>
                  <span className="text-[#D97706] font-black">{currencyInfo.code}</span>
                  <span className="text-stone-500 text-[11px]">({currencyInfo.symbol})</span>
                  <span className="text-[10px] text-stone-400">Modifier ↗</span>
                </button>
              </div>

              {/* Subtotal & Shipping */}
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Sous-total articles</span>
                  <span className="font-medium text-stone-900">
                    {formatPrice(cartSubtotal, cartSubtotal)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Frais de livraison estimés</span>
                  <span>
                    {cartShipping === 0 ? (
                      <span className="text-emerald-700 font-semibold uppercase text-[11px]">
                        Offerts
                      </span>
                    ) : (
                      formatPrice(cartShipping, cartShipping)
                    )}
                  </span>
                </div>
                <div className="pt-2 border-t border-stone-200 flex justify-between text-base font-semibold text-stone-900 font-serif">
                  <span>Total TTC</span>
                  <span>{formatPrice(cartTotal, cartTotal)}</span>
                </div>
              </div>

              {/* Security info */}
              <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Commande sécurisée • Sans création de compte obligatoire</span>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={handleCheckoutClick}
                className="w-full py-3.5 px-6 bg-stone-900 hover:bg-amber-800 text-white rounded-xl text-sm font-semibold tracking-wide transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer active:scale-98"
              >
                <span>Commander</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setIsCartOpen(false);
                  navigateTo('cart');
                }}
                className="w-full text-center text-xs text-stone-500 hover:text-stone-900 underline transition-colors cursor-pointer"
              >
                Voir le détail complet du panier
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
